/* global require,_,console,Butterfly */

require.config({
    baseUrl: '../',
    packages: [{
        name: 'butterfly',
        location: '../butterfly',
        main: 'butterfly'
    },{
        name: 'bsl',
        location: '../../cordova',
        main: 'bsl'
    }],
    paths: {
        // require.js plugins
        view: '../butterfly/js/requirejs-butterfly',
        View: '../butterfly/js/view',
        // lib
        zepto: '../butterfly/vendor/zepto/zepto',
        fastclick: '../butterfly/vendor/fastclick/fastclick',
        jquery: '../butterfly/vendor/jquery/jquery-1.9.1.min',
        underscore: '../butterfly/vendor/underscore/underscore',
        backbone: '../butterfly/vendor/backbone/backbone',
        text: '../butterfly/vendor/requirejs-text/text',
        spin: '../butterfly/vendor/spinjs/spin.min',
        butterfly: '../butterfly/js/butterfly',
        commonObj: '../butterfly/js/common',
        i18n: '../butterfly/vendor/requirejs-i18n/js/i18n',
        components: '../butterfly/components/components',
        //以下的是组件
        iScroll: '../butterfly/vendor/iscroll/js/iscroll-lite',
        list: '../butterfly/components/list',

        //listview组件使用到的iscroll
        iscroll: '../butterfly/vendor/iscroll/js/iscroll-probe',
        listview: '../butterfly/components/listview/ListView',
        bsl_const: '../pages/commonBf/js/bsl_const',

        util: '../pages/commonBf/js/EMCSUtil',
        //公共方法
        com: '../pages/commonBf/js/com',
        oldCommon: '../pages/commonBf/js/common',
        //初始化公共方法
        init: '../pages/commonBf/js/init',
        ecConfig: '../butterfly/vendor/echarts/config',
        //公共请求地址
        openAPI: '../pages/commonBf/js/openapi',
        //jroll
        jroll: '../butterfly/vendor/jroll/jroll.min',
        'jroll-pulldown': '../butterfly/vendor/jroll/jroll-pulldown.min',
        'jroll-infinite': '../butterfly/vendor/jroll/jroll-infinite.min',
        //jroll_infinite原为JRoll1的无限加载
        //现引入JRoll2后，jroll_infinite成为兼容原API的大平台插件
        jroll_infinite: '../pages/commonBf/js/bupm.jroll.infinite',
        //ui3.0
        ui3: '../butterfly/vendor/ui3/ui3',
        ui3_dialog: '../butterfly/vendor/ui3/ui3.dialog',
        ui3_refresh: '../butterfly/vendor/ui3/ui3.refresh',
        //埋点
        cat: '../pages/commonBf/js/cat_amd',
        //jQuery WeUi
        jquery_weui: '../butterfly/vendor/jquery-weui/jquery-weui.min',

        //引入swiper.js文件
        swiper:'../butterfly/vendor/swiper/swiper.min',
        share_and_adjust: '../components/share_and_adjust/main'
    },
    waitSeconds: 7,
    shim: {
        zepto: {
            exports: '$'
        },
        underscore: {
            exports: '_'
        },
        iScroll: {
            exports: 'iScroll'
        },
        //iscroll-lite中不存在listview中使用到的部分方法，所以使用iscroll-probe
        iscroll: {
            exports: 'IScroll'
        },
        backbone: {
            deps: ['underscore'],
            exports: 'Backbone'
        },
        slide: {
            deps: ['zepto']
        },
        jquery_weui: {
            deps: ['zepto']
        },
        'jroll-pulldown': {
            deps: ['jroll']
        },
        'jroll-infinite': {
            deps: ['jroll']
        }
    },

    exclude: ["zepto", "jquery", "underscore", "backbone", "spin", "iScroll", "ui3"],
    excludeShallow: ["text"],

    optimize: "uglify2", // "uglify2" "none"
    preserveLicenseComments: false
});

var oldCommon = '', jqueryWeUI = '';
//旧模块迁移，引入旧文件common.js
if (document.querySelector("script[import-common]")) {
    oldCommon = 'oldCommon';
}
//支持jQuery WeUI
if (document.querySelector("script[import-weui]")) {
    jqueryWeUI = 'jquery_weui';
}

require(['bsl', 'bsl_const', oldCommon, jqueryWeUI], function(bsl, bsl_const, common, jquery_weui) {
    /**
     * 如果是生产环境，重写所有console的方法，禁止在生产环境输出
     * 提供__console方法在生产环境输出日志
     */
    window.__console = window.console;

    bsl.infinitus.tools.getHost(function(host) {
        var n;
        host = JSON.parse(host);

        if (typeof common === "function") {
            common(host);
        }

        //生产环境，重写console
        if (host.root.indexOf('gbss.infinitus.com.cn') > -1) {

            n = function() {};
            window.console = {
                assert: n,
                clear: n,
                count: n,
                debug: n,
                dir: n,
                dirxml: n,
                error: n,
                group: n,
                groupCollapsed: n,
                groupEnd: n,
                info: n,
                log: n,
                markTimeline: n,
                profile: n,
                profileEnd: n,
                table: n,
                time: n,
                timeEnd: n,
                timeStamp: n,
                timeline: n,
                timelineEnd: n,
                trace: n,
                warn: n
            };

        }

        //开始butterfly代码
        //增加了cat.js 捕获页面错误，监控页面操作 chenjiongming 2016-07-01
        require(['butterfly/js/butterfly', 'components', 'fastclick'], function(butterfly, Components, FastClick) {

            //iOS scroll to top
            setTimeout(function() {
                window.scrollTo(0, 1);
            }, 0);

            FastClick.attach(document.body);

            butterfly = _.extend(butterfly, Components);

            console.info("butterfly...");
            console.info(Butterfly);
            console.info('Components...');
            console.info(Components);

        });

    });

});