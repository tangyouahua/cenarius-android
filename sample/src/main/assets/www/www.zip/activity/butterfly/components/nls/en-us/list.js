define({
	"language": "en-us",
	"pullup_load_more": "Pull-up to load more data...",
	"release_to_load": "Release to load...",
	"release_to_update": "Release to update...",
	"pulldown_to_refresh": "Pull-down to refresh...",
	"data_updating": "Data updating...",
	"data_loading": "Data loading...",
	"not_offline": "Not offline in the moment",
	"no_data": "No Data",
	"no_more_data": "",
	"search": "Search",
	"searching": "Searching..."
});