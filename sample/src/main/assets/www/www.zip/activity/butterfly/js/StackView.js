/* global define,console,$,require,Backbone */
define(['View'], function(View) {

    //::性能优化:: 仅保持倒数两个veiw的display为block
    function keepLastTwoVeiwsBlock(views) {
        if (/Android/.test(navigator.userAgent)) {
            var l = views.length;
            for (var i = 0; i < l; i++) {
                if (i === l - 1 || i === l - 2) {
                    views[i].view.el.style.display = "block";
                } else {
                    views[i].view.el.style.display = "none";
                }
            }
        }
    }

    //::性能优化:: 后退，返回之前的页面，跨页面后退操作，1->2->3->4->2，将3、4移除
    //返回view的位置+1或0
    function goHistoryPage(path, views) {
        var l = views.length;
        for (var i = 0; i < l; i++) {
            if (path === views[i].path) {
                return i + 1; //避免i为0里判断失效
            }
        }
        return 0;
    }

    //show only contain one direct subview
    return View.extend({

        initialize: function() {
            View.prototype.initialize.apply(this, arguments);
            this.views = [];
            this.currentView = '';
            this.baseZIndex = 10;
            this.firstLoad = true;
        },

        route: function(paths, options) {
            /* ========================================================================
             * 通过index.html中的data-default定义默认跳转
             * 若data-default不存在或为空，调到当前模块的main.html
             * ======================================================================== */
            var path, mainEl, defaultPath, defaultModule;

            path = paths;

            if (!paths) { //地址栏没有配置路径
                console.log("paths没数据");
                mainEl = $(this.el);

                //配置路径
                defaultPath = mainEl.attr('data-default');

                //获取当前模块
                var pathname = window.location.pathname;
                var rootPath = pathname.substr(0, pathname.lastIndexOf('/'));
                defaultModule = rootPath.substr(rootPath.lastIndexOf('/') + 1);

                if (!defaultPath) {
                    defaultPath = defaultModule + '/main';
                } else if (defaultPath.indexOf('/') === -1) //若data-default没有模块名，则默认为当前模块
                {
                    defaultPath = defaultModule + '/' + defaultPath;
                }

                path = defaultPath || "";
            }

            //对于hash值多余或不完成的处理（暂定方案）
            if (path.indexOf('/') === path.length - 1) {
                path = path + "main";
            }
            
            require(['view!' + path + '.html'], function(ViewClass) {
                var index = goHistoryPage(path, this.views);
                //判断是不是后退操作。
                if (index) {

                    if (!this.views[index - 1] && !this.views[index]) {
                        return;
                    }

                    var currentView = this.views[this.views.length - 1].view;

                    this.views[index - 1].view.el.style.display = "block";
                    this.baseZIndex = this.views[index].view.el.style.zIndex * 1;

                    //移除多余的dom
                    for (var i = index, l = this.views.length - 1; i < l; i++) {
                        this.views[i].view.$el.remove();
                    }
                    //移除views
                    this.views.splice(index, l - index + 1);

                    currentView.animateSlideOutRight(function() {
                        //hide & remote top
                        currentView.$el.hide();
                        currentView.$el.remove();

                        //执行onShow
                        this.views[index - 1].view.show();
                        console.log(this.views);

                        //仅保持倒数两个veiw的display为block
                        keepLastTwoVeiwsBlock(this.views);

                    }.bind(this));

                } else {
                    var newView = new ViewClass();
                    this.views.push({
                        path: path,
                        view: newView
                    });
                    console.log(this.views);
                    newView.$el.css({
                        'position': 'absolute',
                        'top': '0px',
                        'bottom': '0px',
                        'width': '100%',
                        'z-index': this.baseZIndex++
                    });
                    console.log(newView.id);
                    console.log(newView.el);

                    if (newView.id && !newView.el.id) {
                        newView.el.id = newView.id;
                    } else if (!newView.id && !newView.el.id) {
                        console.warn(path + " [><] 缺少id！ 详见 https://iwiki.infinitus.com.cn/pages/viewpage.action?pageId=16893340 或 https://www.zybuluo.com/BarZu/note/231186");
                    } else {
                        console.warn(path + " [><] id冲突！ 详见 https://iwiki.infinitus.com.cn/pages/viewpage.action?pageId=16893340 或 https://www.zybuluo.com/BarZu/note/231186");
                    }
                    newView.render();
                    this.el.appendChild(newView.el);
                    if (!this.firstLoad) {
                        newView.animateSlideInRight(function() {
                            newView.show(options);
                            //仅保持倒数两个veiw的display为block
                            keepLastTwoVeiwsBlock(this.views);
                        }.bind(this));
                    } else {
                        newView.show(options);
                    }
                }
                this.firstLoad = false;

            }.bind(this), function() {
                Backbone.history.navigate('#/' + path);
            });

        }
    });
});
