
define('text!module_activityBf/activitySignUp.html',[],function () { return '<style type="text/css">\n\t/*.bodyer{bottom: 0px;}*/\n\t\n\t/*.signUp_li {\n\t\twidth: 49%;\n\t\tmargin-bottom: 10px;\n\t}\n\t\n\t.signUp_li:nth-child(odd) {\n\t\tfloat: left;\n\t}\n\t\n\t.signUp_li:nth-child(even) {\n\t\tfloat: right;\n\t}\n\t\n\t.signUp_li img {\n\t\twidth: 100%;\n\t\theight: 100px;\n\t}\n\t\n\t.signUp_li .title {\n\t\ttext-align: center;\n\t}*/\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar">\n\t<div class="ui3-row-12">\n\t\t<div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center">活动报名</div>\n\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"> <span class="goMain" style="color: black;">首页</span> </div>\n\t</div>\n</header>\n<div class="bodyer">\n\t<div id=\'headlineJroll\'>\n\t\t<div class="horn" style="display: none;"> <img src="images/horn_icon.png"> <span>业务总监会议时间更改为09:00-12:00</span> </div>\n\t\t<div class="activity_nav">\n\t\t\t<!--<div class="nav_list goHostActivity"> <img src="images/hostActivity_icon.png" /> <span>举办活动</span> </div>\n\t\t\t<div class="nav_list goSignUp" style="color: red;"> <img src="images/activity_signUp.png" /> <span>活动报名</span> </div>\n\t\t\t<div class="nav_list goVisit"> <img src="images/visit_icon.png" /> <span>参观申请</span> </div>\n\t\t\t<div class="nav_list goCalendar"> <img src="images/calendar_icon.png" /> <span>日历</span> </div>-->\n\t\t</div>\n\t\t<div id="new_wrap" style="bottom: 0px;">\n\t\t\t<div id="signUp_li_wrapper" style="padding: 5px;overflow: auto;">\n\t\t\t\t<!--<div class="signUp_li"> <img src="images/signUp1.png">\n\t\t\t\t\t<p class="title">海外培训</p>\n\t\t\t\t</div>-->\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n\n<!--这个模板暂时不用，用activities_li_tpl.html-->\n<script type="text/template" id="signUp_li_tpl">\n\n    <%for(var i=0;i<result.length;i++){\n    \tvar item = result[i];%>\n    \t\n\t\t<div class="signUp_li" data-url=<%= item.url %> > \n\t\t\t<img src= <%= item.photo %> >\n\t\t\t<!--<img src="images/signUp1.png">-->\n\t\t\t<p class="title"><%= item.title %></p>\n\t\t</div>    \t\n    \t\n    <%}%>\n\n</script>';});


define('text!module_activityBf/template/activities_menu_tpl.html',[],function () { return '\t<%for(var i=0;i<result.length;i++){\n\t    if(result[i].iconUri == \'\'){result[i].iconUri = \'images/home_icon_01.png\'} %>\n\t\t<div class="nav_list " style="color: red;" data-name="<%= result[i].name %>" uri="<%=result[i].uri%>" jNavInfo=\'<%=result[i].attributes.helpUri%>\'>\n\t\t\t<img src="<%=result[i].iconUri%>"/>\n\t\t\t<span><%=result[i].name%></span>\n\t\t</div>\n\t<%}%>';});


define('text!module_activityBf/template/activities_li_tpl.html',[],function () { return '    <%for(var i=0;i<result.length;i++){\n    \tvar item = result[i];%>\n\n\t<div class="activities_li" data-title=<%= item.title %> data-url=<%= item.url %>>\n\t\t<img src=<%= item.photo %> />\n\t\t<!--<img src="images/s2.jpg" />-->\n\t\t<div class="word">\n\t\t\t<span><%= item.title %></span>\n\t\t\t<span class="right_icon">></span>\n\t\t</div>\n\t</div>\n\t\n\t<%}%>';});

/*write by yangguanyong*/
define('module_activityBf/js/common',['zepto', "bsl", "util"], function($, bsl, Util) {
	var obj = {
		urlProfix: "/activity/activity",
		submitFn: function(arg, share) {
			var textArray = arg.me.$el.find('form').find('input[type=text]');
			//如果是用div模仿textarea的话
			//var testBtn = arg.me.$el.find('#test');
			//textArray.push(testBtn);
			console.log(textArray);
			//初始化的值
			var submitObj = {
				vo: {
					activityName: "美丽有约",
					projectCode: "999",
					type: "001",
					startTime: "2016-11-01",
					endTime: "2016-11-30",
					address: "666",
					templateCode: "MLYY",
					formData: {
						userName: "MLYY",
						ddddd: "MLdddYY"
					}
				}
			}
			var txt = "",
				submitWhether = 0,
				Alength = textArray.length;
			for(var i = 0; i < Alength; i++) {
				var item = $(textArray[i]);
				var value = item[0].tagName == "INPUT" ? item.val() : item.html(); //用于提交键值对
				var attrName = item.attr('data-attrName'); //用于弹窗
				var ajaxName = item.attr('data-ajaxName'); //用于提交键值对
				if(value == "") {
					txt += attrName + ' ';
				} else {
					submitObj.vo.formData[ajaxName] = value;
					submitWhether++;
				}
			}
			if(submitWhether == Alength) {
				submitObj.vo.formData.invitedType = arg.invitedType; //xx有约
				submitObj = JSON.stringify(submitObj);
				console.log(submitObj);
				var postUrl = const_getAppConfig.hostConfig.gateway + "/activity/activity/share/url?app_key=1&timestamp=1&sign=1&access_token=ZmJSR0FzYXl6dzlOUE1rTXRuTHl6YjN6N2hsTFVlUU1JR1h1MFI2QW1lU0NyRm5lRFNhYWF1QVNhN2NlWFg4QSMjMzMwNzM3NjAx";
				$.ajax({
					type: "post",
					url: postUrl,
					async: true,
					contentType: "application/json",
					data: submitObj,
					success: function(data) {
						var isWechatInstall = true,
							isQQInstall = true;
						//检测微信
						bsl.infinitus.share.checkAppInstall(1, function(isInstall) {
							isWechatInstall = isInstall;
							//检测QQ
							bsl.infinitus.share.checkAppInstall(2, function(isInstall) {
								isQQInstall = isInstall;
								if(isWechatInstall == true && isQQInstall == true) {
									share.tranUrl = data.returnObject;
									bsl.infinitus.share.shareContent(share.shareList, share.title, share.message, share.tranUrl, share.imgUrl, share.musicUrl, share.shareType, share.contentID, share.callBack);
								} else {
									alert("检测您的微信和QQ是否安装");
									return;
								}
							});
						});
					},
					error: function(e) {
						alert(e);
					}
				});
			} else {
				txt += '不能为空';
				alert(txt);
			}
		},
		transferFn:function(me,e,activities_menu_tpl,activeTitle){
			//生成菜单
			bsl.infinitus.tools.getCurrentMenuCode(function(menuCode){
				if(isInApp)menuCode = "BUPM-PHONE-HOME-ACTIVITY";
				Util.getMenu(menuCode,function(menus){
	            	var activities_menu_obj = _.template(activities_menu_tpl);
	            	var activities_menu_html = activities_menu_obj({
		                result: menus
		            });
		            me.$el.find('.activity_nav').html(activities_menu_html);
					me.$el.find('.activity_nav>div').unbind('click').bind('click',function(e){
						var $currentTarget = $(e.currentTarget)
						var active = $currentTarget.attr('data-name');
						if(active==activeTitle){
							return;
						}else{
							var uri = $currentTarget.attr('uri');
							var jNavInfoStr = $(e.currentTarget).attr('jNavInfo');
							//var jNavInfoObj = JSON.parse(jNavInfoStr);
							bsl.infinitus.transfer.openWebPage({ "sTitle":active, "url": uri, "sFlag": true,"jNavInfo":jNavInfoStr});
						}
					});		
				});
			});

			//首页
			me.$el.find('.goMain').off('click').on('click', function() {
				com.goMain()
			});
		}
	}
	return obj;
});
define('module_activityBf/activitySignUp',['zepto',
	"View",
	"util", "com", "jroll","text!./template/activities_menu_tpl.html",
	"text!./template/activities_li_tpl.html",
	"./js/common"
], function($, View, Util, com, Jroll,activities_menu_tpl,activities_li_tpl,common) {

	var me, jroll;

	return View.extend({

		id: "activityBf-module-activitySignUp",

		initialize: function() {

			me = this;

			Util.init();

		},

		events: {
			"click .goBack": Util.goBack,
			"click #signUp_li_wrapper .activities_li": "goDetails",
			"click .goHostActivity": "goHostActivity",
			"click .goCalendar": "goCalendar"
		},

		onShow: function() {
			this.transferFn();
			this.loadMenu();

			this.setHeight();

			jroll = new Jroll("#activityBf-module-activitySignUp #new_wrap", {
				bounce: true,
				scrollX: false
			});

			var bodyer = document.getElementsByClassName('bodyer')[0];
			var imgs = bodyer.getElementsByTagName("img");
			console.log(imgs.length);
			for(var i = 0; i < imgs.length; i++) {
				imgs[i].onload = function() {
					jroll.refresh();
				}
			}

		},

		//手动给jroll高度
		setHeight: function() {
			var hornHeight = document.querySelector('.horn').offsetHeight;
			var activityNavHeight = document.querySelector('.activity_nav').offsetHeight;
			var newWrapHeight = $('#activityBf-module-activitySignUp .bodyer')[0].offsetHeight - hornHeight - activityNavHeight;
			$('#activityBf-module-activitySignUp').find('#new_wrap').css('height', newWrapHeight + 'px');
			console.log(newWrapHeight);
		},

		//四个菜单跳转
		transferFn: function(e) {
			//第四个参数用来判断点击是否是当前页面
			common.transferFn(me,e,activities_menu_tpl,"活动报名");
		},

		//加载菜单
		loadMenu: function() {
            var getUrl = const_getAppConfig.hostConfig.gateway +  "/activity/activity/enter?access_token=ZmJSR0FzYXl6dzlOUE1rTXRuTHl6YjN6N2hsTFVlUU1JR1h1MFI2QW1lU0NyRm5lRFNhYWF1QVNhN2NlWFg4QSMjMzMwNzM3NjAx";
			Util.Ajax({
				url: getUrl,
				//data: {access_token:"ZmJSR0FzYXl6dzlOUE1rTXRuTHl6YjN6N2hsTFVlUU1JR1h1MFI2QW1lU0NyRm5lRFNhYWF1QVNhN2NlWFg4QSMjMzMwNzM3NjAx"},
				hideLoading: true,
				success: function(data, status, xhr) {
					console.log(data.result);

					var signUpLiHtml = activities_li_tpl;
					var signUpLiFn = _.template(signUpLiHtml);
					var signUpLiTpl = signUpLiFn({
						result: data
					});
					document.getElementById('signUp_li_wrapper').innerHTML = signUpLiTpl;
					setTimeout(function() {
						jroll.refresh();
					}, 100);
				}
			});
		},

		//点击菜单
		goDetails: function(e) {
			var Url = e.currentTarget.getAttribute('data-url');
			bsl.infinitus.transfer.openWebPage({
				url: Url,
				sFlag: false,
				sTitle:"活动报名"
			});
		}

	});
});

;
define("module_activityBf/common", function(){});


define('text!module_activityBf/index.html',[],function () { return '<!DOCTYPE html>\n<html lang="zh-CN">\n\t<head>\n\t\t<meta charset="UTF-8">\n\t\t<meta name="viewport" content="width=device-width,initial-scale=1, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />\n\t\t<title>活动</title>\n\t\t<script type="text/javascript" src="../../../cordova/cordova.js"></script>\n\t\t<link href="../commonBf/css/ui3.css" rel="stylesheet"/>\n    \t<link href="../commonBf/css/common.css" rel="stylesheet" />\n    \t<link href="../../butterfly/css/main.css" rel="stylesheet" />\n    \t<link rel="stylesheet" type="text/css" href="style.css"/>\n    \t<!--<script jroll-import=\'normal\' src=\'../commonBf/js/jroll.min.js\'></script>\n    \t<script jroll-import=\'normal\' src=\'../commonBf/js/jroll.infinite.min.js\'></script>-->\n\t</head>\n\t<script>\n\t//在手机运行时设为true,用于去除hardcode数据\n\tvar isInApp = true;\n\t</script>\n\t<body>\n\t\t<div id="index" data-view="$StackView"></div>\n    \t<script src="../../butterfly/vendor/requirejs/require.js" data-main="../../butterfly/js/butterfly-amd"></script>\n\t</body>\n</html>\n';});

define('module_activityBf/index',['zepto',
        "View",
        "util"
    ], function($, View, Util) {

    var me;

    return View.extend({
    	
    	
        events: {},
        initialize:function(){
        	me = this;
        	alert("A");
        },
        render: function() {
        },
        onShow: function() {
        }
    });
});

define('text!module_activityBf/invitationBeaty.html',[],function () { return '<style>\n.bodyer{padding: 0px;background: white;}\n#activityBf-module-invitationBeaty{color: RGB(133,27,54);}\n#activityBf-module-invitationBeaty .operation input[type=button]{background: RGB(133,27,54);}\n/*换行\n * #test{\n\twidth: 400px; \n    min-height: 40px; \n    max-height: 300px;\n    _height: 120px; \n    margin-left: auto; \n    margin-right: auto; \n    padding: 3px; \n    outline: 0; \n    border: 1px solid #a0b3d6; \n    font-size: 12px; \n    line-height: 24px;\n    padding: 2px;\n    word-wrap: break-word;\n    overflow-x: hidden;\n    overflow-y: auto;\n \n    -webkit-user-select: auto;\n    border-color: rgba(82, 168, 236, 0.8);\n    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1), 0 0 8px rgba(82, 168, 236, 0.6);\n}*/\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg">\n    <div class="ui3-row-12">\n        <div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n        <div class="ui3-col-6 ui3-fontsize-1 text-center">邀请函</div>\n        <div class="ui3-col-3 ui3-theme-color ui3-header-right">\n            <span class="goMain" style="color: black;">首页</span>\n        </div>\n    </div>\n</header>\n<div class="bodyer">\n\t<div class="invitation">\n\t<div class="invitation_img">\n\t\t<img src="images/invitation02.png">\n\t</div>\n\t\n\t<form>\n\t<div class="invitation_word">\n\t\t<p class="call">\n\t\t\t亲爱的\n\t\t\t<input value="李二狗" type="text" id="call_name" placeholder="20汉字以内" maxlength="20" data-attrName="被邀请人" data-ajaxName="beInviter" />:\n\t\t</p>\n\t\t<p class="main_body">\n\t\t\t女人，应该典雅、自信、美丽的。绽放自然纯粹光彩的女人，仿佛自天生就拥有了这与生俱来的全部赞美。“美丽走进你\n\t\t\t我他”美丽有约全国大型巡回活动盛情开幕！特别邀请您于\n\t\t\t<input type="text" value="2016-12-13 15:49:00" disabled="disabled" id="YYYYMMDD" placeholder="点击选择日期" data-attrName="日期" data-ajaxName="invitedDate">\n\t\t\t，在地点\n\t\t\t<input type=\'text\' value="广州" id="place" placeholder="不限字数" data-attrName="地点" data-ajaxName="address">\n\t\t\t<!--<div id="test" contenteditable="true" data-attrName="换行div" data-ajaxName="testBoy"><br></div>-->\n\t\t\t出席这美丽的约会，分享这难得的美丽盛宴。</p>\n\t</div>\n\t<div class="signature">\n\t\t<p>邀请人:<input type="text" id="inviter" value="陈莉莉" data-attrName="邀请人" data-ajaxName="inviter"></p>\t\n\t\t<p>日期:<input type="text" id="writeDate" value="2016年11月10日" data-attrName="填写日期" data-ajaxName="writeDate"></p>\n\t</div>\n\t<div class="operation">\n\t\t<input type="button" name="" id="sendBtn" value="发送" />\n\t</div>\n\t</form>\n\t\n\t</div>\n</div>';});

define('module_activityBf/invitationBeaty',['zepto',
	"View",
	"util", "com", "bsl", "./js/common", "jroll"
], function($, View, Util, com, bsl, common, Jroll) {

	var me, jroll;

	var obj = {

		id: "activityBf-module-invitationBeaty",

		initialize: function() {

			me = this;

			Util.init();

		},

		events: {
			"click .goBack": Util.goBack,
			"click .goMain": "goMain",
			"click #YYYYMMDD": "showDatePick",
			"click #sendBtn": "submitFn"
		},

		onShow: function() {
			jroll = new Jroll("#activityBf-module-invitationBeaty .bodyer", {
				bounce: true,
				XScroll: false
			});
		},

		goMain: function() {
			com.goMain();
		},

		showDatePick: function(e) {
			bsl.infinitus.tools.showDatePicker(2, "{'selectDate':'1111-11-11 12:12:00','MaxDate':'1111-11-11 21:19:00','MinDate':'1111-11-11 03:04:00'}", function(arg) {
				e.target.value = arg;
			});
		},

		submitFn: function() {
			var arg = {
				invitedType: "美丽有约",
				me: me
			}
			var share = {};
			share.shareList = [1, 5]; //微信朋友圈，微信好友，QQ
			share.title = arg.invitedType + "邀请函";
			share.message = "健康，幸福生活的源泉..."
			share.tranUrl = ""; //为空就行
			share.imgUrl = "";
			share.musicUrl = "";
			share.shareType = 0; //0为文本，1为图片
			share.contentID = 1218912312312; //内容id（注意用于埋点）
			share.callBack = function(arg) {
				console.log(arg.code + "," + arg.msg);
			}
			common.submitFn(arg, share);
		}
	};

	return View.extend(obj);

});

define('text!module_activityBf/invitationHealth.html',[],function () { return '<style type="text/css">\n.bodyer{padding: 0px;background: white;}\n#activityBf-module-invitationHealth{color: RGB(1,144,1);}\n#activityBf-module-invitationHealth .operation input[type=button]{background: RGB(1,144,1);}\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg">\n    <div class="ui3-row-12">\n        <div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n        <div class="ui3-col-6 ui3-fontsize-1 text-center">邀请函</div>\n        <div class="ui3-col-3 ui3-theme-color ui3-header-right">\n            <span class="goMain" style="color: black;">首页</span>\n        </div>\n    </div>\n</header>\n<div class="bodyer">\n\t<div class="invitation">\n\t<div class="invitation_img">\n\t\t<img src="images/invitation.jpg">\n\t</div>\n\t<form>\n\t<div class="invitation_word">\n\t\t<p class="call">\n\t\t\t亲爱的\n\t\t\t<input type="text" id="call_name" placeholder="20汉字以内" maxlength="20" data-attrName="被邀请人" data-ajaxName="beInviter"/>:</p>\n\t\t<p class="main_body">\n\t\t\t健康，幸福生活的源泉。智慧养生，从良好的生活习惯做起，跟我们一起最适合\n\t\t自己的养生方式，现邀您于\n\t\t<input type="text" value="2016-12-13 15:49:00" disabled="disabled" id="YYYYMMDD" placeholder="点击选择日期" data-attrName="日期" data-ajaxName="invitedDate">\n\t\t，在地点\n\t\t<input type=\'text\' value="广州" id="place" placeholder="不限字数" data-attrName="地点" data-ajaxName="address">\n\t\t出席健康有约，一起\n\t\t选择最适合自己的健康之路</p>\n\t</div>\n\t<div class="signature">\n\t\t<p>邀请人:<input type="text" id="" value="陈莉莉" data-attrName="邀请人" data-ajaxName="inviter"></p>\t\n\t\t<p>日期:<input type="text" id="" value="2016年11月10日" data-attrName="填写日期" data-ajaxName="writeDate"></p>\n\t</div>\n\t<div class="operation">\n\t\t<input type="button" name="" id="sendBtn" value="发送" />\n\t</div>\n\t</form>\n\t\n\t</div>\n</div>';});

define('module_activityBf/invitationHealth',['zepto',
        "View",
        "util","com","bsl","./js/common","jroll"
    ], function($, View, Util,com,bsl,common,Jroll) {

    var me,jroll;

    var obj = {

        id: "activityBf-module-invitationHealth",

        initialize: function() {

            me = this;

            Util.init();

        },

        events: {
            "click .goBack":Util.goBack,
            "click .goMain":"goMain",
            "click #YYYYMMDD":"showDatePick",
            "click #sendBtn":"submitFn"
        },

        onShow: function() {
         	jroll = new Jroll("#activityBf-module-invitationHealth .bodyer",{
        		bounce:true,
        		XScroll:false
        	});
        },
        goMain:function(){
        	com.goMain();
        },
        showDatePick:function(e){
        	bsl.infinitus.tools.showDatePicker(2,"{'selectDate':'1111-11-11 12:12:00','MaxDate':'1111-11-11 21:19:00','MinDate':'1111-11-11 03:04:00'}", function(arg){
        		e.target.value = arg;
        	});
        },
        submitFn:function(){
        	var arg = {
        		invitedType:"健康有约",
        		me:me
        	}
        	common.submitFn(arg,function(data){
        		console.log(data);
        		var shareList = [2,1,5];   //微信朋友圈，微信好友，QQ
				var title = arg.invitedType+"邀请函";
				var message = "健康，幸福生活的源泉..."
				var tranUrl = data;
				var imgUrl = "xxx.jpg";
				var musicUrl = "";
				var shareType = 0; //0为文本，1为图片
				var contentID = 1218912312312; //内容id（注意用于埋点）
				var callBack = function(){}
				bsl.infinitus.tools.shareContent(shareList,title,message,tranUrl,imgUrl,musicUrl,shareType,contentID,callBack);
        	});
        }
    };
    
    return View.extend(obj);

});


define('text!module_activityBf/invitationSuccess.html',[],function () { return '<style type="text/css">\n.bodyer{padding: 0px;background: white;}\n#activityBf-module-invitationSuccess{color: RGB(125,173,58);}\n#activityBf-module-invitationSuccess .operation input[type=button]{background: RGB(125,173,58);};\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg">\n    <div class="ui3-row-12">\n        <div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n        <div class="ui3-col-6 ui3-fontsize-1 text-center">邀请函</div>\n        <div class="ui3-col-3 ui3-theme-color ui3-header-right">\n            <span class="goMain" style="color: black;">首页</span>\n        </div>\n    </div>\n</header>\n<div class="bodyer">\n\t<div class="invitation">\n\t<div class="invitation_img">\n\t\t<img src="images/invitation03.png">\n\t</div>\n\t\n\t<form>\n\t<div class="invitation_word">\n\t\t<p class="call">\n\t\t\t亲爱的\n\t\t\t<input type="text" id="call_name" placeholder="20汉字以内" maxlength="20" data-attrName="被邀请人" data-ajaxName="beInviter"/>:</p>\n\t\t<p class="main_body">\n\t\t\t坚定梦想，蓄势高飞！现诚邀您于\n\t\t\t<input type="text" value="2016-12-13 15:49:00" disabled="disabled" id="YYYYMMDD" placeholder="点击选择日期" data-attrName="日期" data-ajaxName="invitedDate">\n\t\t\t，在地点\n\t\t\t<input type=\'text\' value="广州" id="place" placeholder="不限字数" data-attrName="地点" data-ajaxName="address">\n\t\t\t出席为您打造的事业说明会，通过学习与分\n                     享，聆听与吸收，让我们助您成功路上的一臂之力，让梦想不再遥远，我们携手前行。\n\t\t</p>\n\t</div>\n\t<div class="signature">\n\t\t<p>邀请人:<input type="text" id="" value="陈莉莉" data-attrName="邀请人" data-ajaxName="inviter"></p>\t\n\t\t<p>日期:<input type="text" id="" value="2016年11月10日" data-attrName="填写日期" data-ajaxName="writeDate"></p>\n\t</div>\n\t<div class="operation">\n\t\t<input type="button" name="" id="sendBtn" value="发送" />\n\t</div>\n\t</form>\n\t\n\t</div>\n</div>\n';});

define('module_activityBf/invitationSuccess',['zepto',
        "View",
        "util","com","bsl","./js/common",'jroll'
    ], function($, View, Util,com,bsl,common,Jroll) {

    var me,jroll;

    var obj = {

        id: "activityBf-module-invitationSuccess",

        initialize: function() {

            me = this;

            Util.init();

        },

        events: {
            "click .goBack":Util.goBack,
            "click .goMain":"goMain",
            "click #YYYYMMDD":"showDatePick",
            "click #sendBtn":"submitFn"
        },

        onShow: function() {
        	jroll = new Jroll("#activityBf-module-invitationSuccess .bodyer",{
        		bounce:true,
        		XScroll:false
        	});
        },
        
        goMain:function(){
        	com.goMain();
        },
        
        showDatePick:function(e){
        	bsl.infinitus.tools.showDatePicker(2,"{'selectDate':'1111-11-11 12:12:00','MaxDate':'1111-11-11 21:19:00','MinDate':'1111-11-11 03:04:00'}", function(arg){
        		e.target.value = arg;
        	});
        },
        
        submitFn:function(){
        	var arg = {
        		invitedType:"美丽有约",
        		me:me
        	}
        	common.submitFn(arg,function(data){
        		console.log(data);
        		var shareList = [2,1,5];   //微信朋友圈，微信好友，QQ
				var title = arg.invitedType+"邀请函";
				var message = "健康，幸福生活的源泉..."
				var tranUrl = data;
				var imgUrl = "xxx.jpg";
				var musicUrl = "";
				var shareType = 0; //0为文本，1为图片
				var contentID = 1218912312312; //内容id（注意用于埋点）
				var callBack = function(){}
				bsl.infinitus.tools.shareContent(shareList,title,message,tranUrl,imgUrl,musicUrl,shareType,contentID,callBack);
        	});
        }
    };
    
    return View.extend(obj);

});

define('text!module_activityBf/main.html',[],function () { return '<style type="text/css">\n.video_link{width: 100%;margin-top: 20px;background: white;}\n.video_link .video_link_title{width: 100%;padding: 10px;box-sizing: border-box;border-bottom: 1px solid RGB(153,153,153);}\n.video_link .video_link_list{width: 100%;padding: 2%;box-sizing: border-box;overflow: auto;}\n.video_link .video_link_list .video_link_li{width: 49%;box-sizing: border-box;height: 2rem;margin-bottom: 20px;overflow:hidden;position: relative;}\n.video_link .video_link_list .video_link_li:nth-child(odd){float: left;}\n.video_link .video_link_list .video_link_li:nth-child(even){float: right;}\n.video_link .video_link_list .video_link_li img{width: 100%;height: 100%;}\n.video_link .video_link_list .video_link_li .theme{position: absolute;z-index: 100;bottom: 0px;text-align: center;width: 100%;background: white;opacity: 0.7;}\n\n.how_to_host{width: 100%;text-align: center;padding: 10px;box-sizing: border-box;background: white;margin-top: 15px;position: relative;}\n.how_to_host .right_icon{position: absolute;top: 0px;right: 0px;padding: 10px;box-sizing: border-box;}\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar">\n    <div class="ui3-row-12">\n        <div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n        <div class="ui3-col-6 ui3-fontsize-1 text-center">举办活动</div>\n        <div class="ui3-col-3 ui3-theme-color ui3-header-right">\n            <span class="goMain" style="color: black;">首页</span>\n        </div>\n    </div>\n</header>\n\n<div class="bodyer">\n<div id="headlineJroll">\n\t<div class="horn" style="display: none;">\n\t\t<img src="images/horn_icon.png">\n\t\t<span>业务总监会议时间更改为09:00-12:00</span>\n\t</div>\n\t<div class="activity_nav">\n\t\t<!--<div class="nav_list goHostActivity" style="color: red;">\n\t\t\t<img src="images/hostActivity_icon.png"/>\n\t\t\t<span>举办活动</span>\n\t\t</div>\n\t\t<div class="nav_list goSignUp">\n\t\t\t<img src="images/activity_signUp.png"/>\n\t\t\t<span>活动报名</span>\n\t\t</div>\n\t\t<div class="nav_list goVisit">\n\t\t\t<img src="images/visit_icon.png"/>\n\t\t\t<span>参观申请</span>\n\t\t</div>\n\t\t<div class="nav_list goCalendar">\n\t\t\t<img src="images/calendar_icon.png"/>\n\t\t\t<span>日历</span>\n\t\t</div>-->\n    </div>\n\t\n\t<div id="new_wrap" style="bottom: 0px;">\n\t<div id="new_jroll">\n\t\n\t<div class="activities_list">\n\t\t<!--<div class="activities_li goInvitationHealth">\n\t\t\t<img src="images/s2.jpg" />\n\t\t\t<div class="word">\n\t\t\t\t<span>健康有约</span>\n\t\t\t\t<span class="right_icon">></span>\n\t\t\t</div>\n\t\t</div>\n\t\t<div class="activities_li goInvitationBeaty">\n\t\t\t<img src="images/s3.jpg"/>\n\t\t\t<div class="word">\n\t\t\t\t<span>美丽有约</span>\n\t\t\t\t<span class="right_icon">></span>\n\t\t\t</div>\n\t\t</div>\n\t\t<div class="activities_li goInvitationSuccess">\n\t\t\t<img src="images/s2.jpg"/>\n\t\t\t<div class="word">\n\t\t\t\t<span>成功有约</span>\n\t\t\t\t<span class="right_icon">></span>\n\t\t\t</div>\n\t\t</div>-->\n\t</div>\n\t\n\t<!--<div class="video_link">\n\t\t<div class="video_link_title">相关视频链接</div>\n\t    <div class="video_link_list">\n\t    \t<div class="video_link_li">\n\t    \t\t<img src="images/list2.jpg"/>\n\t    \t\t<div class="theme">\n\t    \t\t\t<h3>主题主题主题</h3>\n\t    \t\t\t<p>讲述讲述讲述</p>\n\t    \t\t</div>\n\t    \t</div>\n\t    \t<div class="video_link_li">\n\t    \t\t<img src="images/list3.jpg"/>\n\t    \t\t<div class="theme">\n\t    \t\t\t<h3>主题主题主题</h3>\n\t    \t\t\t<p>讲述讲述讲述</p>\n\t    \t\t</div>\n\t    \t</div>\n\t    \t<div class="video_link_li">\n\t    \t\t<img src="images/list4.jpg"/>\n\t    \t\t<div class="theme">\n\t    \t\t\t<h3>主题主题主题</h3>\n\t    \t\t\t<p>讲述讲述讲述</p>\n\t    \t\t</div>\n\t    \t</div>\n\t    \t<div class="video_link_li">\n\t    \t\t<img src="images/list5.jpg"/>\n\t    \t\t<div class="theme">\n\t    \t\t\t<h3>主题主题主题</h3>\n\t    \t\t\t<p>讲述讲述讲述</p>\n\t    \t\t</div>\n\t    \t</div>\n\t    </div>\n\t</div>\n\t\n\t<div class="how_to_host">\n\t\t<h3>如何举办小型SP活动?</h3>\n\t\t<span class="right_icon">></span>\n\t</div>-->\n\t\n\t</div>\n\t</div>\n\t\n</div>\n</div>\n';});

define('module_activityBf/main',['zepto',
	"View",
	"util", "com", "jroll","text!./template/activities_menu_tpl.html",
	"text!./template/activities_li_tpl.html",
	"./js/common"
], function($, View, Util, com, Jroll,activities_menu_tpl,activities_li_tpl,common) {

	var me, jroll;

	var obj = {

		id: "activityBf-module-main",

		initialize: function() {

			me = this;

			Util.init();

		},

		events: {
			"click .goBack": Util.goBack,
			"click .activities_li": "goInvitation"
		},

		onShow: function() {
			this.transferFn();

			//if(document.querySelector('.activities_list').innerHTML !== ""){
			this.loadMenu();
			//}

			this.setHeight();

			if(!jroll) {
				jroll = new Jroll("#activityBf-module-main #new_wrap", {
					bounce: true,
					scrollX: false
				});
			}

		},

		//加载三个有约列表
		loadMenu: function() {
            var getUrl =  const_getAppConfig.hostConfig.gateway +  "/activity/activity?access_token=ZmJSR0FzYXl6dzlOUE1rTXRuTHl6YjN6N2hsTFVlUU1JR1h1MFI2QW1lU0NyRm5lRFNhYWF1QVNhN2NlWFg4QSMjMzMwNzM3NjAx";
			//测试接口
			Util.Ajax({
				url: getUrl,
				//data: {dealerNo:"330737601"},
				hideLoading: true,
				success: function(data, status, xhr) {
					console.log(data);
					var invitationHtml = activities_li_tpl;
					var invitationFn = _.template(invitationHtml);
					var invitationTpl = invitationFn({
						result: data
					});
					document.querySelector('.activities_list').innerHTML = invitationTpl;

					setTimeout(function() {
						jroll.refresh();
					}, 100);
				}
			});

		},

		setHeight: function() {
			var hornHeight = document.querySelector('.horn').offsetHeight;
			var activityNavHeight = document.querySelector('.activity_nav').offsetHeight;
			var newWrapHeight = $('#activityBf-module-main .bodyer')[0].offsetHeight - hornHeight - activityNavHeight;
			$('#activityBf-module-main').find('#new_wrap').css('height', newWrapHeight + 'px');
			console.log(newWrapHeight);
		},
		
		transferFn: function(e) {
			
			common.transferFn(me,e,activities_menu_tpl,"举办活动");

		},

		//三个有约跳转链接
		goInvitation: function(e) {
//			var Url = e.currentTarget.getAttribute('data-url');
//			bsl.infinitus.transfer.openWebPage({
//				url: Url,
//				sFlag: false
//			});	
            var title = e.currentTarget.getAttribute('data-title');
            switch(title){
            	case "美丽有约":
                	Util.navigate('invitationBeaty');
            		break;
            	case "健康有约":
            		Util.navigate('invitationHealth');
            		break;
            	case "成功有约":
            		Util.navigate('invitationSuccess');
            		break;
            }
		}

	};
	
	return View.extend(obj);

});

define('text!module_activityBf/signUpDetails.html',[],function () { return '<style type="text/css">\n\t.bodyer{padding: 0px;bottom: 0px;background: white;}\n\t.mess{padding: 10px;}\n\t.mess .mess_ct{padding: 10px;}\n\t.mess .mess_ct .mess_li{padding: 5px;border-bottom: 1px solid RGB(121,121,121);}\n\t.mess .mess_ct .mess_li:nth-last-child(1){border-bottom: none;}\n\t.mess .mess_ct .mess_li .icon{background: RGB(168,43,43);width: 15px;display: inline-block;margin: 5px;}\n\t.mess .mess_ct .mess_li .map_nav{border: 1px solid RGB(121,121,121);padding: 5px;border-radius: 5px;float: right;}\n\t\n    .mess .mess_Intro{padding: 5px;}\n    .mess .mess_Intro .main_body{text-indent: 35px;}\n    .signUp_btn{width: 100%;background: RGB(168,43,43);color: RGB(252,255,255);text-align: center;padding: 20px;box-sizing: border-box;position: absolute;bottom: 0px;}\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg">\n    <div class="ui3-row-12">\n        <div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n        <div class="ui3-col-6 ui3-fontsize-1 text-center">活动</div>\n        <div class="ui3-col-3 ui3-theme-color ui3-header-right">\n            <span class="goMain" style="color: black;">首页</span>\n        </div>\n    </div>\n</header>\n<div class="bodyer">\n\t<div class="mess">\n\t\t<h3>业务总监会议</h3>\n\t\t<div class="mess_ct">\n\t\t\t<div class="mess_li">\n\t\t\t\t<span class="icon">&nbsp;</span>活动时间:<span>2016年12月10日 09:00-12:00</span>\n\t\t\t</div>\n\t\t\t<div class="mess_li">\n\t\t\t\t<span class="icon">&nbsp;</span>活动地点:<span>广州市无限极服务中心</span><span class="map_nav">地图导航</span>\n\t\t\t</div>\n\t\t\t<div class="mess_li">\n\t\t\t\t<span class="icon">&nbsp;</span>收费:<span>100元\t</span>\n\t\t\t</div>\n\t\t</div>\n\t\t<div class="mess_Intro">\n\t\t\t<p>活动简介</p>\n\t\t\t<p class="main_body">2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"\n\t\t\t2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"\n\t\t\t2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"\n\t\t\t2016年10月31日，广州分公司举办了"精英成长计划"2016年10月31日，广州分公司举办了"精英成长计划"</p>\n\t\t</div>\n\t</div>\n\t<div class="signUp_btn"><h3>我要报名</h3></div>\n</div>';});

define('module_activityBf/signUpDetails',['zepto',
        "View",
        "util","com"
    ], function($, View, Util,com) {

    var me;

    return View.extend({

        id: "activityBf-module-activityDetails",

        initialize: function() {

            me = this;

            Util.init();

        },

        events: {
            "click .goBack":Util.goBack,
            "click .goMain":"goMain"
        },

        onShow: function() {
			
        },
        goMain:function(){
        	com.goMain();
        }
    });

});


define('text!module_activityBf/visitApplication.html',[],function () { return '<style type="text/css">\n</style>\n<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar">\n\t<div class="ui3-row-12">\n\t\t<div class="ui3-col-3 ui3-icon-back goBack">返回</div>\n\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center">参观申请</div>\n\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"> <span class="goMain" style="color: black;">首页</span> </div>\n\t</div>\n</header>\n<div class="bodyer">\n\t<div id=\'headlineJroll\'>\n\t\t<div class="horn" style="display: none;"> <img src="images/horn_icon.png"> <span>业务总监会议时间更改为09:00-12:00</span> </div>\n\t\t<div class="activity_nav">\n\t\t\t<!--菜单模板-->\n\t\t</div>\n\t\t<div id="new_wrap" style="bottom: 0px;">\n\t\t\t<div id="visitAppli_li_wrapper" style="padding: 5px;overflow: auto;">\n            \t<!--模板-->\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>';});

define('module_activityBf/visitApplication',['zepto',
	"View",
	"util", "com", "jroll","text!./template/activities_menu_tpl.html",
	"text!./template/activities_li_tpl.html",
	"./js/common"
], function($, View, Util, com, Jroll,activities_menu_tpl,activities_li_tpl,common) {
	var me, jroll;
	return View.extend({

		id: "activityBf-module-visitApplication",

		initialize: function() {

			me = this;

			Util.init();

		},

		events: {
			"click .goBack": Util.goBack,
			"click #visitAppli_li_wrapper .activities_li": "goDetails",
		},

		onShow: function() {
			this.transferFn();
			this.loadMenu();

			this.setHeight();

			jroll = new Jroll("#activityBf-module-visitApplication #new_wrap", {
				bounce: true,
				scrollX: false
			});

			var bodyer = document.getElementsByClassName('bodyer')[0];
			var imgs = bodyer.getElementsByTagName("img");
			console.log(imgs.length);
			for(var i = 0; i < imgs.length; i++) {
				imgs[i].onload = function() {
					jroll.refresh();
				}
			}

		},

		//手动给jroll高度
		setHeight: function() {
			var hornHeight = document.querySelector('.horn').offsetHeight;
			var activityNavHeight = document.querySelector('.activity_nav').offsetHeight;
			var newWrapHeight = $('#activityBf-module-visitApplication .bodyer')[0].offsetHeight - hornHeight - activityNavHeight;
			$('#activityBf-module-visitApplication').find('#new_wrap').css('height', newWrapHeight + 'px');
			console.log(newWrapHeight);
		},

		//四个菜单跳转
		transferFn: function(e) {
			//第四个参数用来判断点击是否是当前页面
			common.transferFn(me,e,activities_menu_tpl,"参观申请");
		},

		//加载菜单
		loadMenu: function() {
            var getUrl = const_getAppConfig.hostConfig.gateway +  "/activity/activity/apply?access_token=ZmJSR0FzYXl6dzlOUE1rTXRuTHl6YjN6N2hsTFVlUU1JR1h1MFI2QW1lU0NyRm5lRFNhYWF1QVNhN2NlWFg4QSMjMzMwNzM3NjAx";
			Util.Ajax({
				url: getUrl,
				//data: {access_token:"ZmJSR0FzYXl6dzlOUE1rTXRuTHl6YjN6N2hsTFVlUU1JR1h1MFI2QW1lU0NyRm5lRFNhYWF1QVNhN2NlWFg4QSMjMzMwNzM3NjAx"},
				hideLoading: true,
				success: function(data, status, xhr) {
					console.log(data);

					var visitAppliLiHtml = activities_li_tpl;
					var visitAppliLiFn = _.template(visitAppliLiHtml);
					var visitAppliLiTpl = visitAppliLiFn({
						result: data
					});
					document.getElementById('visitAppli_li_wrapper').innerHTML = visitAppliLiTpl;
					setTimeout(function() {
						jroll.refresh();
					}, 100);
				}
			});
		},

		//点击菜单
		goDetails: function(e) {
			var Url = e.currentTarget.getAttribute('data-url');
			bsl.infinitus.transfer.openWebPage({
				url: Url,
				sFlag: false,
				sTitle:"参观申请"
			});
		}

	});
});

  define('module_activityBf/module-registry',['require','text!./activitySignUp.html','./activitySignUp','./common','text!./index.html','./index','text!./invitationBeaty.html','./invitationBeaty','text!./invitationHealth.html','./invitationHealth','text!./invitationSuccess.html','./invitationSuccess','./js/common','text!./main.html','./main','text!./signUpDetails.html','./signUpDetails','text!./template/activities_li_tpl.html','text!./template/activities_menu_tpl.html','text!./visitApplication.html','./visitApplication'],function(require){
    require("text!./activitySignUp.html");
require("./activitySignUp");
require("./common");
require("text!./index.html");
require("./index");
require("text!./invitationBeaty.html");
require("./invitationBeaty");
require("text!./invitationHealth.html");
require("./invitationHealth");
require("text!./invitationSuccess.html");
require("./invitationSuccess");
require("./js/common");
require("text!./main.html");
require("./main");
require("text!./signUpDetails.html");
require("./signUpDetails");
require("text!./template/activities_li_tpl.html");
require("text!./template/activities_menu_tpl.html");
require("text!./visitApplication.html");
require("./visitApplication");
  });
  
