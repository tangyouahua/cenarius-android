//HuangDongPeng 2016-07-O6 埋点。
//在页面中添加com.infinitus.official.common下cat.js文件。
/*var catScript = document.getElementById("cat-script");
if(!catScript){
    catScript = document.createElement("script");
    catScript.type= "text/javascript";
    catScript.id= "cat-script";
    catScript.src = "../common/js/cat.js";
    document.head.appendChild(catScript);
}*/

define(["jquery", "bsl", "ui3"], function($, bsl, ui3) {

    if (bsl.infinitus.tools.debug == true) {
        window.host = {
            "gbss": {
                "uim": "https://uim-test.infinitus.com.cn",
                "gmcsnew": "http://m-test.infinitus.com.cn",
                "gmcs": "http://m.infinitus.com.cn",
                "gbss": "https://gbssdev.infinitus.com.cn/gbss-bupm",
                "root": "https://gbssdev.infinitus.com.cn",
                "cdn": "https://emcsdev-cdn.infinitus.com.cn"
            },
            "uim": null,
            "root": null,
            "emcs": null
        }
        window.param = {
            param: [{
                "DPI": "3.0",
                "appVersion": "1.1.0",
                "brand": "nubia",
                "coreVersion": "3.10.49-perf-g6f05a8e-00414-g64f1036+nubia%40swlab-1t078%29+%29+%231+SMP+PREEMPT+Mon+Dec+14+18%3A58%3A47+CST+2015",
                "dealerNo": "161398128",
                "imei": "867924022287208",
                "loginToken": "",
                "machineModel": "NX511J",
                "model": "2",
                "netType": "wifi",
                "os": "2",
                "osVersion": "5.0.2",
                "screen": "1080x1920"
            }]
        }

    }

    var hostRoot = host.root;
    var hostGmcs = host.gbss.gmcs;
    //设备参数
    var commonParam = param.param;
    //设备类型
    var deviceType = commonParam[0].brand == "iPad" ? "pad" : "phone";
    //设备参数
    //var commonParam = tools.getCommonParam();
    //设备类型
    //var deviceType = commonParam[0].brand == "iPad" ? "pad" : "phone";

    //检测网络 add by chenjianlong 2016-04-26
    (function() {
        //通过判断是否引入了ui3.css
        var a = false,
            link, style;
        var sheets = document.styleSheets;
        for (var i = 0, l = sheets.length; i < l; i++) {
            if (sheets[i].href && sheets[i].href.indexOf("ui3.css") !== -1) {
                a = true;
                break;
            }
        }

        if (!a) {
            link = document.createElement("link");
            link.rel = "stylesheet";
            link.href = "../../butterfly/vendor/ui3/ui3.css";
            document.head.appendChild(link);
        }

        //如果木有头部，重置网络提醒高度
        var headerDiv = document.querySelector("header.topBar");
        if (!headerDiv || headerDiv.classList.contains("none")) {
            style = document.createElement("style");
            style.innerHTML = ".ui3-network-fail {top:0;}";
            document.head.appendChild(style);
        }

        //监听网络动态变化
        if (bsl.infinitus.network.checkNetworkChanging) {
            bsl.infinitus.network.checkNetworkChanging(function(status) {

                //网络连接失败
                if (parseInt(status, 10) === 0) {

                    //使用了ui3则使用新提示
                    ui3.showNetworkFail();

                } else { //网络连接成功

                    ui3.hideNetworkFail();

                }

            });
        }

    }());
    /*获取页面标题 2016/7/29 by DGHGPG start*/
    // (function() {
    //     setTimeout(function() {
    //         var cat_title = $("[data-click-title]").attr("data-click-title");
    //         var specialTitle = ["官网主页", "董事长寄语", "产品", "多媒体", "图库", "专题", "电子出版物", "互动", "企业介绍", "无限极微刊", "养生固本 健康人生", "媒眼无限极", "业务导航", "导航信息", "官网信息", "寄语信息", "产品详情", "图库信息", "出版物信息", "文章信息", "焦点"];
    //         if (specialTitle.indexOf(cat_title) === -1) {
    //             if (cat_title) {
    //                 CatStatistical.analytics({
    //                     "category": cat_title,
    //                     "action": "浏览",
    //                     "label": "",
    //                     "value": ""
    //                 });
    //             }
    //         }
    //     }, 1500);
    // })();
    /*获取页面标题 2016/7/29 by DGHGPG end*/
    //把对象转换为数组
    function toArray(obj) {
        if ($.isArray(obj)) {
            return obj;
        } else {
            return [obj];
        }
    }

    //日期格式化
    Date.prototype.format = function(format) {
        var o = {
            "M+": this.getMonth() + 1, //month
            "d+": this.getDate(), //day
            "h+": this.getHours(), //hour
            "m+": this.getMinutes(), //minute
            "s+": this.getSeconds(), //second
            "q+": Math.floor((this.getMonth() + 3) / 3), //quarter
            "S": this.getMilliseconds() //millisecond
        }
        if (/(y+)/.test(format)) {
            format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(format)) {
                format = format.replace(RegExp.$1,
                    RegExp.$1.length == 1 ? o[k] :
                    ("00" + o[k]).substr(("" + o[k]).length));
            }
        }
        return format;
    }

    function formatDate(obj, property, format) {
        var data = toArray(obj);
        var properties = toArray(property)
        for (var i = 0; i < data.length; i++) {
            for (var j = 0; j < properties.length; j++) {
                data[i][properties[j]] = toDate(data[i][properties[j]]).format(format);
            }
        }
    }

    //加法运算，避免数据相加小数点后产生多位数和计算精度损失。
    function numAdd(num1, num2) {
        var baseNum, baseNum1, baseNum2;
        try {
            baseNum1 = num1.toString().split(".")[1].length;
        } catch (e) {
            baseNum1 = 0;
        }
        try {
            baseNum2 = num2.toString().split(".")[1].length;
        } catch (e) {
            baseNum2 = 0;
        }

        baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
        return (numMulti(baseNum, num1) + numMulti(baseNum, num2)) / baseNum;
    };

    //加法运算，避免数据相减小数点后产生多位数和计算精度损失。
    function numSub(num1, num2) {
        var baseNum, baseNum1, baseNum2;
        var precision; // 精度
        try {
            baseNum1 = num1.toString().split(".")[1].length;
        } catch (e) {
            baseNum1 = 0;
        }
        try {
            baseNum2 = num2.toString().split(".")[1].length;
        } catch (e) {
            baseNum2 = 0;
        }
        baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
        precision = (baseNum1 >= baseNum2) ? baseNum1 : baseNum2;
        return Number(((num1 * baseNum - num2 * baseNum) / baseNum).toFixed(precision));
    };

    //乘法运算，避免数据相乘小数点后产生多位数和计算精度损失。
    //这个方法还是有问题
    function numMulti(num1, num2) {
        var baseNum = 0;
        try {
            baseNum += num1.toString().split(".")[1].length;
        } catch (e) {}
        try {
            baseNum += num2.toString().split(".")[1].length;
        } catch (e) {}
        return Number(num1.toString().replace(".", "")) * Number(num2.toString().replace(".", "")) / Math.pow(10, baseNum);
    };


    //除法运算，避免数据相除小数点后产生多位数和计算精度损失。
    //这个方法还是有问题
    function numDiv(num1, num2) {
        var baseNum1 = 0,
            baseNum2 = 0;
        var baseNum3, baseNum4;
        try {
            baseNum1 = num1.toString().split(".")[1].length;
        } catch (e) {
            baseNum1 = 0;
        }
        try {
            baseNum2 = num2.toString().split(".")[1].length;
        } catch (e) {
            baseNum2 = 0;
        }
        with(Math) {
            baseNum3 = Number(num1.toString().replace(".", ""));
            baseNum4 = Number(num2.toString().replace(".", ""));
            return (baseNum3 / baseNum4) * pow(10, baseNum2 - baseNum1);
        }
    }


    //页面初始化事件处理
    var pageObject = {
        //每个页面都会render时调用此方法，用作判断IPAD,PHONE，然后使用不同的模板
        render: function(phone, pad, CubeView) {
            if (deviceType == "phone") {
                // $(this.el).html(phone);
            } else {
                //$(this.el).html(pad);
            }
            return this;
        },
        beforeInitialize: function() {
            com.commonAjax.ajaxSetup();
            com.commonAjaxNew.ajaxCount = 0; //用作记录当前AJAX的请求数，控制loader 的显示消失。
        },
        beforeOnShow: function(e) {

            pageObject.changeTheme();
            //弹出框
            $(".showOverlay").bind("click", function() {
                $(".overlay").removeClass("hidden");
            })
            $(".overlay").bind("click", function(sender) { //点击灰色层隐藏
                if (sender.currentTarget == sender.target) {
                    $(sender.currentTarget).addClass("hidden");
                }
            });

            //返回功能
            //e.goBack 当本身页面没有定义的时候这里就会定义，然后判断是否有弹出层，有就关闭弹出层，否则就判断是否模块主页，如果是就直接跳出。
            if (e.goBack == null) {
                e.goBack = function(sender) {
                    if ($(".overlay:not(.hidden)").length > 0) {
                        $(".overlay").addClass("hidden");
                    } else {
                        bsl.infinitus.transfer.returnBack(true);
                    }
                }
            }
            //物理返回键
            bsl.infinitus.tools.setBackAction("page.goBack");
            //返回按键
            var goBackBtn = $(".goBack");
            goBackBtn.html(goBackBtn.text());
            goBackBtn.bind("click", e.goBack);

            var goBack = $(".goBack:not(.goBackPad)").parent();
            goBack.addClass("goBack");
            var goBackPad = $(".goBackPad").parent();
            goBackPad.addClass("goBack");
            goBack.prepend($("<img class='goBackImg' src='../commonBf/images/goBack.png' />"));
            goBackPad.prepend($("<img class='goBackImg' src='../commonBf/images/gobackPad.png' />"));


            //弹出窗隐藏滚动条
            try {
                var mutationObserver = window.MutationObserver || window.WebKitMutationObserver;
                if (mutationObserver != null) {
                    var observer = new mutationObserver(function(sender) {
                        if ($(".overlay:not(.hidden)").length > 0) {
                            //removeScroll();
                        } else {
                            //enableScroll();
                        }
                    });
                    var overlay = $(".overlay")
                    overlay.forEach(function(item) {
                        var options = {
                            "attributes": true
                        };
                        observer.observe(item, options);
                    });
                }
            } catch (ex) {}

            //弹出层出现后，背后层不能拖动
            $(".overlay").bind("touchmove", function(e) {
                var div = $(e.currentTarget).find("div > div:nth-of-type(2)")[0];
                if (div && div.scrollHeight <= $(div).css("height").replace(/[a-z]/g, '')) {
                    e.preventDefault();
                    return;
                }
                var continueMove = false;
                $(".overlay > div > div:nth-of-type(2) > div").each(function() {
                    if (e.target == this) {
                        continueMove = true;
                        return false;
                    }
                });
                if (!continueMove) e.preventDefault();
            });
        },
        afterOnShow: function(e) {
            //displayPhoneOrPad();
            document.body.scrollTop = 0;
            //if(e.afterOnShow) {
            //    setTimeout(function(){
            //       e.afterOnShow();
            //    },0)
            //}
        },
        nextPageSuccess: function(data) {
            if (data.lastPage) {
                $(".nextPage").addClass("hidden");
            } else {
                $(".nextPage").removeClass("hidden");
            }
        },
        nextPageFailed: function() {
            $(".nextPage").addClass("hidden");
        },
        changeTheme: function() {
            var status_bar_bg = bsl.infinitus.tools.themeColor("status_bar_bg",function(color){
                return color;
            })
            try {
                $(".topBar>div").css("background-color", status_bar_bg);
            } catch (ex) {}
        }
    }

    //拦截页面事件
    Object.defineProperty(window, "page", {
        set: function(e) {
            pageObject.beforeInitialize(e);
            e.callBack = new Array();
            window.currentPage = e;
        },
        get: function(e) {
            return window.currentPage;
        }
    });

    //设置缓存 chenjiongming 20160411
    function setCache(key, value, param) {
        key = "official" + key;
        var sp = [];
        if (param && param !== {}) {
            for (var i in param) {
                sp.push(i + "=" + param[i])
            }
        }
        sp = sp.join("&");
        key += sp;

        bsl.infinitus.userDefault.saveValue(key, value);
        //存的时候，先把所有png,jpg,gif类型的图片缓存到本地

        var tempArrObj = value; //对象数组，或者对象
        if (value.total) {
            tempArrObj = value.data;
        }
        findValue(tempArrObj, changeCache);
    }
    //遍历数据的值
    function findValue(obj, callback) {
        if (typeof obj === "string") {
            callback(obj);
        } else if (obj instanceof Array) { //数组
            for (var i = 0; i < obj.length; i++) {
                findValue(obj[i], callback);
            }
        } else if (obj instanceof Object) {
            for (var j in obj) {
                findValue(obj[j], callback);
            }
        } else {
            return;
        }

    }
    //更改图片缓存 chenjiongming 20160411
    function changeCache(url) {
        if (typeof url == "string") {
            var reg = /\.(png|jpg|gif|jpeg)$/i;
            var result = reg.test(url);
            if (result) {
                bsl.infinitus.cache.cacheImageWithUrl(url, "", function(params) {
                    //imgUrl,filePath,sUserInfo
                    var img = $(".cacheimages");
                    for (var j = 0; j < img.length; j++) {
                        if ($(img[j]).attr("data-url") === url) {
                            img[j].src = params[1];
                        }
                    }
                });
            }
        }
    }
    //获取JSON缓存 chenjiongming 20160411
    function getCache(key, callBack, param) {
        key = "official" + key;
        var sp = [];
        if (param && param !== {}) {
            for (var i in param) {
                sp.push(i + "=" + param[i])
            }
        }
        sp = sp.join("&");
        key += sp;
        bsl.infinitus.userDefault.readValue(key, callBack);
    }

    //获取图片缓存 chenjiongming 20160411
    function showCacheImage() {
        var imgs = $(".cacheimages[data-url]");
        if (imgs.length) {
            var url = $(imgs[0]).attr("data-url");
            bsl.infinitus.cache.cacheImageWithUrl(url, "", function(params) {
                //imgUrl,filePath,sUserInfo
                var img = $(".cacheimages[data-url='" + params[0] + "']")[0];
                img.src = params[1];
                $(img).removeAttr("data-url");
                showCacheImage();
            });
        }
    }
    var com = {
        test: function() {
            alert("test")
        },
        //全局ajax调用方法
        callAjaxNew: function(options) {

            // Cat Analytics 大平台官网 框架修改
            if (typeof catAnalyticStart !== 'undefined' && catAnalyticsEnd !== 'undefined') {
                var cat_op = { url: options.url, data: options.data, success: options.success };
                catAnalyticStart(cat_op);
                var callsuccess = options.success;
                options.success = function(data, status, xhr) {
                    var cat_returnOp = {
                        code: status,
                        data: data
                    };
                    catAnalyticsEnd(cat_op, cat_returnOp);
                    callsuccess(data, status, xhr);
                }
            }
            this.commonAjaxNew.ajaxSend(options);
            if (bsl.infinitus.tools.debug) {
                if (!options.type || options.type == "GET") {
                    options.type = "GET";
                } else {
                    options.type = "POST";
                }
                $.ajax(options);
            } else {
                options.data = options.data ? options.data : {};
                //默认为POST
                if (!options.type) {
                    options.type = "POST";
                }
                //chenjiongming 2016-04-08
                bsl.infinitus.network.checkNetState(function(r) {
                    if (r == 0) { //无网络
                        getCache(options.url, function(d) {
                            var data;
                            try {
                                data = JSON.parse(d);
                            } catch (e) {
                                data = [];
                            }
                            options.success(data, 101);
                            //先执行json串的返回，然后启用图片缓存。
                            setTimeout(showCacheImage, 300);
                        }, options.data);
                        ui3.showNetworkFail();
                    } else { //有网络
                        ui3.hideNetworkFail();
                        if (options.type === "GET") {
                            bsl.infinitus.network.get(options.url, options.data, function(data) {
                                var d;
                                try {
                                    d = JSON.parse(data[0]);
                                } catch (e) {
                                    console.error(e);
                                    d = null;
                                }
                                if (d) options.success(d, data[1]);
                            });
                        } else {
                            bsl.infinitus.network.post(options.url, options.data, function(data) {
                                var d;
                                try {
                                    d = JSON.parse(data[0]);
                                } catch (e) {
                                    console.error(e);
                                    d = null;
                                }
                                if (d) {
                                    //有网络时缓存
                                    setCache(options.url, d, options.data);
                                    options.success(d, data[1]);
                                }
                            });
                        }
                    }
                });
            }
        },
        commonAjaxNew: {
            timeout: [],
            _ajaxCount: 0,

            set ajaxCount(value) {
                if (value == 1) {
                    window.test33333 = value;
                    bsl.infinitus.tools.showLoading();
                }
                if (value == 0) {
                    if (page != null) {
                        page.lastMessage = "";
                    }
                    bsl.infinitus.tools.dismissLoading();
                }
                this._ajaxCount = value;
            },

            get ajaxCount() {
                return this._ajaxCount;
            },

            //ajax请求默认设置
            ajaxSetup: function() {
                //设置时长
                $.ajaxSettings.timeout = "60000";
                //$.ajaxSettings.timeout = "1000000";
                $.ajaxSettings.beforeSend = function(xhr, settings) {
                    if (settings.dataType = "jsonp") {
                        settings.url = settings.url.replace("callback=", "jsonpCallback=");
                    }
                };
            },

            //生成ajax默认数据格式
            ajaxSend: function(options) {
                //this.ajaxCount = 1;
                if (!options.hideLoading) {
                    bsl.infinitus.tools.showLoading();
                }
                var id = setTimeout(function() {
                    //bsl.infinitus.tools.showToast("网络超时，请刷新页面", 2000);
                    bsl.infinitus.tools.dismissLoading();
                }, 1000 * 5);
                this.timeout.push(id);
                //修正请求地址
                //if (options.emcs == true) {
                //    options.url = hostEmcs + options.url;
                //} else {
                //    options.url = hostRoot + options.url;
                //}
                if (options.headers == null) {
                    options.headers = new Object();
                }
                options.headers["X-Requested-With"] = "XMLHttpRequest";
                if (options.data == null) {
                    options.data = new Object();
                }
                if (options.type != "POST") {
                    this.ajaxParam(options);
                }
                this.ajaxCallback(options);
            },

            //生成ajax默认数据格式
            ajaxParam: function(options) {
                var urlParam = new Array();
                this.createParam(options.data, urlParam, "");
                for (var i = 0; i < urlParam.length; i++) {
                    urlParam[i] = urlParam[i].substring(1);
                }
                if (bsl.infinitus.tools.debug) {
                    for (x in commonParam[0]) {
                        urlParam.push(x + "=" + commonParam[0][x]);
                    }
                }
                options.data = null;
                if (urlParam.length) {
                    options.url = options.url + "?" + urlParam.join("&");
                };

            },
            /**
             *
             * @param data 传入的参数数据
             * @param urlParam 空数组
             * @param route
             * @param isArray
             */
            createParam: function(data, urlParam, route, isArray) {
                for (x in data) {
                    switch (typeof(data[x])) { //data[x] 递归的字段数据
                        case "function":
                            continue;
                        case "object":
                            if (isArray) {
                                this.createParam(data[x], urlParam, route + "[" + x + "]", $.isArray(data[x])); //product[0].code=1 &...
                            } else {
                                this.createParam(data[x], urlParam, route + "." + x, $.isArray(data[x])); // array["name"] => name="a"& name="b"
                            }
                            break;
                        default: //普通参数
                            if (isArray) {
                                urlParam.push(route + "=" + data[x]);
                            } else {
                                urlParam.push(route + "." + x + "=" + data[x]);
                            }
                            break;
                    }
                }
            },

            //ajax回调
            ajaxCallback: function(options) {
                var that = this;
                var callback = options.success;
                options.success = function(data, status, xhr) {
                    //that.ajaxCount = 0;
                    bsl.infinitus.tools.dismissLoading();
                    for (i = 0; i < that.timeout.length; i++) {
                        clearTimeout(that.timeout[i]);
                    };
                    that.timeout = [];
                    if (data != null) { //接口调用成功
                        if (options.isQuery == false) { //操作
                            if (options.hide == null || $.inArray(0, toArray(options.hide)) == -1) { // 0 success, 1 fail, 3 empty
                                bsl.infinitus.tools.showToast("成功");
                            }
                            callback(data, status, xhr);
                        } else { //查询
                            var result;
                            if (data.firstPage == null) { //data.firstPage 相当于 判断是否分页
                                result = data;
                            } else {
                                result = data.content;
                                result.firstPage = data.firstPage;
                                result.lastPage = data.lastPage;
                                result.totalElements = data.totalElements;
                            }
                            if (result == null || ($.isArray(result) && result.length == 0)) { //没有数据
                                if (options.hide == null || $.inArray(3, toArray(options.hide)) == -1) { //假如hide传入 3 ，不弹出没有数据
                                    bsl.infinitus.tools.showToast("没有数据");
                                }
                                that.ajaxFailed(options, data);
                                if (data.firstPage != null) {
                                    pageObject.nextPageFailed(); //假如是分页并且没有数据，把下拉加载隐藏
                                }
                            } else { //查询成功
                                callback(result, status, xhr);
                                if (data.firstPage != null) {
                                    pageObject.nextPageSuccess(data);
                                }
                            }
                        }
                    } else { //接口调用失败
                        if (options.hide == null || $.inArray(1, toArray(options.hide)) == -1) {
                            var message = data.exceptionMessage != null ? data.exceptionMessage : data;
                            if (page.lastMessage != message) {
                                page.lastMessage = message;
                                bsl.infinitus.tools.showDialog("温馨提示", page.lastMessage);
                            }
                        }
                        that.ajaxFailed(options, data);
                        if (data.firstPage != null) {
                            pageObject.nextPageFailed();
                        }
                    }
                };
            },

            //ajax错误
            ajaxFailed: function(options, data) {
                if (options.failed != null) {
                    options.failed(data);
                }
            }
        },

        template: {
            emcs: host.gbss.cdn,
            //图片补全地址
            formatImage: function(obj, property) {
                var data = toArray(obj);
                var properties = toArray(property);
                for (var i = 0; i < data.length; i++) {
                    for (var j = 0; j < properties.length; j++) {
                        if (properties[j].indexOf("|") == -1) {
                            var url = data[i][properties[j]];
                            if (url != null) {
                                if (data[i][properties[j]].indexOf(this.emcs) == -1) {
                                    data[i][properties[j]] = this.emcs + url;
                                }
                                data[i][properties[j] + "Key"] = url.split("=")[1];
                            } else {
                                data[i][properties[j] + "Key"] = "";
                            }
                        } else { //支持子对象是数组
                            var children = properties[j].split("|");
                            var ary = toArray(data[i][children[0]]);
                            for (var k = 0; k < ary.length; k++) {
                                var url = ary[k][children[1]];
                                if (url != null) {
                                    if (ary[k][children[1]].indexOf(this.emcs) == -1) {
                                        ary[k][children[1]] = this.emcs + url;
                                    }
                                    ary[k][children[1] + "Key"] = url.split("=")[1];
                                } else {
                                    ary[k][children[1] + "Key"] = "";
                                }
                            }
                        }
                    }
                }
            },
            //把图片缓存到客户端
            loadImage: function(obj, property) {
                var data = toArray(obj);
                var properties = toArray(property)
                console.log(data)
                for (var i = 0; i < data.length; i++) {
                    for (var j = 0; j < properties.length; j++) {
                        if (properties[j].indexOf("|") == -1) {
                            var key = data[i][properties[j] + "Key"];
                            //console.log(key)
                            if (key != null && key != "") {
                                var url = data[i][properties[j]];
                                bsl.infinitus.cache.cacheImageWithUrl("template.formatImageCallback", url, key);
                            }
                        } else { //支持子对象是数组
                            var children = properties[j].split("|");
                            var ary = data[i][children[0]];
                            for (var k = 0; k < ary.length; k++) {
                                var key = ary[k][children[1] + "Key"];
                                if (key != null && key != "") {
                                    var url = ary[k][children[1]];
                                    bsl.infinitus.cache.cacheImageWithUrl("template.formatImageCallback", url, key);
                                }
                            }
                        }
                    }
                }
            },
            //缓存到客户端后的回调方法
            formatImageCallback: function(url, filePath, sUserInfo) {
                //console.log(url,filePath,sUserInfo);

                //当模板循环绑定数据的时候，图片属性名+'key'＝图片路径后面的参数值
                //图片路径: /front/emcs-server-newMobile/mongoPhoto/getProductPhoto?photoCode=S1418893496410
                $("." + sUserInfo).attr("src", filePath);

            }
        },
        //本地数据保存
        saveObject: function(key, obj) {
            if (bsl.infinitus.tools.debug) {
                window.localStorage.setItem(key, JSON.stringify(obj));
            } else {
                bsl.infinitus.tools.saveTempCache(key, JSON.stringify(obj));
            }
        },

        saveGlobalCache: function(key, val) {
            if (bsl.infinitus.tools.debug) {
                window.localStorage.setItem(key, JSON.stringify(val));
            } else {
                bsl.infinitus.cache.setH5Cache(key, JSON.stringify(val));
            }
        },

        clearGlobalCache: function() {
            if (bsl.infinitus.tools.debug) {
                localStorage.clear();
            } else {
                bsl.infinitus.cache.clearH5Cache();
            }
        },

        //本地数据读取
        loadObject: function(key, keep) {
            var objStr;
            if (bsl.infinitus.tools.debug) {
                objStr = window.localStorage.getItem(key);
                if (keep != true) {
                    //window.localStorage.removeItem(key);
                }
            } else {
                objStr = bsl.infinitus.tools.readTempCache(key);
                if (keep != true) {
                    bsl.infinitus.tools.saveTempCache(key, "");
                }
            }
            var obj = (objStr == null || objStr == "") ? null : JSON.parse(objStr);
            return obj;
        },

        clearObject: function() {
            if (bsl.infinitus.tools.debug) {
                window.localStorage.clear();
            } else {
                bsl.infinitus.tools.cleanTempCache();
            }
        },

        removeObject: function(key) {
            window.localStorage.removeItem(key);
        }

    }



    //var template = {
    //    emcs: host.gbss.cdn,
    //    //图片补全地址
    //    formatImage: function (obj, property) {
    //        var data = toArray(obj);
    //        var properties = toArray(property);
    //        for (var i = 0; i < data.length; i++) {
    //            for (var j = 0; j < properties.length; j++) {
    //                if (properties[j].indexOf("|") == -1) {
    //                    var url = data[i][properties[j]];
    //                    if (url != null) {
    //                        if (data[i][properties[j]].indexOf(this.emcs) == -1) {
    //                            data[i][properties[j]] = this.emcs + url;
    //                        }
    //                        data[i][properties[j] + "Key"] = url.split("=")[1];
    //                    } else {
    //                        data[i][properties[j] + "Key"] = "";
    //                    }
    //                } else {//支持子对象是数组
    //                    var children = properties[j].split("|");
    //                    var ary = toArray(data[i][children[0]]);
    //                    for (var k = 0; k < ary.length; k++) {
    //                        var url = ary[k][children[1]];
    //                        if (url != null) {
    //                            if (ary[k][children[1]].indexOf(this.emcs) == -1) {
    //                                ary[k][children[1]] = this.emcs + url;
    //                            }
    //                            ary[k][children[1] + "Key"] = url.split("=")[1];
    //                        } else {
    //                            ary[k][children[1] + "Key"] = "";
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    },
    //    //把图片缓存到客户端
    //    loadImage: function (obj, property) {
    //        var data = toArray(obj);
    //        var properties = toArray(property)
    //        console.log(data)
    //        for (var i = 0; i < data.length; i++) {
    //            for (var j = 0; j < properties.length; j++) {
    //                if (properties[j].indexOf("|") == -1) {
    //                    var key = data[i][properties[j] + "Key"];
    //                    //console.log(key)
    //                    if (key != null && key != "") {
    //                        var url = data[i][properties[j]];
    //                        cache.cacheImageWithUrl("template.formatImageCallback", url, key);
    //                    }
    //                } else {//支持子对象是数组
    //                    var children = properties[j].split("|");
    //                    var ary = data[i][children[0]];
    //                    for (var k = 0; k < ary.length; k++) {
    //                        var key = ary[k][children[1] + "Key"];
    //                        if (key != null && key != "") {
    //                            var url = ary[k][children[1]];
    //                            cache.cacheImageWithUrl("template.formatImageCallback", url, key);
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //    },
    //    //缓存到客户端后的回调方法
    //    formatImageCallback: function (url, filePath, sUserInfo) {
    //        //console.log(url,filePath,sUserInfo);
    //
    //        //当模板循环绑定数据的时候，图片属性名+'key'＝图片路径后面的参数值
    //        //图片路径: /front/emcs-server-newMobile/mongoPhoto/getProductPhoto?photoCode=S1418893496410
    //        //<img class="<%=iconImgKey%>" src="../common/images/default.png" />
    //
    //            $("." + sUserInfo).attr("src", filePath);
    //
    //    }
    //}
    //
    //
    //
    ////本地数据保存
    //function saveObject(key, obj) {
    //    if (tools.debug) {
    //        window.localStorage.setItem(key, JSON.stringify(obj));
    //    } else {
    //        tools.saveTempCache(key, JSON.stringify(obj));
    //    }
    //}
    //
    //function saveGlobalCache(key,val){
    //    if (tools.debug) {
    //        window.localStorage.setItem(key, JSON.stringify(val));
    //    } else {
    //        cache.setH5Cache(key, JSON.stringify(val));
    //    }
    //}
    //
    //function getGlobalCache(key,keep){
    //    var objStr;
    //    if (tools.debug) {
    //        objStr = window.localStorage.getItem(key);
    //        if (keep != true) {
    //            //window.localStorage.removeItem(key);
    //        }
    //    } else {
    //        objStr = cache.getH5Cache(key);
    //        //if (keep != true) {
    //        //    cache.setH5Cache(key, null);
    //        //}
    //    }
    //    var obj = (objStr == null || objStr == "") ? null : JSON.parse(objStr);
    //    return obj;
    //}
    //
    //function clearGlobalCache(){
    //    if (tools.debug) {
    //        localStorage.clear();
    //    } else {
    //        cache.clearH5Cache();
    //    }
    //}
    //
    //
    ////本地数据读取
    //function loadObject(key, keep) {
    //    var objStr;
    //    if (tools.debug) {
    //        objStr = window.localStorage.getItem(key);
    //        if (keep != true) {
    //            //window.localStorage.removeItem(key);
    //        }
    //    } else {
    //        objStr = tools.readTempCache(key);
    //        if (keep != true) {
    //            tools.saveTempCache(key, "");
    //        }
    //    }
    //    var obj = (objStr == null || objStr == "") ? null : JSON.parse(objStr);
    //    return obj;
    //}
    //
    ////清楚本地数据
    //function clearObject() {
    //    if (tools.debug) {
    //        window.localStorage.clear();
    //    } else {
    //        tools.cleanTempCache();
    //    }
    //}
    //
    ////清除本地数据
    //function removeObject(key) {
    //    window.localStorage.removeItem(key);
    //}










    //根据phone和pad显示不同
    function displayPhoneOrPad() {
        var hiddenType = commonParam[0].brand != "iPad" ? "pad" : "phone";
        //$("." + hiddenType).addClass("hidden");
        $("." + hiddenType).remove(); // 删除另一个设备的 HTML
        $('#' + hiddenType + 'Style').remove(); // 删除另一个设备的 CSS
    }

    //全局回调函数
    var globalCallback = new Object();


    String.prototype.trim = function() {
        return this.replace(/(^\s*)|(\s*$)/g, "");
    }

    String.prototype.trimStr = function(value) {
        var str = this;
        if (str.indexOf(value) == 0) {
            str = str.substring(value.length);
        }
        if (str.indexOf(value) == str.length - value.length) {
            str = str.substring(0, str.length - value.length);
        }
        return str;
    }


    function pageLoad() {
        var designWidth = deviceType == "pad" ? 2048 : 640;
        var deviceDidth = $(window).width();
        if (deviceType == "pad") {
            $('#phone').remove(); //删除 phone 端页面 HTML
            $("meta[name='viewport']").each(function(item) {
                var content = $(this).attr("content").replace("device-width", deviceDidth);
                $(this).attr("content", content);
            });
        } else {
            //pad 端 css 覆盖 phone 端，若为 phone 端，则remove pad 端 css
            $('head link').filter('.padStyle').remove(); // 删除公共的 xx_pad.css
            $('#padStyle').remove(); // 删除页面的 pad 端 CSS
            $('#pad').remove(); //删除 pad 端页面 HTML
        }
        var fontSize = deviceDidth / designWidth * (deviceType == "pad" ? 160 : 100);
        $("html").css("font-size", fontSize + "px");
        if (typeof window.console === "undefined") {
            window.console = {
                log: function() {}
            };
        }
        $(window).resize = setSize;
    }


    function setSize() {
        var designWidth = deviceType == "pad" ? 2048 : 640;
        var deviceDidth = $(window).width();
        if (deviceType == "pad") {
            $("meta[name='viewport']").forEach(function(item) {
                var content = $(item).attr("content").replace("device-width", deviceDidth);
                $(item).attr("content", content);
            });
        }
        var fontSize = deviceDidth / designWidth * (deviceType == "pad" ? 160 : 100);
        $("html").css("font-size", fontSize + "px");
    }
    //当没数据的时候要显示一个DIV样式来显示
    function empty(msg) {
        var noData = $("<div class='empty middle'>" + msg + "</div>");
        page.$el.append(noData);
    }

    function removeEmpty() {
        $(".empty").remove();
    }


    //解决事件穿透
    function stopTap(touch, e) {
        var target = $(touch.el);
        if (target.hasClass("overlay") || (target.parents().hasClass("overlay") && !(target.is("input[type='text']") || target.is("input[type='checkbox']"))) || target.hasClass("goBack") || ($(touch.el).data("stop") || $(touch.el).parents("[data-stop='true']").length > 0)) {
            var forTap = $('#forTap');
            if (!forTap[0]) {
                forTap = $('<div id="forTap" style="display: none; border-radius: 60px; position: absolute; z-index: 99999; width: 60px; height: 60px"></div>');
                $('body').append(forTap);
            }
            forTap.css({
                top: (e.changedTouches[0].pageY - 30) + 'px',
                left: (e.changedTouches[0].pageX - 30) + 'px'
            });
            forTap.show();
            setTimeout(function() {
                forTap.hide();
            }, 350);
        }
    }

    function keyboardWillShow() {
        $(".shoppingBar").addClass("commonHidden");
        $(".topBar>div,.fixed").addClass("topBarHidden");
        page.currentScroll = document.body.scrollTop;
    }

    function keyboardWillHide() {
        $(".shoppingBar").removeClass("commonHidden");
        $(".topBar>div,.fixed").removeClass("topBarHidden");
        document.body.scrollTop = page.currentScroll;
    }

    function toDate(str) {
        try {
            if (str == null) {
                return new Date();
            }
            var date = new Date(str);
            if (!isNaN(date)) {
                return date;
            } else {
                // return eval("new Date(" + str.split(/\D/).join(",").replace(/(^\,*)|(\,*$)/g, "") + ")");
                var parms = str.split(/\D/).join(",").replace(/(^\,*)|(\,*$)/g, "").split(",")
                parms[1] = parseInt(parms[1]) - 1;
                return eval("new Date(" + parms.join(",") + ")");
            }
        } catch (ex) {
            return new Date(undefined);
        }
    }

    function selecttwo() {
        var firstTab = $(".tab > div > div:nth-child(2)");
        firstTab.addClass("tab-active").siblings().removeClass("tab-active");
        var firstContext = $("#" + firstTab.data("context"));
        firstContext.removeClass("hidden").siblings().addClass("hidden");
    }


    function jumpToPage(url, isDel) {
        if (bsl.infinitus.tools.debug) {
            location.href = url;
        } else {
            if (url.indexOf("../") > -1) {
                url = url.replace("../", "");
            }
            console.log(url);

            bsl.infinitus.transfer.openWebPage({
                "url":url, 
                "sFlag":isDel
            });
        }
    }

    //返回元素在数组中的index
    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function(elt) {
            var len = this.length >>> 0;
            var from = Number(arguments[1]) || 0;
            from = (from < 0) ? Math.ceil(from) : Math.floor(from);
            if (from < 0) from += len;
            for (; from < len; from++) {
                if (from in this && this[from] === elt) return from;
            }
            return -1;
        };
    }
    //根据index删除数组元素
    if (!Array.prototype.del) {
        Array.prototype.del = function(n) {
            if (n < 0) {
                return this;
            } else {
                return this.slice(0, n).concat(this.slice(n + 1, this.length));
            }
        }
    }

    return com;

})