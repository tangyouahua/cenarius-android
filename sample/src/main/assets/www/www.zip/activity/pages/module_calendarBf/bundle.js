//! moment.js
//! version : 2.10.6
//! authors : Tim Wood, Iskren Chernev, Moment.js contributors
//! license : MIT
//! momentjs.com
!function(a,b){"object"==typeof exports&&"undefined"!=typeof module?module.exports=b():"function"==typeof define&&define.amd?define('module_calendarBf/js/moment.min',b):a.moment=b()}(this,function(){"use strict";function a(){return Hc.apply(null,arguments)}function b(a){Hc=a}function c(a){return"[object Array]"===Object.prototype.toString.call(a)}function d(a){return a instanceof Date||"[object Date]"===Object.prototype.toString.call(a)}function e(a,b){var c,d=[];for(c=0;c<a.length;++c)d.push(b(a[c],c));return d}function f(a,b){return Object.prototype.hasOwnProperty.call(a,b)}function g(a,b){for(var c in b)f(b,c)&&(a[c]=b[c]);return f(b,"toString")&&(a.toString=b.toString),f(b,"valueOf")&&(a.valueOf=b.valueOf),a}function h(a,b,c,d){return Ca(a,b,c,d,!0).utc()}function i(){return{empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1}}function j(a){return null==a._pf&&(a._pf=i()),a._pf}function k(a){if(null==a._isValid){var b=j(a);a._isValid=!(isNaN(a._d.getTime())||!(b.overflow<0)||b.empty||b.invalidMonth||b.invalidWeekday||b.nullInput||b.invalidFormat||b.userInvalidated),a._strict&&(a._isValid=a._isValid&&0===b.charsLeftOver&&0===b.unusedTokens.length&&void 0===b.bigHour)}return a._isValid}function l(a){var b=h(NaN);return null!=a?g(j(b),a):j(b).userInvalidated=!0,b}function m(a,b){var c,d,e;if("undefined"!=typeof b._isAMomentObject&&(a._isAMomentObject=b._isAMomentObject),"undefined"!=typeof b._i&&(a._i=b._i),"undefined"!=typeof b._f&&(a._f=b._f),"undefined"!=typeof b._l&&(a._l=b._l),"undefined"!=typeof b._strict&&(a._strict=b._strict),"undefined"!=typeof b._tzm&&(a._tzm=b._tzm),"undefined"!=typeof b._isUTC&&(a._isUTC=b._isUTC),"undefined"!=typeof b._offset&&(a._offset=b._offset),"undefined"!=typeof b._pf&&(a._pf=j(b)),"undefined"!=typeof b._locale&&(a._locale=b._locale),Jc.length>0)for(c in Jc)d=Jc[c],e=b[d],"undefined"!=typeof e&&(a[d]=e);return a}function n(b){m(this,b),this._d=new Date(null!=b._d?b._d.getTime():NaN),Kc===!1&&(Kc=!0,a.updateOffset(this),Kc=!1)}function o(a){return a instanceof n||null!=a&&null!=a._isAMomentObject}function p(a){return 0>a?Math.ceil(a):Math.floor(a)}function q(a){var b=+a,c=0;return 0!==b&&isFinite(b)&&(c=p(b)),c}function r(a,b,c){var d,e=Math.min(a.length,b.length),f=Math.abs(a.length-b.length),g=0;for(d=0;e>d;d++)(c&&a[d]!==b[d]||!c&&q(a[d])!==q(b[d]))&&g++;return g+f}function s(){}function t(a){return a?a.toLowerCase().replace("_","-"):a}function u(a){for(var b,c,d,e,f=0;f<a.length;){for(e=t(a[f]).split("-"),b=e.length,c=t(a[f+1]),c=c?c.split("-"):null;b>0;){if(d=v(e.slice(0,b).join("-")))return d;if(c&&c.length>=b&&r(e,c,!0)>=b-1)break;b--}f++}return null}function v(a){var b=null;if(!Lc[a]&&"undefined"!=typeof module&&module&&module.exports)try{b=Ic._abbr,require("./locale/"+a),w(b)}catch(c){}return Lc[a]}function w(a,b){var c;return a&&(c="undefined"==typeof b?y(a):x(a,b),c&&(Ic=c)),Ic._abbr}function x(a,b){return null!==b?(b.abbr=a,Lc[a]=Lc[a]||new s,Lc[a].set(b),w(a),Lc[a]):(delete Lc[a],null)}function y(a){var b;if(a&&a._locale&&a._locale._abbr&&(a=a._locale._abbr),!a)return Ic;if(!c(a)){if(b=v(a))return b;a=[a]}return u(a)}function z(a,b){var c=a.toLowerCase();Mc[c]=Mc[c+"s"]=Mc[b]=a}function A(a){return"string"==typeof a?Mc[a]||Mc[a.toLowerCase()]:void 0}function B(a){var b,c,d={};for(c in a)f(a,c)&&(b=A(c),b&&(d[b]=a[c]));return d}function C(b,c){return function(d){return null!=d?(E(this,b,d),a.updateOffset(this,c),this):D(this,b)}}function D(a,b){return a._d["get"+(a._isUTC?"UTC":"")+b]()}function E(a,b,c){return a._d["set"+(a._isUTC?"UTC":"")+b](c)}function F(a,b){var c;if("object"==typeof a)for(c in a)this.set(c,a[c]);else if(a=A(a),"function"==typeof this[a])return this[a](b);return this}function G(a,b,c){var d=""+Math.abs(a),e=b-d.length,f=a>=0;return(f?c?"+":"":"-")+Math.pow(10,Math.max(0,e)).toString().substr(1)+d}function H(a,b,c,d){var e=d;"string"==typeof d&&(e=function(){return this[d]()}),a&&(Qc[a]=e),b&&(Qc[b[0]]=function(){return G(e.apply(this,arguments),b[1],b[2])}),c&&(Qc[c]=function(){return this.localeData().ordinal(e.apply(this,arguments),a)})}function I(a){return a.match(/\[[\s\S]/)?a.replace(/^\[|\]$/g,""):a.replace(/\\/g,"")}function J(a){var b,c,d=a.match(Nc);for(b=0,c=d.length;c>b;b++)Qc[d[b]]?d[b]=Qc[d[b]]:d[b]=I(d[b]);return function(e){var f="";for(b=0;c>b;b++)f+=d[b]instanceof Function?d[b].call(e,a):d[b];return f}}function K(a,b){return a.isValid()?(b=L(b,a.localeData()),Pc[b]=Pc[b]||J(b),Pc[b](a)):a.localeData().invalidDate()}function L(a,b){function c(a){return b.longDateFormat(a)||a}var d=5;for(Oc.lastIndex=0;d>=0&&Oc.test(a);)a=a.replace(Oc,c),Oc.lastIndex=0,d-=1;return a}function M(a){return"function"==typeof a&&"[object Function]"===Object.prototype.toString.call(a)}function N(a,b,c){dd[a]=M(b)?b:function(a){return a&&c?c:b}}function O(a,b){return f(dd,a)?dd[a](b._strict,b._locale):new RegExp(P(a))}function P(a){return a.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(a,b,c,d,e){return b||c||d||e}).replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&")}function Q(a,b){var c,d=b;for("string"==typeof a&&(a=[a]),"number"==typeof b&&(d=function(a,c){c[b]=q(a)}),c=0;c<a.length;c++)ed[a[c]]=d}function R(a,b){Q(a,function(a,c,d,e){d._w=d._w||{},b(a,d._w,d,e)})}function S(a,b,c){null!=b&&f(ed,a)&&ed[a](b,c._a,c,a)}function T(a,b){return new Date(Date.UTC(a,b+1,0)).getUTCDate()}function U(a){return this._months[a.month()]}function V(a){return this._monthsShort[a.month()]}function W(a,b,c){var d,e,f;for(this._monthsParse||(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[]),d=0;12>d;d++){if(e=h([2e3,d]),c&&!this._longMonthsParse[d]&&(this._longMonthsParse[d]=new RegExp("^"+this.months(e,"").replace(".","")+"$","i"),this._shortMonthsParse[d]=new RegExp("^"+this.monthsShort(e,"").replace(".","")+"$","i")),c||this._monthsParse[d]||(f="^"+this.months(e,"")+"|^"+this.monthsShort(e,""),this._monthsParse[d]=new RegExp(f.replace(".",""),"i")),c&&"MMMM"===b&&this._longMonthsParse[d].test(a))return d;if(c&&"MMM"===b&&this._shortMonthsParse[d].test(a))return d;if(!c&&this._monthsParse[d].test(a))return d}}function X(a,b){var c;return"string"==typeof b&&(b=a.localeData().monthsParse(b),"number"!=typeof b)?a:(c=Math.min(a.date(),T(a.year(),b)),a._d["set"+(a._isUTC?"UTC":"")+"Month"](b,c),a)}function Y(b){return null!=b?(X(this,b),a.updateOffset(this,!0),this):D(this,"Month")}function Z(){return T(this.year(),this.month())}function $(a){var b,c=a._a;return c&&-2===j(a).overflow&&(b=c[gd]<0||c[gd]>11?gd:c[hd]<1||c[hd]>T(c[fd],c[gd])?hd:c[id]<0||c[id]>24||24===c[id]&&(0!==c[jd]||0!==c[kd]||0!==c[ld])?id:c[jd]<0||c[jd]>59?jd:c[kd]<0||c[kd]>59?kd:c[ld]<0||c[ld]>999?ld:-1,j(a)._overflowDayOfYear&&(fd>b||b>hd)&&(b=hd),j(a).overflow=b),a}function _(b){a.suppressDeprecationWarnings===!1&&"undefined"!=typeof console&&console.warn&&console.warn("Deprecation warning: "+b)}function aa(a,b){var c=!0;return g(function(){return c&&(_(a+"\n"+(new Error).stack),c=!1),b.apply(this,arguments)},b)}function ba(a,b){od[a]||(_(b),od[a]=!0)}function ca(a){var b,c,d=a._i,e=pd.exec(d);if(e){for(j(a).iso=!0,b=0,c=qd.length;c>b;b++)if(qd[b][1].exec(d)){a._f=qd[b][0];break}for(b=0,c=rd.length;c>b;b++)if(rd[b][1].exec(d)){a._f+=(e[6]||" ")+rd[b][0];break}d.match(ad)&&(a._f+="Z"),va(a)}else a._isValid=!1}function da(b){var c=sd.exec(b._i);return null!==c?void(b._d=new Date(+c[1])):(ca(b),void(b._isValid===!1&&(delete b._isValid,a.createFromInputFallback(b))))}function ea(a,b,c,d,e,f,g){var h=new Date(a,b,c,d,e,f,g);return 1970>a&&h.setFullYear(a),h}function fa(a){var b=new Date(Date.UTC.apply(null,arguments));return 1970>a&&b.setUTCFullYear(a),b}function ga(a){return ha(a)?366:365}function ha(a){return a%4===0&&a%100!==0||a%400===0}function ia(){return ha(this.year())}function ja(a,b,c){var d,e=c-b,f=c-a.day();return f>e&&(f-=7),e-7>f&&(f+=7),d=Da(a).add(f,"d"),{week:Math.ceil(d.dayOfYear()/7),year:d.year()}}function ka(a){return ja(a,this._week.dow,this._week.doy).week}function la(){return this._week.dow}function ma(){return this._week.doy}function na(a){var b=this.localeData().week(this);return null==a?b:this.add(7*(a-b),"d")}function oa(a){var b=ja(this,1,4).week;return null==a?b:this.add(7*(a-b),"d")}function pa(a,b,c,d,e){var f,g=6+e-d,h=fa(a,0,1+g),i=h.getUTCDay();return e>i&&(i+=7),c=null!=c?1*c:e,f=1+g+7*(b-1)-i+c,{year:f>0?a:a-1,dayOfYear:f>0?f:ga(a-1)+f}}function qa(a){var b=Math.round((this.clone().startOf("day")-this.clone().startOf("year"))/864e5)+1;return null==a?b:this.add(a-b,"d")}function ra(a,b,c){return null!=a?a:null!=b?b:c}function sa(a){var b=new Date;return a._useUTC?[b.getUTCFullYear(),b.getUTCMonth(),b.getUTCDate()]:[b.getFullYear(),b.getMonth(),b.getDate()]}function ta(a){var b,c,d,e,f=[];if(!a._d){for(d=sa(a),a._w&&null==a._a[hd]&&null==a._a[gd]&&ua(a),a._dayOfYear&&(e=ra(a._a[fd],d[fd]),a._dayOfYear>ga(e)&&(j(a)._overflowDayOfYear=!0),c=fa(e,0,a._dayOfYear),a._a[gd]=c.getUTCMonth(),a._a[hd]=c.getUTCDate()),b=0;3>b&&null==a._a[b];++b)a._a[b]=f[b]=d[b];for(;7>b;b++)a._a[b]=f[b]=null==a._a[b]?2===b?1:0:a._a[b];24===a._a[id]&&0===a._a[jd]&&0===a._a[kd]&&0===a._a[ld]&&(a._nextDay=!0,a._a[id]=0),a._d=(a._useUTC?fa:ea).apply(null,f),null!=a._tzm&&a._d.setUTCMinutes(a._d.getUTCMinutes()-a._tzm),a._nextDay&&(a._a[id]=24)}}function ua(a){var b,c,d,e,f,g,h;b=a._w,null!=b.GG||null!=b.W||null!=b.E?(f=1,g=4,c=ra(b.GG,a._a[fd],ja(Da(),1,4).year),d=ra(b.W,1),e=ra(b.E,1)):(f=a._locale._week.dow,g=a._locale._week.doy,c=ra(b.gg,a._a[fd],ja(Da(),f,g).year),d=ra(b.w,1),null!=b.d?(e=b.d,f>e&&++d):e=null!=b.e?b.e+f:f),h=pa(c,d,e,g,f),a._a[fd]=h.year,a._dayOfYear=h.dayOfYear}function va(b){if(b._f===a.ISO_8601)return void ca(b);b._a=[],j(b).empty=!0;var c,d,e,f,g,h=""+b._i,i=h.length,k=0;for(e=L(b._f,b._locale).match(Nc)||[],c=0;c<e.length;c++)f=e[c],d=(h.match(O(f,b))||[])[0],d&&(g=h.substr(0,h.indexOf(d)),g.length>0&&j(b).unusedInput.push(g),h=h.slice(h.indexOf(d)+d.length),k+=d.length),Qc[f]?(d?j(b).empty=!1:j(b).unusedTokens.push(f),S(f,d,b)):b._strict&&!d&&j(b).unusedTokens.push(f);j(b).charsLeftOver=i-k,h.length>0&&j(b).unusedInput.push(h),j(b).bigHour===!0&&b._a[id]<=12&&b._a[id]>0&&(j(b).bigHour=void 0),b._a[id]=wa(b._locale,b._a[id],b._meridiem),ta(b),$(b)}function wa(a,b,c){var d;return null==c?b:null!=a.meridiemHour?a.meridiemHour(b,c):null!=a.isPM?(d=a.isPM(c),d&&12>b&&(b+=12),d||12!==b||(b=0),b):b}function xa(a){var b,c,d,e,f;if(0===a._f.length)return j(a).invalidFormat=!0,void(a._d=new Date(NaN));for(e=0;e<a._f.length;e++)f=0,b=m({},a),null!=a._useUTC&&(b._useUTC=a._useUTC),b._f=a._f[e],va(b),k(b)&&(f+=j(b).charsLeftOver,f+=10*j(b).unusedTokens.length,j(b).score=f,(null==d||d>f)&&(d=f,c=b));g(a,c||b)}function ya(a){if(!a._d){var b=B(a._i);a._a=[b.year,b.month,b.day||b.date,b.hour,b.minute,b.second,b.millisecond],ta(a)}}function za(a){var b=new n($(Aa(a)));return b._nextDay&&(b.add(1,"d"),b._nextDay=void 0),b}function Aa(a){var b=a._i,e=a._f;return a._locale=a._locale||y(a._l),null===b||void 0===e&&""===b?l({nullInput:!0}):("string"==typeof b&&(a._i=b=a._locale.preparse(b)),o(b)?new n($(b)):(c(e)?xa(a):e?va(a):d(b)?a._d=b:Ba(a),a))}function Ba(b){var f=b._i;void 0===f?b._d=new Date:d(f)?b._d=new Date(+f):"string"==typeof f?da(b):c(f)?(b._a=e(f.slice(0),function(a){return parseInt(a,10)}),ta(b)):"object"==typeof f?ya(b):"number"==typeof f?b._d=new Date(f):a.createFromInputFallback(b)}function Ca(a,b,c,d,e){var f={};return"boolean"==typeof c&&(d=c,c=void 0),f._isAMomentObject=!0,f._useUTC=f._isUTC=e,f._l=c,f._i=a,f._f=b,f._strict=d,za(f)}function Da(a,b,c,d){return Ca(a,b,c,d,!1)}function Ea(a,b){var d,e;if(1===b.length&&c(b[0])&&(b=b[0]),!b.length)return Da();for(d=b[0],e=1;e<b.length;++e)(!b[e].isValid()||b[e][a](d))&&(d=b[e]);return d}function Fa(){var a=[].slice.call(arguments,0);return Ea("isBefore",a)}function Ga(){var a=[].slice.call(arguments,0);return Ea("isAfter",a)}function Ha(a){var b=B(a),c=b.year||0,d=b.quarter||0,e=b.month||0,f=b.week||0,g=b.day||0,h=b.hour||0,i=b.minute||0,j=b.second||0,k=b.millisecond||0;this._milliseconds=+k+1e3*j+6e4*i+36e5*h,this._days=+g+7*f,this._months=+e+3*d+12*c,this._data={},this._locale=y(),this._bubble()}function Ia(a){return a instanceof Ha}function Ja(a,b){H(a,0,0,function(){var a=this.utcOffset(),c="+";return 0>a&&(a=-a,c="-"),c+G(~~(a/60),2)+b+G(~~a%60,2)})}function Ka(a){var b=(a||"").match(ad)||[],c=b[b.length-1]||[],d=(c+"").match(xd)||["-",0,0],e=+(60*d[1])+q(d[2]);return"+"===d[0]?e:-e}function La(b,c){var e,f;return c._isUTC?(e=c.clone(),f=(o(b)||d(b)?+b:+Da(b))-+e,e._d.setTime(+e._d+f),a.updateOffset(e,!1),e):Da(b).local()}function Ma(a){return 15*-Math.round(a._d.getTimezoneOffset()/15)}function Na(b,c){var d,e=this._offset||0;return null!=b?("string"==typeof b&&(b=Ka(b)),Math.abs(b)<16&&(b=60*b),!this._isUTC&&c&&(d=Ma(this)),this._offset=b,this._isUTC=!0,null!=d&&this.add(d,"m"),e!==b&&(!c||this._changeInProgress?bb(this,Ya(b-e,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,a.updateOffset(this,!0),this._changeInProgress=null)),this):this._isUTC?e:Ma(this)}function Oa(a,b){return null!=a?("string"!=typeof a&&(a=-a),this.utcOffset(a,b),this):-this.utcOffset()}function Pa(a){return this.utcOffset(0,a)}function Qa(a){return this._isUTC&&(this.utcOffset(0,a),this._isUTC=!1,a&&this.subtract(Ma(this),"m")),this}function Ra(){return this._tzm?this.utcOffset(this._tzm):"string"==typeof this._i&&this.utcOffset(Ka(this._i)),this}function Sa(a){return a=a?Da(a).utcOffset():0,(this.utcOffset()-a)%60===0}function Ta(){return this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset()}function Ua(){if("undefined"!=typeof this._isDSTShifted)return this._isDSTShifted;var a={};if(m(a,this),a=Aa(a),a._a){var b=a._isUTC?h(a._a):Da(a._a);this._isDSTShifted=this.isValid()&&r(a._a,b.toArray())>0}else this._isDSTShifted=!1;return this._isDSTShifted}function Va(){return!this._isUTC}function Wa(){return this._isUTC}function Xa(){return this._isUTC&&0===this._offset}function Ya(a,b){var c,d,e,g=a,h=null;return Ia(a)?g={ms:a._milliseconds,d:a._days,M:a._months}:"number"==typeof a?(g={},b?g[b]=a:g.milliseconds=a):(h=yd.exec(a))?(c="-"===h[1]?-1:1,g={y:0,d:q(h[hd])*c,h:q(h[id])*c,m:q(h[jd])*c,s:q(h[kd])*c,ms:q(h[ld])*c}):(h=zd.exec(a))?(c="-"===h[1]?-1:1,g={y:Za(h[2],c),M:Za(h[3],c),d:Za(h[4],c),h:Za(h[5],c),m:Za(h[6],c),s:Za(h[7],c),w:Za(h[8],c)}):null==g?g={}:"object"==typeof g&&("from"in g||"to"in g)&&(e=_a(Da(g.from),Da(g.to)),g={},g.ms=e.milliseconds,g.M=e.months),d=new Ha(g),Ia(a)&&f(a,"_locale")&&(d._locale=a._locale),d}function Za(a,b){var c=a&&parseFloat(a.replace(",","."));return(isNaN(c)?0:c)*b}function $a(a,b){var c={milliseconds:0,months:0};return c.months=b.month()-a.month()+12*(b.year()-a.year()),a.clone().add(c.months,"M").isAfter(b)&&--c.months,c.milliseconds=+b-+a.clone().add(c.months,"M"),c}function _a(a,b){var c;return b=La(b,a),a.isBefore(b)?c=$a(a,b):(c=$a(b,a),c.milliseconds=-c.milliseconds,c.months=-c.months),c}function ab(a,b){return function(c,d){var e,f;return null===d||isNaN(+d)||(ba(b,"moment()."+b+"(period, number) is deprecated. Please use moment()."+b+"(number, period)."),f=c,c=d,d=f),c="string"==typeof c?+c:c,e=Ya(c,d),bb(this,e,a),this}}function bb(b,c,d,e){var f=c._milliseconds,g=c._days,h=c._months;e=null==e?!0:e,f&&b._d.setTime(+b._d+f*d),g&&E(b,"Date",D(b,"Date")+g*d),h&&X(b,D(b,"Month")+h*d),e&&a.updateOffset(b,g||h)}function cb(a,b){var c=a||Da(),d=La(c,this).startOf("day"),e=this.diff(d,"days",!0),f=-6>e?"sameElse":-1>e?"lastWeek":0>e?"lastDay":1>e?"sameDay":2>e?"nextDay":7>e?"nextWeek":"sameElse";return this.format(b&&b[f]||this.localeData().calendar(f,this,Da(c)))}function db(){return new n(this)}function eb(a,b){var c;return b=A("undefined"!=typeof b?b:"millisecond"),"millisecond"===b?(a=o(a)?a:Da(a),+this>+a):(c=o(a)?+a:+Da(a),c<+this.clone().startOf(b))}function fb(a,b){var c;return b=A("undefined"!=typeof b?b:"millisecond"),"millisecond"===b?(a=o(a)?a:Da(a),+a>+this):(c=o(a)?+a:+Da(a),+this.clone().endOf(b)<c)}function gb(a,b,c){return this.isAfter(a,c)&&this.isBefore(b,c)}function hb(a,b){var c;return b=A(b||"millisecond"),"millisecond"===b?(a=o(a)?a:Da(a),+this===+a):(c=+Da(a),+this.clone().startOf(b)<=c&&c<=+this.clone().endOf(b))}function ib(a,b,c){var d,e,f=La(a,this),g=6e4*(f.utcOffset()-this.utcOffset());return b=A(b),"year"===b||"month"===b||"quarter"===b?(e=jb(this,f),"quarter"===b?e/=3:"year"===b&&(e/=12)):(d=this-f,e="second"===b?d/1e3:"minute"===b?d/6e4:"hour"===b?d/36e5:"day"===b?(d-g)/864e5:"week"===b?(d-g)/6048e5:d),c?e:p(e)}function jb(a,b){var c,d,e=12*(b.year()-a.year())+(b.month()-a.month()),f=a.clone().add(e,"months");return 0>b-f?(c=a.clone().add(e-1,"months"),d=(b-f)/(f-c)):(c=a.clone().add(e+1,"months"),d=(b-f)/(c-f)),-(e+d)}function kb(){return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")}function lb(){var a=this.clone().utc();return 0<a.year()&&a.year()<=9999?"function"==typeof Date.prototype.toISOString?this.toDate().toISOString():K(a,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"):K(a,"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")}function mb(b){var c=K(this,b||a.defaultFormat);return this.localeData().postformat(c)}function nb(a,b){return this.isValid()?Ya({to:this,from:a}).locale(this.locale()).humanize(!b):this.localeData().invalidDate()}function ob(a){return this.from(Da(),a)}function pb(a,b){return this.isValid()?Ya({from:this,to:a}).locale(this.locale()).humanize(!b):this.localeData().invalidDate()}function qb(a){return this.to(Da(),a)}function rb(a){var b;return void 0===a?this._locale._abbr:(b=y(a),null!=b&&(this._locale=b),this)}function sb(){return this._locale}function tb(a){switch(a=A(a)){case"year":this.month(0);case"quarter":case"month":this.date(1);case"week":case"isoWeek":case"day":this.hours(0);case"hour":this.minutes(0);case"minute":this.seconds(0);case"second":this.milliseconds(0)}return"week"===a&&this.weekday(0),"isoWeek"===a&&this.isoWeekday(1),"quarter"===a&&this.month(3*Math.floor(this.month()/3)),this}function ub(a){return a=A(a),void 0===a||"millisecond"===a?this:this.startOf(a).add(1,"isoWeek"===a?"week":a).subtract(1,"ms")}function vb(){return+this._d-6e4*(this._offset||0)}function wb(){return Math.floor(+this/1e3)}function xb(){return this._offset?new Date(+this):this._d}function yb(){var a=this;return[a.year(),a.month(),a.date(),a.hour(),a.minute(),a.second(),a.millisecond()]}function zb(){var a=this;return{years:a.year(),months:a.month(),date:a.date(),hours:a.hours(),minutes:a.minutes(),seconds:a.seconds(),milliseconds:a.milliseconds()}}function Ab(){return k(this)}function Bb(){return g({},j(this))}function Cb(){return j(this).overflow}function Db(a,b){H(0,[a,a.length],0,b)}function Eb(a,b,c){return ja(Da([a,11,31+b-c]),b,c).week}function Fb(a){var b=ja(this,this.localeData()._week.dow,this.localeData()._week.doy).year;return null==a?b:this.add(a-b,"y")}function Gb(a){var b=ja(this,1,4).year;return null==a?b:this.add(a-b,"y")}function Hb(){return Eb(this.year(),1,4)}function Ib(){var a=this.localeData()._week;return Eb(this.year(),a.dow,a.doy)}function Jb(a){return null==a?Math.ceil((this.month()+1)/3):this.month(3*(a-1)+this.month()%3)}function Kb(a,b){return"string"!=typeof a?a:isNaN(a)?(a=b.weekdaysParse(a),"number"==typeof a?a:null):parseInt(a,10)}function Lb(a){return this._weekdays[a.day()]}function Mb(a){return this._weekdaysShort[a.day()]}function Nb(a){return this._weekdaysMin[a.day()]}function Ob(a){var b,c,d;for(this._weekdaysParse=this._weekdaysParse||[],b=0;7>b;b++)if(this._weekdaysParse[b]||(c=Da([2e3,1]).day(b),d="^"+this.weekdays(c,"")+"|^"+this.weekdaysShort(c,"")+"|^"+this.weekdaysMin(c,""),this._weekdaysParse[b]=new RegExp(d.replace(".",""),"i")),this._weekdaysParse[b].test(a))return b}function Pb(a){var b=this._isUTC?this._d.getUTCDay():this._d.getDay();return null!=a?(a=Kb(a,this.localeData()),this.add(a-b,"d")):b}function Qb(a){var b=(this.day()+7-this.localeData()._week.dow)%7;return null==a?b:this.add(a-b,"d")}function Rb(a){return null==a?this.day()||7:this.day(this.day()%7?a:a-7)}function Sb(a,b){H(a,0,0,function(){return this.localeData().meridiem(this.hours(),this.minutes(),b)})}function Tb(a,b){return b._meridiemParse}function Ub(a){return"p"===(a+"").toLowerCase().charAt(0)}function Vb(a,b,c){return a>11?c?"pm":"PM":c?"am":"AM"}function Wb(a,b){b[ld]=q(1e3*("0."+a))}function Xb(){return this._isUTC?"UTC":""}function Yb(){return this._isUTC?"Coordinated Universal Time":""}function Zb(a){return Da(1e3*a)}function $b(){return Da.apply(null,arguments).parseZone()}function _b(a,b,c){var d=this._calendar[a];return"function"==typeof d?d.call(b,c):d}function ac(a){var b=this._longDateFormat[a],c=this._longDateFormat[a.toUpperCase()];return b||!c?b:(this._longDateFormat[a]=c.replace(/MMMM|MM|DD|dddd/g,function(a){return a.slice(1)}),this._longDateFormat[a])}function bc(){return this._invalidDate}function cc(a){return this._ordinal.replace("%d",a)}function dc(a){return a}function ec(a,b,c,d){var e=this._relativeTime[c];return"function"==typeof e?e(a,b,c,d):e.replace(/%d/i,a)}function fc(a,b){var c=this._relativeTime[a>0?"future":"past"];return"function"==typeof c?c(b):c.replace(/%s/i,b)}function gc(a){var b,c;for(c in a)b=a[c],"function"==typeof b?this[c]=b:this["_"+c]=b;this._ordinalParseLenient=new RegExp(this._ordinalParse.source+"|"+/\d{1,2}/.source)}function hc(a,b,c,d){var e=y(),f=h().set(d,b);return e[c](f,a)}function ic(a,b,c,d,e){if("number"==typeof a&&(b=a,a=void 0),a=a||"",null!=b)return hc(a,b,c,e);var f,g=[];for(f=0;d>f;f++)g[f]=hc(a,f,c,e);return g}function jc(a,b){return ic(a,b,"months",12,"month")}function kc(a,b){return ic(a,b,"monthsShort",12,"month")}function lc(a,b){return ic(a,b,"weekdays",7,"day")}function mc(a,b){return ic(a,b,"weekdaysShort",7,"day")}function nc(a,b){return ic(a,b,"weekdaysMin",7,"day")}function oc(){var a=this._data;return this._milliseconds=Wd(this._milliseconds),this._days=Wd(this._days),this._months=Wd(this._months),a.milliseconds=Wd(a.milliseconds),a.seconds=Wd(a.seconds),a.minutes=Wd(a.minutes),a.hours=Wd(a.hours),a.months=Wd(a.months),a.years=Wd(a.years),this}function pc(a,b,c,d){var e=Ya(b,c);return a._milliseconds+=d*e._milliseconds,a._days+=d*e._days,a._months+=d*e._months,a._bubble()}function qc(a,b){return pc(this,a,b,1)}function rc(a,b){return pc(this,a,b,-1)}function sc(a){return 0>a?Math.floor(a):Math.ceil(a)}function tc(){var a,b,c,d,e,f=this._milliseconds,g=this._days,h=this._months,i=this._data;return f>=0&&g>=0&&h>=0||0>=f&&0>=g&&0>=h||(f+=864e5*sc(vc(h)+g),g=0,h=0),i.milliseconds=f%1e3,a=p(f/1e3),i.seconds=a%60,b=p(a/60),i.minutes=b%60,c=p(b/60),i.hours=c%24,g+=p(c/24),e=p(uc(g)),h+=e,g-=sc(vc(e)),d=p(h/12),h%=12,i.days=g,i.months=h,i.years=d,this}function uc(a){return 4800*a/146097}function vc(a){return 146097*a/4800}function wc(a){var b,c,d=this._milliseconds;if(a=A(a),"month"===a||"year"===a)return b=this._days+d/864e5,c=this._months+uc(b),"month"===a?c:c/12;switch(b=this._days+Math.round(vc(this._months)),a){case"week":return b/7+d/6048e5;case"day":return b+d/864e5;case"hour":return 24*b+d/36e5;case"minute":return 1440*b+d/6e4;case"second":return 86400*b+d/1e3;case"millisecond":return Math.floor(864e5*b)+d;default:throw new Error("Unknown unit "+a)}}function xc(){return this._milliseconds+864e5*this._days+this._months%12*2592e6+31536e6*q(this._months/12)}function yc(a){return function(){return this.as(a)}}function zc(a){return a=A(a),this[a+"s"]()}function Ac(a){return function(){return this._data[a]}}function Bc(){return p(this.days()/7)}function Cc(a,b,c,d,e){return e.relativeTime(b||1,!!c,a,d)}function Dc(a,b,c){var d=Ya(a).abs(),e=ke(d.as("s")),f=ke(d.as("m")),g=ke(d.as("h")),h=ke(d.as("d")),i=ke(d.as("M")),j=ke(d.as("y")),k=e<le.s&&["s",e]||1===f&&["m"]||f<le.m&&["mm",f]||1===g&&["h"]||g<le.h&&["hh",g]||1===h&&["d"]||h<le.d&&["dd",h]||1===i&&["M"]||i<le.M&&["MM",i]||1===j&&["y"]||["yy",j];return k[2]=b,k[3]=+a>0,k[4]=c,Cc.apply(null,k)}function Ec(a,b){return void 0===le[a]?!1:void 0===b?le[a]:(le[a]=b,!0)}function Fc(a){var b=this.localeData(),c=Dc(this,!a,b);return a&&(c=b.pastFuture(+this,c)),b.postformat(c)}function Gc(){var a,b,c,d=me(this._milliseconds)/1e3,e=me(this._days),f=me(this._months);a=p(d/60),b=p(a/60),d%=60,a%=60,c=p(f/12),f%=12;var g=c,h=f,i=e,j=b,k=a,l=d,m=this.asSeconds();return m?(0>m?"-":"")+"P"+(g?g+"Y":"")+(h?h+"M":"")+(i?i+"D":"")+(j||k||l?"T":"")+(j?j+"H":"")+(k?k+"M":"")+(l?l+"S":""):"P0D"}var Hc,Ic,Jc=a.momentProperties=[],Kc=!1,Lc={},Mc={},Nc=/(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Q|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,Oc=/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,Pc={},Qc={},Rc=/\d/,Sc=/\d\d/,Tc=/\d{3}/,Uc=/\d{4}/,Vc=/[+-]?\d{6}/,Wc=/\d\d?/,Xc=/\d{1,3}/,Yc=/\d{1,4}/,Zc=/[+-]?\d{1,6}/,$c=/\d+/,_c=/[+-]?\d+/,ad=/Z|[+-]\d\d:?\d\d/gi,bd=/[+-]?\d+(\.\d{1,3})?/,cd=/[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i,dd={},ed={},fd=0,gd=1,hd=2,id=3,jd=4,kd=5,ld=6;H("M",["MM",2],"Mo",function(){return this.month()+1}),H("MMM",0,0,function(a){return this.localeData().monthsShort(this,a)}),H("MMMM",0,0,function(a){return this.localeData().months(this,a)}),z("month","M"),N("M",Wc),N("MM",Wc,Sc),N("MMM",cd),N("MMMM",cd),Q(["M","MM"],function(a,b){b[gd]=q(a)-1}),Q(["MMM","MMMM"],function(a,b,c,d){var e=c._locale.monthsParse(a,d,c._strict);null!=e?b[gd]=e:j(c).invalidMonth=a});var md="January_February_March_April_May_June_July_August_September_October_November_December".split("_"),nd="Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),od={};a.suppressDeprecationWarnings=!1;var pd=/^\s*(?:[+-]\d{6}|\d{4})-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/,qd=[["YYYYYY-MM-DD",/[+-]\d{6}-\d{2}-\d{2}/],["YYYY-MM-DD",/\d{4}-\d{2}-\d{2}/],["GGGG-[W]WW-E",/\d{4}-W\d{2}-\d/],["GGGG-[W]WW",/\d{4}-W\d{2}/],["YYYY-DDD",/\d{4}-\d{3}/]],rd=[["HH:mm:ss.SSSS",/(T| )\d\d:\d\d:\d\d\.\d+/],["HH:mm:ss",/(T| )\d\d:\d\d:\d\d/],["HH:mm",/(T| )\d\d:\d\d/],["HH",/(T| )\d\d/]],sd=/^\/?Date\((\-?\d+)/i;a.createFromInputFallback=aa("moment construction falls back to js Date. This is discouraged and will be removed in upcoming major release. Please refer to https://github.com/moment/moment/issues/1407 for more info.",function(a){a._d=new Date(a._i+(a._useUTC?" UTC":""))}),H(0,["YY",2],0,function(){return this.year()%100}),H(0,["YYYY",4],0,"year"),H(0,["YYYYY",5],0,"year"),H(0,["YYYYYY",6,!0],0,"year"),z("year","y"),N("Y",_c),N("YY",Wc,Sc),N("YYYY",Yc,Uc),N("YYYYY",Zc,Vc),N("YYYYYY",Zc,Vc),Q(["YYYYY","YYYYYY"],fd),Q("YYYY",function(b,c){c[fd]=2===b.length?a.parseTwoDigitYear(b):q(b)}),Q("YY",function(b,c){c[fd]=a.parseTwoDigitYear(b)}),a.parseTwoDigitYear=function(a){return q(a)+(q(a)>68?1900:2e3)};var td=C("FullYear",!1);H("w",["ww",2],"wo","week"),H("W",["WW",2],"Wo","isoWeek"),z("week","w"),z("isoWeek","W"),N("w",Wc),N("ww",Wc,Sc),N("W",Wc),N("WW",Wc,Sc),R(["w","ww","W","WW"],function(a,b,c,d){b[d.substr(0,1)]=q(a)});var ud={dow:0,doy:6};H("DDD",["DDDD",3],"DDDo","dayOfYear"),z("dayOfYear","DDD"),N("DDD",Xc),N("DDDD",Tc),Q(["DDD","DDDD"],function(a,b,c){c._dayOfYear=q(a)}),a.ISO_8601=function(){};var vd=aa("moment().min is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548",function(){var a=Da.apply(null,arguments);return this>a?this:a}),wd=aa("moment().max is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548",function(){var a=Da.apply(null,arguments);return a>this?this:a});Ja("Z",":"),Ja("ZZ",""),N("Z",ad),N("ZZ",ad),Q(["Z","ZZ"],function(a,b,c){c._useUTC=!0,c._tzm=Ka(a)});var xd=/([\+\-]|\d\d)/gi;a.updateOffset=function(){};var yd=/(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/,zd=/^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/;Ya.fn=Ha.prototype;var Ad=ab(1,"add"),Bd=ab(-1,"subtract");a.defaultFormat="YYYY-MM-DDTHH:mm:ssZ";var Cd=aa("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.",function(a){return void 0===a?this.localeData():this.locale(a)});H(0,["gg",2],0,function(){return this.weekYear()%100}),H(0,["GG",2],0,function(){return this.isoWeekYear()%100}),Db("gggg","weekYear"),Db("ggggg","weekYear"),Db("GGGG","isoWeekYear"),Db("GGGGG","isoWeekYear"),z("weekYear","gg"),z("isoWeekYear","GG"),N("G",_c),N("g",_c),N("GG",Wc,Sc),N("gg",Wc,Sc),N("GGGG",Yc,Uc),N("gggg",Yc,Uc),N("GGGGG",Zc,Vc),N("ggggg",Zc,Vc),R(["gggg","ggggg","GGGG","GGGGG"],function(a,b,c,d){b[d.substr(0,2)]=q(a)}),R(["gg","GG"],function(b,c,d,e){c[e]=a.parseTwoDigitYear(b)}),H("Q",0,0,"quarter"),z("quarter","Q"),N("Q",Rc),Q("Q",function(a,b){b[gd]=3*(q(a)-1)}),H("D",["DD",2],"Do","date"),z("date","D"),N("D",Wc),N("DD",Wc,Sc),N("Do",function(a,b){return a?b._ordinalParse:b._ordinalParseLenient}),Q(["D","DD"],hd),Q("Do",function(a,b){b[hd]=q(a.match(Wc)[0],10)});var Dd=C("Date",!0);H("d",0,"do","day"),H("dd",0,0,function(a){return this.localeData().weekdaysMin(this,a)}),H("ddd",0,0,function(a){return this.localeData().weekdaysShort(this,a)}),H("dddd",0,0,function(a){return this.localeData().weekdays(this,a)}),H("e",0,0,"weekday"),H("E",0,0,"isoWeekday"),z("day","d"),z("weekday","e"),z("isoWeekday","E"),N("d",Wc),N("e",Wc),N("E",Wc),N("dd",cd),N("ddd",cd),N("dddd",cd),R(["dd","ddd","dddd"],function(a,b,c){var d=c._locale.weekdaysParse(a);null!=d?b.d=d:j(c).invalidWeekday=a}),R(["d","e","E"],function(a,b,c,d){b[d]=q(a)});var Ed="Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),Fd="Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),Gd="Su_Mo_Tu_We_Th_Fr_Sa".split("_");H("H",["HH",2],0,"hour"),H("h",["hh",2],0,function(){return this.hours()%12||12}),Sb("a",!0),Sb("A",!1),z("hour","h"),N("a",Tb),N("A",Tb),N("H",Wc),N("h",Wc),N("HH",Wc,Sc),N("hh",Wc,Sc),Q(["H","HH"],id),Q(["a","A"],function(a,b,c){c._isPm=c._locale.isPM(a),c._meridiem=a}),Q(["h","hh"],function(a,b,c){b[id]=q(a),j(c).bigHour=!0});var Hd=/[ap]\.?m?\.?/i,Id=C("Hours",!0);H("m",["mm",2],0,"minute"),z("minute","m"),N("m",Wc),N("mm",Wc,Sc),Q(["m","mm"],jd);var Jd=C("Minutes",!1);H("s",["ss",2],0,"second"),z("second","s"),N("s",Wc),N("ss",Wc,Sc),Q(["s","ss"],kd);var Kd=C("Seconds",!1);H("S",0,0,function(){return~~(this.millisecond()/100)}),H(0,["SS",2],0,function(){return~~(this.millisecond()/10)}),H(0,["SSS",3],0,"millisecond"),H(0,["SSSS",4],0,function(){return 10*this.millisecond()}),H(0,["SSSSS",5],0,function(){return 100*this.millisecond()}),H(0,["SSSSSS",6],0,function(){return 1e3*this.millisecond()}),H(0,["SSSSSSS",7],0,function(){return 1e4*this.millisecond()}),H(0,["SSSSSSSS",8],0,function(){return 1e5*this.millisecond()}),H(0,["SSSSSSSSS",9],0,function(){return 1e6*this.millisecond()}),z("millisecond","ms"),N("S",Xc,Rc),N("SS",Xc,Sc),N("SSS",Xc,Tc);var Ld;for(Ld="SSSS";Ld.length<=9;Ld+="S")N(Ld,$c);for(Ld="S";Ld.length<=9;Ld+="S")Q(Ld,Wb);var Md=C("Milliseconds",!1);H("z",0,0,"zoneAbbr"),H("zz",0,0,"zoneName");var Nd=n.prototype;Nd.add=Ad,Nd.calendar=cb,Nd.clone=db,Nd.diff=ib,Nd.endOf=ub,Nd.format=mb,Nd.from=nb,Nd.fromNow=ob,Nd.to=pb,Nd.toNow=qb,Nd.get=F,Nd.invalidAt=Cb,Nd.isAfter=eb,Nd.isBefore=fb,Nd.isBetween=gb,Nd.isSame=hb,Nd.isValid=Ab,Nd.lang=Cd,Nd.locale=rb,Nd.localeData=sb,Nd.max=wd,Nd.min=vd,Nd.parsingFlags=Bb,Nd.set=F,Nd.startOf=tb,Nd.subtract=Bd,Nd.toArray=yb,Nd.toObject=zb,Nd.toDate=xb,Nd.toISOString=lb,Nd.toJSON=lb,Nd.toString=kb,Nd.unix=wb,Nd.valueOf=vb,Nd.year=td,Nd.isLeapYear=ia,Nd.weekYear=Fb,Nd.isoWeekYear=Gb,Nd.quarter=Nd.quarters=Jb,Nd.month=Y,Nd.daysInMonth=Z,Nd.week=Nd.weeks=na,Nd.isoWeek=Nd.isoWeeks=oa,Nd.weeksInYear=Ib,Nd.isoWeeksInYear=Hb,Nd.date=Dd,Nd.day=Nd.days=Pb,Nd.weekday=Qb,Nd.isoWeekday=Rb,Nd.dayOfYear=qa,Nd.hour=Nd.hours=Id,Nd.minute=Nd.minutes=Jd,Nd.second=Nd.seconds=Kd,
Nd.millisecond=Nd.milliseconds=Md,Nd.utcOffset=Na,Nd.utc=Pa,Nd.local=Qa,Nd.parseZone=Ra,Nd.hasAlignedHourOffset=Sa,Nd.isDST=Ta,Nd.isDSTShifted=Ua,Nd.isLocal=Va,Nd.isUtcOffset=Wa,Nd.isUtc=Xa,Nd.isUTC=Xa,Nd.zoneAbbr=Xb,Nd.zoneName=Yb,Nd.dates=aa("dates accessor is deprecated. Use date instead.",Dd),Nd.months=aa("months accessor is deprecated. Use month instead",Y),Nd.years=aa("years accessor is deprecated. Use year instead",td),Nd.zone=aa("moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779",Oa);var Od=Nd,Pd={sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"},Qd={LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},Rd="Invalid date",Sd="%d",Td=/\d{1,2}/,Ud={future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"},Vd=s.prototype;Vd._calendar=Pd,Vd.calendar=_b,Vd._longDateFormat=Qd,Vd.longDateFormat=ac,Vd._invalidDate=Rd,Vd.invalidDate=bc,Vd._ordinal=Sd,Vd.ordinal=cc,Vd._ordinalParse=Td,Vd.preparse=dc,Vd.postformat=dc,Vd._relativeTime=Ud,Vd.relativeTime=ec,Vd.pastFuture=fc,Vd.set=gc,Vd.months=U,Vd._months=md,Vd.monthsShort=V,Vd._monthsShort=nd,Vd.monthsParse=W,Vd.week=ka,Vd._week=ud,Vd.firstDayOfYear=ma,Vd.firstDayOfWeek=la,Vd.weekdays=Lb,Vd._weekdays=Ed,Vd.weekdaysMin=Nb,Vd._weekdaysMin=Gd,Vd.weekdaysShort=Mb,Vd._weekdaysShort=Fd,Vd.weekdaysParse=Ob,Vd.isPM=Ub,Vd._meridiemParse=Hd,Vd.meridiem=Vb,w("en",{ordinalParse:/\d{1,2}(th|st|nd|rd)/,ordinal:function(a){var b=a%10,c=1===q(a%100/10)?"th":1===b?"st":2===b?"nd":3===b?"rd":"th";return a+c}}),a.lang=aa("moment.lang is deprecated. Use moment.locale instead.",w),a.langData=aa("moment.langData is deprecated. Use moment.localeData instead.",y);var Wd=Math.abs,Xd=yc("ms"),Yd=yc("s"),Zd=yc("m"),$d=yc("h"),_d=yc("d"),ae=yc("w"),be=yc("M"),ce=yc("y"),de=Ac("milliseconds"),ee=Ac("seconds"),fe=Ac("minutes"),ge=Ac("hours"),he=Ac("days"),ie=Ac("months"),je=Ac("years"),ke=Math.round,le={s:45,m:45,h:22,d:26,M:11},me=Math.abs,ne=Ha.prototype;ne.abs=oc,ne.add=qc,ne.subtract=rc,ne.as=wc,ne.asMilliseconds=Xd,ne.asSeconds=Yd,ne.asMinutes=Zd,ne.asHours=$d,ne.asDays=_d,ne.asWeeks=ae,ne.asMonths=be,ne.asYears=ce,ne.valueOf=xc,ne._bubble=tc,ne.get=zc,ne.milliseconds=de,ne.seconds=ee,ne.minutes=fe,ne.hours=ge,ne.days=he,ne.weeks=Bc,ne.months=ie,ne.years=je,ne.humanize=Fc,ne.toISOString=Gc,ne.toString=Gc,ne.toJSON=Gc,ne.locale=rb,ne.localeData=sb,ne.toIsoString=aa("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)",Gc),ne.lang=Cd,H("X",0,0,"unix"),H("x",0,0,"valueOf"),N("x",_c),N("X",bd),Q("X",function(a,b,c){c._d=new Date(1e3*parseFloat(a,10))}),Q("x",function(a,b,c){c._d=new Date(q(a))}),a.version="2.10.6",b(Da),a.fn=Od,a.min=Fa,a.max=Ga,a.utc=h,a.unix=Zb,a.months=jc,a.isDate=d,a.locale=w,a.invalid=l,a.duration=Ya,a.isMoment=o,a.weekdays=lc,a.parseZone=$b,a.localeData=y,a.isDuration=Ia,a.monthsShort=kc,a.weekdaysMin=nc,a.defineLocale=x,a.weekdaysShort=mc,a.normalizeUnits=A,a.relativeTimeThreshold=Ec;var oe=a;return oe});
/* 
 * 1、获取和处理页面数据
 * 
*/
define('module_calendarBf/js/calendarFunc',['jquery', './moment.min'], function($, moment) {
	// 生成随机码 参数为随机码位数


	var InputInf = {
		// 生成随机数
		randomString: function(len) {　　
			len = len || 32;　　
			var $chars = '0123456789'; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/ 　　
			var maxPos = $chars.length;　　
			var pwd = '';　　
			for (i = 0; i < len; i++) {　　　　
				pwd += $chars.charAt(Math.floor(Math.random() * maxPos));　　
			}　　
			return pwd;
		},

		// 计算两个日期 之间的 天数，并返回一个字符串 格式 2015-10-09&201510-08
		calcDate: function(dateStart, dateEnd) {

			var returnArr = [dateStart];
			if (dateStart === dateEnd) {
				return returnArr[0];
			}

			var startArr = dateStart.split('-');
			var endArr = dateEnd.split('-');

			var theDateStart = new Date(parseInt(startArr[0]), parseInt(startArr[1]) - 1, parseInt(startArr[2]));
			var theDateEnd = new Date(parseInt(endArr[0]), parseInt(endArr[1]) - 1, parseInt(endArr[2]));

			var endTime = theDateEnd.getTime();
			var startTime = theDateStart.getTime();
			var i = 1;

			var newDate = new Date(startTime + 1000 * 60 * 60 * 24);

			while (newDate.getTime() < theDateEnd.getTime()) {
				var showMonth = (newDate.getMonth() + 1) > 9 ? (newDate.getMonth() + 1) : '0' + (newDate.getMonth() + 1);
				var showDay = newDate.getDate() > 9 ? newDate.getDate() : '0' + newDate.getDate();

				returnArr.push(newDate.getFullYear() + '-' + showMonth + '-' + showDay);
				i++;
				newDate = new Date(startTime + 1000 * 60 * 60 * 24 * i);
			}
			returnArr.push(dateEnd);
			console.log(returnArr);

			return returnArr.join("&");
		},

		// 根据时间对象 生成 2015-1-5 9：00 的时间字符串
		getTimeString: function(num) {
			var timeObj = new Date(num);
			return timeObj.getFullYear() + "-" + this.calcTen((timeObj.getMonth() + 1)) + "-" + this.calcTen(timeObj.getDate()) + " " + this.calcTen(timeObj.getHours()) + ":" + this.calcTen(timeObj.getMinutes());
		},

		// 处理获取到的时间
		conductTime: function(time) {
			var date = time.split(" ");
			var timeArr = date[0].split("-");
			var timeArr_t = date[1].split(":");
			var returnObj = {};
			return returnObj = {
				year: timeArr[0],
				month: timeArr[1],
				date: timeArr[2],
				hour: timeArr_t[0],
				mins: timeArr_t[1]
			}
		},

		// 生成 事件对象
		createTimeObj: function(time) {
			var obj = this.conductTime(time);
			return new Date(obj.year, obj.month - 1, obj.date, obj.hour, obj.mins, 0);
		},

		// 小于 10 的数 加0   9 -> 09
		calcTen: function(num) {
			return num < 10 ? "0" + num : num;
		},

		
		// 把 年月日 时分秒 加起来
		calcOrderTime: function(time) {
			var arr = time.split(' ');
			return parseInt(arr[0].split('-')[0] + arr[0].split('-')[1] + arr[0].split('-')[2] + arr[1].split(':')[0] + arr[1].split(':')[1]);
		},
		// 获取 页面数据返回到 theObj
		// num 为 id 的位数 
		// remindMark 为 事件的统一的id
		// mark 为 实例的id
		getPageInf: function(pageId, remindMark) {
			var theObj = {};
			var $page = $('#' + pageId);

			theObj.address = $page.find("#address").val();
			theObj.title = $page.find("#tittle").val();
			if ($page.find("#idAllDay").hasClass('active')) {
				theObj.allDay = "true";
				theObj.orderAllday = 0;
			} else {
				theObj.allDay = "false";
				theObj.orderAllday = 1;
			}

			theObj.remind = $page.find("#remind").data('type');
			theObj.repeat = $page.find("#repeat").data('type');

			theObj.remarks = $page.find("#remarks").val();
			theObj.mark = this.randomString(8);

			// 每次点击保存时，该值 会更新。 重复事件的 统一的 标志
			theObj.remindMark = remindMark;

			theObj.startTime = $page.find("#startTime").val();
			theObj.orderStart = this.calcOrderTime($page.find("#startTime").val());
			theObj.orderEnd = this.calcOrderTime($page.find("#endTime").val());
			theObj.endTime = $page.find("#endTime").val();
			theObj.thingEndTime = $page.find("#thingEndTime").val();

			return theObj;
		},

		// 获取 页面数据返回到 thing
		// num 为 id 的位数 
		// remindMark 为 事件的统一的id
		// mark 为 实例的id
		getThingInf: function(pageId, remindMark) {
			var thing = {};
			var $page = $('#' + pageId);

			thing.address = $page.find("#address").val();
			thing.title = $page.find("#tittle").val();
			if ($page.find("#idAllDay").hasClass('active')) {
				thing.allDay = true;
				thing.orderAllday = 0;
			} else {
				thing.allDay = false;
				thing.orderAllday = 1;
			}

			thing.remind = $page.find("#remind").data('type');
			thing.repeat = $page.find("#repeat").data('type');

			thing.remarks = $page.find("#remarks").val();
			//thing.mark = this.randomString(8);

			// 每次点击保存时，该值 会更新。 重复事件的 统一的 标志
			//thing.remindMark = remindMark;

			thing.startTime = moment($page.find("#startTime").val()).unix();
			//thing.orderStart = this.calcOrderTime($page.find("#startTime").val());
			//thing.orderEnd = this.calcOrderTime($page.find("#endTime").val());
			thing.endTime = moment($page.find("#endTime").val()).unix();
			thing.thingEndTime = $page.find("#thingEndTime").val() != '' ? moment($page.find("#thingEndTime").val()).unix() : 0;
			thing.remindMark = remindMark;
			thing.modifyids = '';
			return thing;
		},

	

		// 计算重复 复制的 开始时间和结束时间
		// var repeatArrText = ["永不", "每天", "每周", "每两周", "每月", "每年"];
		getRepeatDate: function(repeatype, start, end) {
			var Func = this;
			var returnObj = {
				startTime: [],
				endTime: []
			};

			var startObj = Func.createTimeObj(start);
			var endObj = Func.createTimeObj(end);

			switch (repeatype) {
				case 1:
					for (var i = 0; i < 180; i++) {
						returnObj.startTime.push(Func.getTimeString(startObj.getTime() + 1000 * 60 * 60 * 24 * i));
						returnObj.endTime.push(Func.getTimeString(endObj.getTime() + 1000 * 60 * 60 * 24 * i));
					}
					break;
				case 2:
					for (var i = 0; i < 60; i++) {
						var y = startObj
						returnObj.startTime.push(Func.getTimeString(startObj.getTime() + 1000 * 60 * 60 * 24 * 7 * i));
						returnObj.endTime.push(Func.getTimeString(endObj.getTime() + 1000 * 60 * 60 * 24 * 7 * i));
					}
					break;
				case 3:
					for (var i = 0; i < 60; i++) {
						returnObj.startTime.push(Func.getTimeString(startObj.getTime() + 1000 * 60 * 60 * 24 * 14 * i));
						returnObj.endTime.push(Func.getTimeString(endObj.getTime() + 1000 * 60 * 60 * 24 * 14 * i));
					}
					break;
				case 4:
					var startObjM = this.conductTime(start);
					var startObjMY = startObjM.year;
					var startObjMM = startObjM.month;
					var startObjMD = startObjM.date;
					var startObjMH = startObjM.hour;
					var startObjMMi = startObjM.mins;
					if (startObjMM == 12) {
						startObjMM = 0
					};
					for (var i = 0; i < 60; i++) {

						var monthLastDate = this.getMonthWeek(startObjMY, startObjMM);

						if (startObjMM > 0 && startObjMM < 10) {
							startObjMMon = "0" + startObjMM;
						} else if (startObjMM == 0) {
							startObjMMon = 12;
						} else {
							startObjMMon = startObjMM;
						};
						monthLastDate = monthLastDate[2];
						/*
						在下面判断每月的29/30/31是否可设置，并选择最后一天作为重复事件
						如果不需要将在没有的日期改为最后一天，则不要 【else】;
						 */
						if (monthLastDate >= startObjMD) {
							startObjMDay = startObjMD;
						} else {
							startObjMDay = monthLastDate;
						};
						returnObj.startTime.push(startObjMY + "-" + startObjMMon + "-" + startObjMDay + " " + startObjMH + ":" + startObjMMi);
						if (startObjMM > 11) {
							startObjMM = 0;
						};
						startObjMM++;
						if (startObjMM == 1) {
							startObjMY++;
						};
					};
					var endObjM = this.conductTime(end);
					var endObjMY = endObjM.year;
					var endObjMM = endObjM.month;
					var endObjMD = endObjM.date;
					var endObjMH = endObjM.hour;
					var endObjMMi = endObjM.mins;
					if (endObjMM == 12) {
						endObjMM = 0
					};
					for (var i = 0; i < 60; i++) {
						var monthLastDate = this.getMonthWeek(endObjMY, endObjMM);
						if (endObjMM > 0 && endObjMM < 10) {
							endObjMMon = "0" + endObjMM;
						} else if (endObjMM == 0) {
							endObjMMon = 12;
						} else {
							endObjMMon = endObjMM;
						};
						monthLastDate = monthLastDate[2];
						/*
						在下面判断每月的29/30/31是否可设置，并选择最后一天作为重复事件-刘攀
						如果不需要将在没有的日期改为最后一天，则不要 【else】;
						 */
						if (monthLastDate >= endObjMD) {
							endObjMDay = endObjMD;
						} else {
							endObjMDay = monthLastDate;
						};
						returnObj.endTime.push(endObjMY + "-" + endObjMMon + "-" + endObjMDay + " " + endObjMH + ":" + endObjMMi);
						if (endObjMM > 11) {
							endObjMM = 0;
						};
						endObjMM++;
						if (endObjMM == 1) {
							endObjMY++;
						};
					};
					break;
				case 5:
					var startObjM = this.conductTime(start);
					var startObjMY = startObjM.year;
					var startObjMM = startObjM.month;
					var startObjMD = startObjM.date;
					var startObjMH = startObjM.hour;
					var startObjMMi = startObjM.mins;
					if (startObjMM == 12) {
						startObjMM = 0
					};
					if (startObjMM > 0 && startObjMM < 10) {
						startObjMMon = "0" + startObjMM;
					} else if (startObjMM == 0) {
						startObjMMon = 12;
					} else {
						startObjMMon = startObjMM;
					};
					for (var i = 0; i < 60; i++) {
						var monthLastDate = this.getMonthWeek(startObjMY, startObjMM);
						monthLastDate = monthLastDate[2];
						/*
						在下面判断每月的29/30/31是否可设置，并选择最后一天作为重复事件
						如果不需要将在没有的日期改为最后一天，则不要 【else】;
						 */
						if (monthLastDate >= startObjMD) {
							startObjMDay = startObjMD;
						} else {
							startObjMDay = monthLastDate;
						};
						returnObj.startTime.push(startObjMY + "-" + startObjMMon + "-" + startObjMDay + " " + startObjMH + ":" + startObjMMi);
						startObjMY++;
					};
					var endObjM = this.conductTime(end);
					var endObjMY = endObjM.year;
					var endObjMM = endObjM.month;
					var endObjMD = endObjM.date;
					var endObjMH = endObjM.hour;
					var endObjMMi = endObjM.mins;
					if (endObjMM == 12) {
						endObjMM = 0
					};
					if (endObjMM > 0 && endObjMM < 10) {
						endObjMMon = "0" + endObjMM;
					} else if (endObjMM == 0) {
						endObjMMon = 12;
					} else {
						endObjMMon = endObjMM;
					};
					for (var i = 0; i < 60; i++) {
						var monthLastDate = this.getMonthWeek(endObjMY, endObjMM);
						monthLastDate = monthLastDate[2];
						/*
						在下面判断每月的29/30/31是否可设置，并选择最后一天作为重复事件
						如果不需要将在没有的日期改为最后一天，则不要 【else】;
						 */
						if (monthLastDate >= endObjMD) {
							endObjMDay = endObjMD;
						} else {
							endObjMDay = monthLastDate;
						};
						returnObj.endTime.push(endObjMY + "-" + endObjMMon + "-" + endObjMDay + " " + endObjMH + ":" + endObjMMi);
						endObjMY++;
					};
					break;
			}
			//alert(JSON.stringify(returnObj))
			return returnObj;
		},
		getEndDate: function(end) {
			var endObjM = this.conductTime(end);
			var endObjMY = endObjM.year;
			var endObjMM = endObjM.month;
			var endObjMD = endObjM.date;
			var endObjMH = endObjM.hour;
			var endObjMMi = endObjM.mins;
			for (var i = 0; i < 60; i++) {
				endObjMM++;
				if (endObjMM > 12) {
					endObjMY++;
					endObjMM = 1;
				}
				var monthLastDate = this.getMonthWeek(endObjMY, endObjMM);
				monthLastDate = monthLastDate[2];
				if (monthLastDate >= endObjMD) {
					endObjMD = endObjMD;
				} else {
					endObjMD = monthLastDate;
				};
				returnObj.endTime.push(endObjMY + "-" + endObjMM + "-" + endObjMD + " " + endObjMH + ":" + endObjMMi);
			};
		},
		getStartDate: function(start) {
			var startObjM = this.conductTime(start);
			var startObjMY = startObjM.year;
			var startObjMM = startObjM.month;
			var startObjMD = startObjM.date;
			var startObjMH = startObjM.hour;
			var startObjMMi = startObjM.mins;
			for (var i = 0; i < 60; i++) {
				startObjMM++;
				if (startObjMM > 12) {
					startObjMY++;
					startObjMM = 1;
				}
				var monthLastDate = this.getMonthWeek(startObjMY, startObjMM);
				monthLastDate = monthLastDate[2];
				if (monthLastDate >= startObjMD) {
					startObjMD = startObjMD;
				} else {
					startObjMD = monthLastDate;
				};
				returnObj.startTime.push(startObjMY + "-" + startObjMM + "-" + startObjMD + " " + startObjMH + ":" + startObjMMi);
			};
		},
		// 给输入框添加删除效果
        _addDeleteBtn:function(top,right){
        	top=""+top;
        	right=""+right;
        	if(!top.indexOf("px")>-1){
        		top+="px";
        	}
        	if(!right.indexOf("px")>-1){
        		right+="px";
        	}
            $(".canClear").css("padding-right","30px").each(function(index,item){
            	if($(item).data("btnAdded")=="true"){
            		return null;
            	}
                //樣式
                var btn=$(document.createElement("SPAN"));
                btn.addClass("btnClear");
                btn.text("×");
                $(item).after(btn);
                var height=window.getComputedStyle(item,null)["height"];
                btn.css({"position": "absolute","right":right,"top":top,"font-size":"20px","text-align":"center",
                    "background-color":"rgb(190,190,190)","border-radius":"20px","color":"white","padding-top":"3px"})
                .parent().css("position","relative");
                btn.css("height","25px").css("width","25px");
                //功能
                btn.off("tap");
                btn.on("tap",function(e){
                    $(this).prev().val("");
                    btn.hide();
                });
                btn.hide();
                $(item).data("btnAdded","true");
            });
        },
		// 获取 某个月的第一天 是周几，最后一天是周几，最后一天的日期。
		getMonthWeek: function(theYear, theMonth) {
			// theYear 年份
			// theMonth 1-12的月份

			// 返回的数组 [第一天的星期, 最后一天的星期，最后一天的日期]
			var array = [];

			var theNextYear = theYear;
			var theNextMonth = theMonth + 1;

			// 计算下个月第一天的年月日
			if (theMonth == 12) {
				theNextYear += 1;
				theNextMonth = 1;
			}

			// 创建 theMonth的第一天的对象
			var theDate = new Date(theYear, theMonth - 1, 1);
			array.push(theDate.getDay());

			// 下个月的 第一天减去 一天 则是 要求的 月的最后一天
			// 设置theDate为 下个月第一天
			theDate.setYear(theNextYear);
			theDate.setMonth(theNextMonth - 1);

			// 新建下个月第一第一天的前一天对象
			theNextDate = new Date(theDate.getTime() - 1000 * 60 * 60 * 24);
			array.push(theNextDate.getDay());
			array.push(theNextDate.getDate());

			return array;
		},
		//限制输入框能输入的字符个数-已弃用
		limitChar : function(id,num){
			//var dInput=document.getElementById(id);
			var dInput=$(id);
			if(dInput.hasClass("charLimited")){
				return null;
			}
			if(dInput.tagName!="INPUT"){
				return null;
			}
			dInput.addEventListener("",function(e){
				
			});
			dInput.addEventListener("input",function(e){
				if(dInput.value.length<num){
					//e.preventDefault();
					this["data-input"]=this.value;
				}else{
					if(!this["data-input"]){
						this["data-input"]=this.value;
						this["data-selectedStart"]=dInput.selectionStart;
						//this["data-selectedEnd"]=dInput.selectionEnd;
						return null;
					}
					this.value=this["data-input"];
					dInput.selectionStart=this["data-selectedStart"];
					//dInput.selectionEnd=this["data-selectedEnd"];
				}
			});
			$(dInput).addClass("charLimited");
		},
		// 计算提醒时间
        // 计算提醒时间
        calcRemindTime: function(type) {
            switch (type) {
                case 0:
                    sec = -1;
                    break;
                case 1:
                    sec = 0;
                    break;
                case 2:
                    sec = 5 * 60; //5分钟前
                    break;
                case 3:
                    sec = 15 * 60; //15分钟前
                    break;
                case 4:
                    sec = 30 * 60; //30分钟前
                    break;
                case 5:
                    sec = 60 * 60; //1小时前
                    break;
                case 6:
                    sec = 120 * 60; //2小时前
                    break;
                case 7:
                    sec = 1440 * 60; //1天前
                    break;
                case 8:
                    sec = 2880 * 60; //2天前
                    break;
                case 9:
                    sec = 10080 * 60; //1周前
                    break;
                case 10:
                    sec = 0; //当天9点
                    break;
                case 11:
                    sec = 1 * 1440 * 60; //1天前9点
                    break;
                case 12:
                    sec = 2 * 1440 * 60; //2天前9点
                    break;
                case 13:
                    sec = 7 * 1440 * 60; //1周前9点
                    break;

            }

            return sec;
        },
	};
	return InputInf;
});
/*
 * 1、保存事件相关数据
 * 2、新建、删除本地提醒
 * 
 * 
数据结构：*号表示两个表不同的字段
数据表：calendarthing,日程事件体
{
    "id": 3,            //  主键,事件体Id
    "title": "测试日程",    //  日程标题,最多40字
    "allDay": false,        //  是否全天事件,
    "address": "保利威座",      //  日程地址：最多60字
    "startTime": 1449642345,    //  日程开始时间,时分秒
    "endTime": 1449647168,      //  日程结束时间,时分秒
*   "thingEndTime": 1449647168, //  重复事件日程总体结束日期,当日0时
*   "remind": 1,            //  提醒类型,按秒数设定。-1:无提醒,0:事件发生时,300:5分钟前 ...中间省略... 604800:1周前
*   "repeat": 1,            //  重复类型：0:永不；1:每天；2:每周；3:每两周；4:每月；5:每年；
    "remarks": "备注信息",      // 最多200字
    "remindMark": null,         //  暂无使用
    "modifyids":",1,2,3,4,5,"     //  已修改过的事件实例Id列表,逗号分割,第一个前多加逗号
    
    
    ,"datafrom":"server/client"    // 来自server，或者来自用户client
    ,"readonly":true/false   // 是否可以在本地修改、删除
    ,"dealerNo":1359876789   // 用户卡号
    ,"groupType":1		//0：有约;1：参观申请;2：活动;3：大事件;99:个人日程
    ,"type":"海外培训"      //groupType子分类
    ,"state":1        //1:已完成, 0：未完成
    ,"showApply":true  //是否显示isApply, true/false
    ,"isApply":0                 //0:未报名;1:已报名;2:已审核
}

数据表：calendaritem,日程事件实例
{
    "id": 34,            //  主键,事件实例Id
*   "thingid":3,            // 日程事件体Id
*   "date":"2015-12-09"     // 日程每天字符串   2015-12-01，2015-12-02，2015-12-03
    "title": "测试日程",    //  日程标题,最多40字
    "allDay": false,        //  是否全天事件,
    "address": "保利威座",      //  日程地址：最多60字
    "startTime": 1449642345,    //  日程开始时间
    "endTime": 1449647168,      //  日程结束时间
    "remarks": "备注信息",      // 最多200字
    "remindMark": null,         //  暂无使用
*   "remindTime": 1449642345    //  提醒时间,unix时间格式,单位秒
    "modify":"m",       //  已修改,不能被批量操作;值有m,表示已修改,d,表示已删除
    "remind": 1,            //  提醒类型,按秒数设定。-1:无提醒,0:事件发生时,300:5分钟前 ...中间省略... 604800:1周前
    

    "groupType":1,      //0：有约;1：参观申请;2：活动;3：大事件
    "type":"海外培训"      //groupType子分类
    "state":1      //1:已完成, 0：未完成
    "showApply":true  //是否显示isApply, true/false
    "isApply":0                 //0:未报名;1:已报名;2:已审核
}
LocalStorage保存的键值对
键                          =>   值           // 注释
CalendarBF_ItemDbStartTime  => 1449600001  //  三个月前日期的0时,calendaritem数据表保存数据的开始时间,unix时间格式,单位秒
CalendarBF_ItemDbEndTime    => 1449699999  //  1年后日期的0时,calendaritem数据表保存数据的结束时间,unix时间格式,单位秒
CalendarBF_ItemDbLastUpdate => 1449642345  //  当天0时,calendaritem数据表保存数据的结束时间,unix时间格式,单位秒


修改当前日程：item做标记,things做记录；

修改所有日程：所有和thingid有从属关系的item均修改,包括之前已修改或已删除的单条item

删除当前日程：item做标记,things做记录；

删除所有日程：所有和thingid有从属关系的item均删除；
**/

define('module_calendarBf/js/common',['jquery', 'bsl', './moment.min', './calendarFunc'], function($, bsl, moment, Func) {

    /**
     * [Common 主要的返回对象]
     * 回掉函数 需要一个参数
     */
    var db;
    var me;
    var Common = {
        /**
        初始化Common对象中初始值
        */
        init: function() {
            me = this;
            var me = this;
            CalendarBF_ItemDbStartTime = parseInt(Butterfly.Store.loadObject("calendarBf_ItemDbStartTime"));
            CalendarBF_ItemDbEndTime = parseInt(Butterfly.Store.loadObject("calendarBf_ItemDbEndTime"));
            CalendarBF_ItemDbLastUpdate = parseInt(Butterfly.Store.loadObject("calendarBf_ItemDbLastUpdate"));

            if (!db) {
                db = me._openDatabase();
                db.transaction(function(tx) {
                    tx.executeSql('CREATE TABLE IF NOT EXISTS calendarthing (id integer primary key,title TEXT, address TEXT, startTime INTEGER, endTime INTEGER,thingEndTime INTEGER, allDay BOOLEAN, remind INTEGER, repeat INTEGER, remarks TEXT,  remindMark TEXT, modifyids TEXT, datafrom TEXT, readonly BOOLEAN, dealerNo TEXT, groupType INTEGER,state INTEGER, type TEXT, showApply BOOLEAN, isApply INTEGER)', [], function(tx) {

                    });
                    tx.executeSql('CREATE TABLE IF NOT EXISTS calendaritem (id integer primary key,  thingid INTEGER, date TEXT, title TEXT, address TEXT, startTime INTEGER, endTime INTEGER, allDay BOOLEAN,  remarks TEXT,  remindMark TEXT,remindTime INTEGER,modify TEXT, remind INTEGER, groupType INTEGER,state INTEGER, type TEXT, showApply BOOLEAN, isApply INTEGER)', [], function(tx) {

                    });
                });
            }

            // var thingDemo = {
            //     //"id": 3, //  主键，事件体Id
            //     "title": "测试日程每天重复1122", //  日程标题，最多40字
            //     "allDay": false, //  是否全天事件
            //     "address": "保利威座", //  日程地址：最多60字
            //     "startTime": 1448899200, // 2015-12-11 18:24:01 日程开始时间，时分秒
            //     "endTime": 1449072000, // 2015-12-11 19:20:00 日程结束时间，时分秒
            //     "thingEndTime": 0, //2015-12-25 //  重复事件日程总体结束日期，当日0时
            //     "remind": 300, //  提醒类型，按秒数设定。-1:无提醒，0:事件发生时，300:5分钟前 ...中间省略... 604800:1周前
            //     "repeat": 1, //  重复类型：0:永不；1:每天；2:每周；3:每两周；4:每月；5:每年；
            //     "remarks": "备注信息1122", // 最多200字
            //     "remindMark": '' //  暂无使用
            // }
            // me.pageCalendarAdd(thingDemo);
        },
        CalendarBF_DBNAME: "calendardb",
        _openDatabase: function() {
            var DEFAULT_SIZE = 5000000;
            if (isInApp) {
                // return bsl.sqlite.openDatabase("InfinitusCalendarDB.sqlite", "1.0", "calendar", DEFAULT_SIZE);

                //更新了cordova的SQLite插件，参数变为对象形式
                return bsl.sqlite.openDatabase({
                    name: "InfinitusBupmCalendarDB.sqlite",
                    location: 'default'
                });
            } else {
                return openDatabase("test6DBinCal.sqlite", "1.0", "calendar", DEFAULT_SIZE);
            }
        },
        CalendarBF_ItemDbStartTime: 0, // 三个月前的那天0时
        CalendarBF_ItemDbEndTime: 0, // 1年后的那天0时
        CalendarBF_ItemDbLastUpdate: 0, // 当天0时

        /*
        页面所用：新增日程
        1、保存入calendarthings表
        2、生成对应的items
        3、保存入calendaritem表
        */
        pageCalendarAdd: function(thing, success, error) {
            var me = this;
            if (thing) {
                db.transaction(function(tx) {
                    var sql = "INSERT INTO calendarthing (`title`,`allDay`,`address`,`startTime`,`endTime`,`remarks`,`remindMark`,`thingEndTime`,`remind`,`repeat`,`modifyids`,`datafrom`,`readonly`,`dealerNo`,`groupType`,`state`,`type`,`showApply`,`isApply`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

                    var data = [
                        thing.title, thing.allDay, thing.address, thing.startTime, thing.endTime, thing.remarks, '', thing.thingEndTime, thing.remind, thing.repeat, '', thing.datafrom, thing.readonly, thing.dealerNo, thing.groupType, thing.state, thing.type, thing.showApply, thing.isApply
                    ];
                    tx.executeSql(sql, data, function(tx, res) {
                        if (res.insertId) {
                            thing.id = res.insertId;
                            var itemArr = me.getCalendarItemsByThing(thing);
                            var k = 0;
                            for (var i = 0; i < itemArr.length; i++) {
                                var item = itemArr[i];
                                item.thingid = thing.id;
                                var sqlInsert = "INSERT INTO calendaritem (`thingid`,`date`,`title`,`allDay`,`address`,`startTime`,`endTime`,`remarks`,`remindMark`,`remindTime`,`modify`,`remind`,`groupType`,`state`,`type`,`showApply`,`isApply`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
                                var data = [
                                    item.thingid, item.date, item.title, item.allDay, item.address, item.startTime, item.endTime, item.remarks, item.remindMark, item.remindTime, '', item.remind, item.groupType, item.state, item.type, item.showApply, item.isApply
                                ];
                                tx.executeSql(sqlInsert, data, function(tx, res) {
                                    if (k++ == itemArr.length - 1) {
                                        if (isInApp) bsl.infinitus.tools.dismissLoading();
                                        success();
                                    };
                                }, function(e) {
                                    error(e);
                                });
                            };
                        }
                    }, function(e) {
                        error(e);
                    });
                });
            }
        },
        /*
        页面所用：修改所有日程,修改日程事件体
        1、修改并保存入calendarthings表
        2、删除calendaritem表所有对应记录（除去已标记为删除的数据）
        3、生成对应的items（除去在modifyids中的数据）
        4、保存入calendaritem表
        */
        pageCalendarModifyAllItem: function(thing, success, error) {
            var me = this;
            var insertItemId = null;
            if (thing && thing.id) {
                db.transaction(function(tx) {
                    var sql = "UPDATE calendarthing SET `title` = ?, `allDay` =  ? , `address` = ?, `startTime` =  ? , `endTime` =  ? , `remarks` = ?, `remindMark` = ?, `thingEndTime` =  ? , `remind` =  ? , `repeat` =  ? ,`modifyids` = ? WHERE `id` =  ?;";
                    var data = [thing.title, thing.allDay, thing.address, thing.startTime, thing.endTime, thing.remarks, thing.remindMark, thing.thingEndTime, thing.remind, thing.repeat, thing.modifyids, thing.id];

                    tx.executeSql(sql, data, function(tx, res) {
                        if (true) {
                            // 删除对应items
                            var sqlDel = "DELETE From calendaritem WHERE `thingid` = ?";
                            var data = [thing.id];
                            tx.executeSql(sqlDel, data, function(tx, res) {
                                // 新增对应items
                                var itemArr = me.getCalendarItemsByThing(thing);
                                var sqlInsert = "";
                                var data = [thing.id];
                                var k = 0;
                                for (var i = 0; i < itemArr.length; i++) {
                                    var item = itemArr[i];
                                    var sqlInsert = "INSERT INTO calendaritem (`thingid`,`date`,`title`,`allDay`,`address`,`startTime`,`endTime`,`remarks`,`remindMark`,`remindTime`,`modify`,`remind`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);";
                                    var data = [
                                        item.thingid, item.date, item.title, item.allDay, item.address, item.startTime, item.endTime, item.remarks, item.remindMark, item.remindTime, '', item.remind
                                    ];
                                    tx.executeSql(sqlInsert, data, function(tx, res) {
                                        if (!insertItemId) insertItemId = res.insertId;
                                        //alert('ModifyAllItem success');
                                        if (k++ == itemArr.length - 1) {
                                            if (isInApp) bsl.infinitus.tools.dismissLoading();
                                            success(insertItemId);
                                        };
                                        //isOk = true;
                                    }, function(err) {
                                        //isOk = false;
                                        error(err);
                                    });
                                };
                            }, function(err) {
                                error(err);
                            });
                        }
                    }, function(err) {
                        error(err);
                    });
                });
            }
        },
        /**
        页面所用：修改当前日程,修改单个日程事件实例
        1、修改item表对应记录modify值,修改其他值并保存入calendaritem表
        2、在things表修改modifyids字段值
        */
        pageCalendarModifyOneItem: function(item, success, error) {
            var me = this;
            item.repeat = 0;
            var itemArr = me.getCalendarItemsByThing(item);
            if (item && item.id) {
                db.transaction(function(tx) {
                    var sql = "UPDATE calendaritem SET `date`=  ?  ,`title` =   ?  ,  `allDay` =   ?  ,  `address` =   ? ,  `startTime` =   ?  ,  `endTime` =   ?  ,  `remarks` =   ?  ,  `remindMark` =   ?  ,  `remindTime` =   ?  ,`modify` =   ?  , `remind` = ?   WHERE `id` =   ?;";
                    var data = [itemArr[0].date, itemArr[0].title, itemArr[0].allDay, itemArr[0].address, itemArr[0].startTime, itemArr[0].endTime, itemArr[0].remarks, itemArr[0].remindMark, itemArr[0].remindTime, itemArr[0].modifyids, itemArr[0].remind, item.id];
                    tx.executeSql(sql, data, function(tx, res) {
                        if (isInApp) bsl.infinitus.tools.dismissLoading();
                        success();
                    });
                }, function(err) {
                    error(err);
                });
            }
        },

        /**
        页面所用：根据item Id搜索当前日程
        */
        pageCalendarSelectOneItem: function(item, success, error) {
            db.transaction(function(tx) {
                var sql = "SELECT calendarthing.thingEndTime AS thingEndTime ,calendarthing.repeat AS repeat, calendaritem.* FROM calendaritem INNER JOIN calendarthing ON calendarthing.id = calendaritem.thingid WHERE calendaritem.id = " + item.id;
                tx.executeSql(sql, [], function(tx, res) {
                    if (res.rows.length > 0) {
                        success(res.rows);
                        return;
                    } else {
                        success(false);
                        return;
                    }
                });
            });
        },

        /*
        页面所用：删除日程事件体,删除对应的所有日程
        1、删除calendaritem表所有对应所有记录
        2、删除calendarthings表所对应记录
        */
        pageCalendarDeleteAllItem: function(thing, fnSuccess, fnFail) {
            var me = this;
            if (thing && thing.id) {
                // 删除对应items
                var sqlDel = "DELETE FROM calendaritem WHERE `thingid` = " + thing.id;
                db.transaction(function(tx) {
                    tx.executeSql(sqlDel, [], function(tx, res) {
                        // 删除对应thing
                        var sqlDelThing = "DELETE FROM calendarthing WHERE `id` = " + thing.id;
                        tx.executeSql(sqlDelThing, [], function(tx, res) {
                            if (res && res.rowsAffected == 1) {
                                fnSuccess();
                            } else {
                                fnFail();
                            }
                        }, function(e) {
                            fnFail(e);
                        });
                    }, function(e) {
                        fnFail(e);
                    });
                });
            }
        },

        /*
        页面所用：删除日程事件体,删除对应的所有日程
        1、删除calendaritem表所有对应所有记录
        2、删除calendarthings表所对应记录
        */
        pageCalendarDeleteAllItemFromServer: function(fnSuccess, fnFail) {
            var me = this;
            // 删除对应items
            var sqlDel = "DELETE FROM calendaritem WHERE groupType != 99";
            db.transaction(function(tx) {
                tx.executeSql(sqlDel, [], function(tx, res) {
                    var sqlDel = "DELETE FROM calendarthing WHERE groupType != 99";
                    tx.executeSql(sqlDel, [], function(tx, res) {
                        fnSuccess();
                    }, function(e) {
                        fnFail(e);
                    });
                }, function(e) {
                    fnFail(e);
                });
            });
        },

        /**
        页面所用：删除当前日程
        1、删除calendaritem表
        */
        pageCalendarDeleteOneItem: function(item, fnSuccess, fnFail) {
            var me = this;
            //结束时间等于重复结束时间要更新重复结束时间为前一天
            me.selectAllItemsByThingid(item.thingid, function(result) {
                if (result.length > 1) {
                    var data = result[result.length - 1];
                    if (data.id == item.id) {
                        var newDate = moment.unix(result[result.length - 2].endTime).startOf('day').unix();
                        me.thingEndTimeModify(newDate, item.thingid);
                    }
                }
            });

            if (item && item.id) {
                var sqlDel = "DELETE FROM calendaritem WHERE `id` = ?";
                var data = [item.id];
                db.transaction(function(tx) {
                    tx.executeSql(sqlDel, data, function(tx, res) {
                        if (res.rowsAffected && res.rowsAffected == 1) {
                            fnSuccess();
                        } else {
                            fnFail();
                        }
                    }, function(e) {
                        fnFail(e);
                    });
                });
            }

        },

        thingEndTimeModify: function(date, thingid) {
            var sql = "UPDATE calendarthing SET thingEndTime = " + date + " WHERE `id` = " + thingid;
            //alert(sql);
            db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, res) {

                });
            });
        },

        /**
        页面所用：获取指定月份的所有日程
        */
        pageGetCalendarItemByMonth: function(date, cbSucc, cbFail) {
            var startTime = date;
            var endTime = date;

        },
        /**
        页面所用：获取指定时间段的所有日程
        startTime:1400000000,unix时间戳,单位秒
        */
        pageGetCalendarItemByStartEndTime: function(startTime, endTime, cbSucc, cbFail) {

            var me = this;
            if (startTime < endTime) {
                var sql = 'SELECT * FROM `calendaritem` WHERE `startTime` >= ? AND `endTime` <= ? ORDER BY `id` asc;';
                var data = [startTime, endTime];
                db.transaction(function(tx) {
                    tx.executeSql(sql, data, function(tx, res) {
                        var result = [];
                        for (var i = 0; i < res.rows.length; i++) {
                            var item = me.getItemObjByDbRow(res.rows.item(i));
                            result.push(item);
                        };
                        cbSucc(result);
                    }, function(e) {
                        cbFail(e);
                    });
                });
            } else {
                cbFail([]);
                return;
            }
        },

        //按关键字搜索
        pageGetCalendarItemByKeyWord: function(conf, cbSucc, cbFail) {
            var me = this;
            bsl.infinitus.tools.getUserInfo(function(data) {
                if (typeof(data) == "string") {
                    data = JSON.parse(data);
                }
                var dealerNo = data.authAttr.dealerNo;
                var search_text = conf.key;
                var dateTime = conf.dateTime;
                var direction = conf.direction;
                var isFirst = conf.isFirst; //是否第一次搜索无结果后的向上搜索
                var where;
                switch (direction) {
                    case 'up':
                        where = 'calendaritem.startTime <' + dateTime + ' order by calendaritem.startTime desc';
                        break;
                    case 'down':
                        where = 'calendaritem.startTime >' + dateTime + ' order by calendaritem.startTime';
                        break;
                    case 'again':
                        where = 'calendaritem.startTime <' + dateTime + ' order by calendaritem.startTime desc';
                        break;
                    default:
                        where = 'calendaritem.startTime >=' + dateTime + ' order by calendaritem.startTime ';
                        break;
                }
                var sql = "SELECT calendaritem.*, calendarthing.repeat AS repeat, calendarthing.thingEndTime AS thingEndTime FROM calendaritem INNER JOIN calendarthing ON calendaritem.thingid = calendarthing.id where (calendaritem.title like ? or calendaritem.remarks like ? or calendaritem.address like ?) and calendarthing.dealerNo = '" + dealerNo + "' and " + where + " limit 20";
                var data = ['%' + search_text + '%', '%' + search_text + '%', '%' + search_text + '%'];
                db.transaction(function(tx) {
                    tx.executeSql(sql, data, function(tx, res) {

                        var result = [];
                        for (var i = 0; i < res.rows.length; i++) {
                            var item = me.getItemObjByDbRow(res.rows.item(i));
                            result.push(item);
                        };
                        if (result.length == 0 && isFirst) {
                            conf.direction = 'again';
                            conf.isFirst = false;
                            me.pageGetCalendarItemByKeyWord(conf, cbSucc, cbFail);
                        } else {
                            cbSucc(result, direction);
                        }
                    }, function(e) {
                        cbFail(e);
                    });
                });
            });
        },

        pageCalendarSelectAllThing: function(cbSucc, cbFail) {
            var sql = "select * from calendarthing";
            db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, res) {
                    cbSucc(res.rows);
                }, function(e) {
                    cbFail()
                });
            });
        },
        selectAllItemsByThingid: function(thingid, cbSucc, cbFail) {
            var me = this;
            var sql = "SELECT * FROM calendaritem WHERE thingid = " + thingid + " order by startTime";
            db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, res) {
                    var result = [];
                    for (var i = 0; i < res.rows.length; i++) {
                        var item = me.getItemObjByDbRow(res.rows.item(i));
                        result.push(item);
                    };
                    cbSucc(result);

                }, function(e) {
                    cbFail(e);
                });
            });
        },
        /*
        日历进入时初始化数据库和提醒
        1、重新设定通知
        2、
        */
        initCalendar: function() {
            var me = this;
            me.init();
            // 清理三个月前,重建1年后,暂无
        },
        /**
        重新设定通知
        **/
        initRemind: function(callBack) {
            var me = this;
            //  清理原生的所有提醒
            if (isInApp) bsl.infinitus.lcnotifiction.removeAllNotification();
            // 重新获取提醒数据,并设置提醒
            var nowTime = moment().unix();
            var sql = 'SELECT calendarthing.repeat AS repeat, calendaritem.* FROM `calendaritem` INNER JOIN calendarthing ON calendarthing.id = calendaritem.thingid WHERE calendaritem.remindTime >= ' + nowTime + ' ORDER BY calendaritem.remindTime asc,calendaritem.id asc limit 0,10;';

            db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, res) {
                    if (res.rows.length > 0) {
                        var result = [];
                        for (var i = 0; i < res.rows.length; i++) {
                            var item = me.getRemindArr(res.rows.item(i));
                            result.push(item);
                        };

                        // 重新设置通知

                        if (i == res.rows.length - 1) {
                            if (isInApp) bsl.infinitus.tools.dismissLoading();
                        };
                        if (isInApp) {
                            bsl.infinitus.lcnotifiction.addNotification(result, function(data) {

                            }, function(err) {
                                bsl.infinitus.tools.showToast('提醒添加失败', 2000);
                            });
                        }

                    } else {

                    }
                    if (typeof(callBack) == 'function') {
                        callBack();
                    }
                });
            });
        },

        getRemindArr: function(item) {
            var hour = moment.unix(item.startTime).get('hour');
            var time = moment.unix(item.startTime).format('HH:mm');
            var startTime, address, title;
            var isIos = localStorage.getItem("isApple");
            if (item.allDay == 'true') {
                startTime = '上午 9:00';
            } else if (hour >= 12) {
                startTime = '下午' + time;
            } else {
                startTime = '上午' + time;
            }
            if (item.address == '') {
                address = '';
            } else {
                address = '，' + item.address;
            }
            title = item.title + "," + startTime + address;
            return {
                "firstTime": moment.unix(item.remindTime).format('YYYY-MM-DD HH:mm:ss'), //"起始时间",// yyyy-MM-dd HH:mm:ss
                "ID": String(item.id),
                "repeatInterval": "0",
                "repeatNumber": "0", // 当用户不处理的时候，再次处理的次数，默认0次 。
                "title": title,
            };

        },

        /**
        3.2.1.  返回指定时间范围内日程事件实例列表
        用途：在向前3个月到未来1年内的月历、周历显示时使用
        获取方式：从『日程事件实例: calendar_item』数据表获取数据并直接返回 
        */
        getCalendarItemsFromDb: function(startTime, endTime, cbSucc, cbFail) {
             var me = this;
             bsl.infinitus.tools.getUserInfo(function(data) {
                if (typeof(data) == "string") {
                    data = JSON.parse(data);
                }
                var dealerNo = data.authAttr.dealerNo;
                var sql = 'SELECT calendaritem.* , calendarthing.groupType AS groupType, calendarthing.thingEndTime AS thingEndTime, calendarthing.repeat AS repeat FROM calendaritem INNER JOIN calendarthing ON calendaritem.thingid = calendarthing.id WHERE calendaritem.startTime < ? AND calendaritem.endTime >= ? AND calendarthing.dealerNo = ? ORDER BY  calendarthing.groupType ASC , calendaritem.allDay ASC , calendaritem.startTime DESC, calendaritem.endTime DESC, calendaritem.thingid DESC';
                //var sql = "select * from calendaritem";
                var data = [endTime, startTime, dealerNo];
                db.transaction(function(tx) {
                    tx.executeSql(sql, data, function(tx, res) {
                        var result = [];
                        for (var i = 0; i < res.rows.length; i++) {
                            var item = me.getItemObjByDbRow(res.rows.item(i));
                            result.push(item);
                        };
                        cbSucc(result);
                    }, function(e) {
                        cbFail(e);
                    });
                });
            });
        },
        /**
        3.2.2.  实时计算并返回指定时间范围内的所有日程事件实例列表
        用途：在月历、周历切换到3个月以前、1年以后时使用。
        获取方式：从『日程事件体: calendar_thing』数据表获取数据,计算返回值
        */
        getCalendarItemsByTime: function(startTime, endTime, cbSucc, cbFail) {
            var me = this;
            //1、从thing表获取StartTime、EndTime间的所有事件体
            //2、遍历事件体,生成事件实例数据列表（使用calcCalendarItemRec）
            //3、用于返回给月历周历显示,或用于入库

            var sql = 'SELECT * FROM calendarthing WHERE startTime >= ' + startTime + ' AND thingEndTime <= ' + endTime;

            db.transaction(function(tx) {
                tx.executeSql(sql, [], function(tx, res) {
                    var result = [];
                    for (var i = 0; i < res.rows.length; i++) {
                        var item = me.getThingObjByDbRow(res.rows.item(i));
                        var itemArr = me.getCalendarItemsByThing(item);
                        result.push(itemArr);
                    };
                    cbSucc(result);
                }, function(e) {
                    cbFail(e);
                });
            });
        },

        /**
        3.2.3.  实时计算指定事件体的实例
        用途：在月历、周历切换到3个月以前、1年以后时使用。
        获取方式：从『日程事件体: calendar_thing』数据表获取数据,计算返回值
        */
        getCalendarItemsByThing: function(thingObj, startTime, endTime) {
            var me = this;
            //1、根据事件体重复枚举,和事件体结束时间,以及开始结束时间参数,生成事件实例返回列表
            //2、用于入库
            var result = [];
            if (thingObj) {
                var repeatInvertal = 0;
                var repeatType = false;
                //  重复类型：0:永不；1:每天；2:每周；3:每两周；4:每月；5:每年；
                switch (thingObj.repeat) {
                    case 1: //每天重复
                        repeatInvertal = 1;
                        repeatType = "days";
                        break;
                    case 2: // 2：每周重复
                        repeatInvertal = 1;
                        repeatType = "weeks";
                        break;
                    case 3: // 3：每两周重复
                        repeatInvertal = 2;
                        repeatType = "weeks";
                        break;
                    case 4: // 3：每月重复
                        repeatInvertal = 1;
                        repeatType = "months";
                        break;
                    case 5: // 3：每年重复
                        repeatInvertal = 1;
                        repeatType = "years";
                        break;
                    default: //  0:永不重复
                        repeatInvertal = 0;
                        repeatType = false;
                        break;
                }
                // 本代码块使用了moment类库,时间格式采用moment对象
                //moment().add(7, 'd');
                // Key Shorthand
                // years   y
                // quarters    Q
                // months  M
                // weeks   w
                // days    d
                // hours   h
                // minutes m
                // seconds s
                // milliseconds    ms

                var thing = me.ObjDeepCopy(thingObj);
                var thingStartTime = moment.unix(thing.startTime);
                var thingEndTime = moment.unix(thing.thingEndTime + 86400);
                var itemStartTime = thingStartTime;
                var itemEndTime = moment.unix(thing.endTime);
                if (thing.allDay) {
                    itemStartTime = moment.unix(moment(itemStartTime.format('YYYY-MM-DD')).unix());
                    itemEndTime = moment.unix(moment(itemEndTime.format('YYYY-MM-DD')).unix() + 3600 * 24 - 1);
                }

                if (repeatType) {
                    //重复,按规则生成数组
                    result = [];
                    var startDay = parseInt(itemStartTime.format('D'));
                    var endDay = parseInt(itemEndTime.format('D'));
                    var startDate = itemStartTime;
                    var endDate = itemEndTime;
                    var stimes = etimes = 1;
                    while (itemStartTime.isBefore(thingEndTime)) {
                        var tmpItem = me.ObjDeepCopy(thing);
                        tmpItem.thingid = thing.id;

                        tmpItem.startTime = itemStartTime.unix();
                        tmpItem.endTime = itemEndTime.unix();

                        if (tmpItem.remind == 0) {
                            tmpItem.remindTime = 0;
                        } else {
                            var remind = Func.calcRemindTime(tmpItem.remind);
                            if (tmpItem.allDay) {

                                var remindTime = moment(itemStartTime).hours(9).minutes(0).seconds(0).milliseconds(0);
                                tmpItem.remindTime = remindTime.unix() - remind;
                            } else {
                                tmpItem.remindTime = itemStartTime.unix() - remind;
                            }
                        }
                        var date = '';
                        var loopStart = moment(itemStartTime).hours(0).minutes(0).seconds(0).milliseconds(0);
                        while (loopStart.isBefore(moment(itemEndTime).hours(23).minutes(59).seconds(59).milliseconds(0))) {
                            date += loopStart.format("YYYY-MM-DD") + ',';
                            loopStart.add(1, 'days');

                        }
                        tmpItem.date = date.substr(0, date.length - 1);
                        result.push(tmpItem);
                        itemStartTime = moment(startDate).add(repeatInvertal * stimes++, repeatType);
                        itemEndTime = moment(endDate).add(repeatInvertal * etimes++, repeatType);
                        //如果重复日期为29-31日，则判断是否润年及二月则跳过二月份
                        var currentDay = parseInt(itemStartTime.format('D'));
                        var currentYear = parseInt(itemStartTime.format('YYYY'));
                        var currentMonth = parseInt(itemStartTime.format('M'));
                        var smallMonth = [2, 4, 6, 9, 11];

                        if (repeatType == 'months' || repeatType == 'years') { //每月每年重复
                            if (!moment(currentYear + '-' + currentMonth + '-' + startDay, 'YYYY-M-D').isValid()) {
                                itemStartTime.add(repeatInvertal, repeatType);
                                itemEndTime.add(repeatInvertal, repeatType);
                                itemStartTime.date(startDay);
                                itemEndTime.date(endDay);
                                stimes++;
                                etimes++;
                            }

                        }

                    }
                } else {
                    // 不重复,生成一条日程事件实例记录
                    var tmpItem = me.ObjDeepCopy(thingObj);
                    tmpItem.thingid = thingObj.id;
                    var date = '';
                    var loopStart = moment(itemStartTime).hours(0).minutes(0).seconds(0).milliseconds(0);

                    tmpItem.startTime = itemStartTime.unix();
                    //tmpItem.endTime = itemStartTime.unix() + thing.endTime - thing.startTime;
                    tmpItem.endTime = itemEndTime.unix();

                    while (loopStart.isBefore(moment(itemEndTime).hours(23).minutes(59).seconds(59).milliseconds(0))) {
                        date += loopStart.format("YYYY-MM-DD") + ',';
                        loopStart.add(1, 'days');
                    }
                    tmpItem.date = date.substr(0, date.length - 1);
                    if (tmpItem.remind == 0) {
                        tmpItem.remindTime = 0;
                    } else {
                        var remind = Func.calcRemindTime(tmpItem.remind);
                        if (tmpItem.allDay) {
                            var remindTime = moment(itemStartTime).hours(9).minutes(0).seconds(0).milliseconds(0);
                            tmpItem.remindTime = remindTime.unix() - remind;
                        } else {
                            tmpItem.remindTime = itemStartTime.unix() - remind;
                        }
                    }
                    result = [tmpItem];
                }
            } else {
                result = [];
            }
            return result;
        },

        /**
        3.2.4.  获取指定月份的指定类型日程事件实例记录数量
        用途：获取当月用户活动数量，指定月用户活动数量等。
        获取方式：从『日程事件实例: calendar_item』数据表获取数据,计算返回值
        */
        getCalendarItemCountByMonth: function(year, month, cbSucc, cbFail) {
            var me = this;
            //1、根据事件体重复枚举,和事件体结束时间,以及开始结束时间参数,生成事件实例返回列表
            //2、用于入库
            var result = 0;
            if (!year) {
                year = moment().year();
            }
            if (!month) {
                month = moment().month();
            }

            var startTime = moment(new Date(year, month, 1));
            var endTime = startTime.clone().add(1, 'M');
            var sql = "select count(*) as cnt from calendaritem where starttime > ? and starttime < ? and modify <> 'd'"

            //var sql = "select * from calendaritem";
            var data = [startTime.unix(), endTime.unix()];
            console.log(data);

            db.transaction(function(tx) {
                tx.executeSql(sql, data, function(tx, res) {
                    var result = 0;
                    var item = res.rows.item(0);
                    console.log(item);
                    result = item.cnt;
                    console.log(result);
                    cbSucc(result);
                }, function(e) {
                    cbFail(e);
                });
            });

            //		db.transaction(function(tx) {
            //				tx.executeSql("select * from calendaritem", [], function(tx, res) {
            //					var result = 0;
            //					console.log("length:"+res.rows.length);
            //for (var i = 0; i < res.rows.length; i++) {
            //						var item = me.getItemObjByDbRow(res.rows.item(i));
            //						console.log(item);
            //					};
            //			
            //					cbSucc(result);
            //				}, function(e) {
            //					cbFail(e);
            //				});
            //			});
            //			console.log("startTime:"+startTime.format("YYYY-MM-DD"));
            //			console.log("endTime:"+endTime.format("YYYY-MM-DD"));
            return result;
        },

        /**
        重新设置所有的提醒,调用原生方法去remove所有提醒,
        并从数据库中找到当前最新10条提醒,并且新增
        **/
        resetRemind: function() {
            var remindCount = 10;
            //TODO 调用原生接口方法,清理所有提醒通知

            //TODO 调用原生方法,添加未来10条提醒通知
        },
        getItemObjByDbRow: function(dbrow) {
            var result = null;
            if (dbrow) {
                result = {
                    type: "calendaritem",
                    id: parseInt(dbrow.id),
                    thingid: parseInt(dbrow.thingid),
                    date: dbrow.date,
                    title: dbrow.title,
                    allDay: dbrow.allDay,
                    address: dbrow.address,
                    startTime: parseInt(dbrow.startTime),
                    endTime: parseInt(dbrow.endTime),
                    thingEndTime: parseInt(dbrow.thingEndTime),
                    remind: parseInt(dbrow.remind),
                    repeat: parseInt(dbrow.repeat),
                    remarks: dbrow.remarks,
                    remindMark: dbrow.remindMark,
                    remindTime: parseInt(dbrow.remindTime),
                    modify: parseInt(dbrow.modify),
                    dateTime: moment.unix(dbrow.startTime).format('YYYY-MM-DD'),
                    groupType:dbrow.groupType,
                    state:dbrow.state,
                    showApply:dbrow.showApply,
                    isApply:dbrow.isApply
                };
                result.mark = result.id;
                result.startTimeHourMin = moment.unix(result.startTime).format("HH:mm");
                result.endTimeHourMin = moment.unix(result.endTime).format("HH:mm");
                result.weekinf = "";
                //weekinf格式为： 2015-44-2&2015-44-3&2015-44-4&2015-44-5&，第0-6周加100，用于跨年计算
                if (result.date && result.date.split(",").length > 0) {
                    var dateArr = result.date.split(",");
                    for (var i = 0; i < dateArr.length; i++) {
                        var mo = moment(dateArr[i]);
                        var year = parseInt(mo.format("YYYY"))
                        var dayInWeek = parseInt(mo.format("d"));
                        var weekOfYear = parseInt(mo.format("w"));

                        result.weekinf += year + '-' + weekOfYear + "-" + dayInWeek + "&";
                    };
                }
                result.weekinf = result.weekinf.substr(0, result.weekinf.length - 1);

            }
            return result;
        },
        getThingObjByDbRow: function(dbrow) {
            var result = null;
            if (dbrow) {
                result = {
                    type: "calendarthing",
                    id: parseInt(dbrow.id),
                    title: dbrow.title,
                    allDay: dbrow.allDay,
                    address: dbrow.address,
                    startTime: parseInt(dbrow.startTime),
                    endTime: parseInt(dbrow.endTime),
                    thingEndTime: parseInt(dbrow.thingEndTime),
                    remind: parseInt(dbrow.remind),
                    repeat: parseInt(dbrow.repeat),
                    remarks: dbrow.remarks,
                    remindMark: dbrow.remindMark,
                    remindTime: parseInt(dbrow.remindTime),
                };
            }
            return result;
        },
        ObjDeepCopy: function(source) {
            var result = {};
            for (var key in source) {
                result[key] = typeof(source[key]) === 'object' ? this.ObjDeepCopy(source[key]) : source[key];
            }
            return result;
        },

    }
    return Common;
});

// console
// 参数：年份数字
// 月份数字
// 成功时回调
//          api.getCalendarItemCountByMonth(2016,11,function(result){
//          	console.log(result);	//返回数字
//          },function(e){
//          	console.log(e);
//          });

define('module_calendarBf/api',['./js/common'], function(CalendarCommon) {
	var Calendar = new function() {}

	Calendar.init = function() {

	}

	Calendar.getCalendarItemCountByMonth = function(year, month, fnSucceed, fnFail) {
		CalendarCommon.init();
		CalendarCommon.getCalendarItemCountByMonth(year, month, fnSucceed, fnFail);
	}

	return Calendar;
});

define('text!module_calendarBf/calendarAdd.html',[],function () { return '<div data-view="calendarAdd" id="calendarAdd" class="views">\n\t<style>/*\n\t\thtml, body {\n\t\t\tposition: absolute;\n\t\t\ttop: 0;\n\t\t\tbottom: 0;\n\t\t}*/\n\t.content{\n\t\ttop:44px;\n\t}\n\t\t#calendarAdd .list {\n\t\t\tmargin-top: 10px;\n\t\t\tpadding: 0 0 0 15px;\n\t\t\tbackground-color: #fff;\n\t\t\tborder-top: 1px solid #eee;\n\t\t\tborder-bottom: 1px solid #eee;\n\t\t}\n\t\t\n\t\t#calendarAdd #section_wrap{\n\t\t\tpadding-top: 10px;\n\t\t\tfont-family: arial,YouYuan;\n\t\t}\n\t\t \n\t\t#calendarAdd .padding-right11 {\n\t\t\tpadding-right: 11px;\n\t\t}\n\t\t\n\t\t#calendarAdd .margin-right11 {\n\t\t\tmargin-right: -11px;\n\t\t}\n\t\t\n\t\t#calendarAdd .input-row {\n\t\t\theight: 47px;\n\t\t\tcolor: #7a7a7a;\n\t\t}\n\t\t#calendarAdd .input-row label{font-family: YouYuan!important;line-height: 47px;padding: 0px 15px;font-weight: bold;}\n\t\t#calendarAdd .add-input input {\n\t\t\theight: 47px;\n\t\t\twidth: 79%;\n\t\t}\n\t\t\n\t\t#calendarAdd .add-input label {\n\t\t\twidth: 20%;\n\t\t\tpadding-right: 0;\n\t\t\twhite-space: nowrap;\n\t\t\tfont-weight: bold;\n\t\t}\n\t\t\n\t\t#calendarAdd .table-view {\n\t\t\tpadding-left: 0;\n\t\t\tmargin-top: 0;\n\t\t\tmargin-bottom: 15px;\n\t\t\tlist-style: none;\n\t\t\tbackground-color: #fff;\n\t\t\tborder-top: none;\n\t\t\tborder-bottom: 1px solid #ddd;\n\t\t}\n\t\t#calendarAdd #calendar-moudel-calendarAdd {\n\t\t\toverflow-y: auto;\n\t\t}\n\t\t\n\t\t#calendarAdd .toggle.active:before {\n\t\t\tcontent: "开";\n\t\t\tfont-size: 16px;\n\t\t}\n\t\t\n\t\t#calendarAdd .toggle:before {\n\t\t\tcontent: "关";\n\t\t\tfont-size: 16px;\n\t\t}\n\t\t\n\t\t#calendarAdd .lineThrough {\n\t\t\ttext-decoration: line-through;\n\t\t}\n\t\t\n\t\t#calendarAdd .clearInput {\n\t\t\tposition: absolute;\n\t\t\tright: 1px;\n\t\t\tpadding: 10px 5px;\n\t\t\tdisplay: none;\n\t\t}\n\t\t\n\t\t#calendarAdd .clearTextarea {\n\t\t\tposition: absolute;\n\t\t\tright: 1px;\n\t\t\tpadding: 0px 5px;\n\t\t\tdisplay: none;\n\t\t}\n\t\t\n\t\t#calendarAdd .newUserTips img {\n\t\t\tdisplay: block;\n\t\t\twidth: 100%;\n\t\t\tborder: none;\n\t\t\tbox-sizing: border-box;\n\t\t\tmargin: 0;\n\t\t\tpadding: 0;\n\t\t}\n\t\t\n\t\t#calendarAdd .newUserTips_img {\n\t\t\theight: 28%;\n\t\t}\n\t\t#calendarAdd .pull-right{color: rgb(122,122,122);font-weight: normal;}\n\n        #calendarAdd footer{\n            position: absolute;\n            left:0;\n            bottom: 0;\n            width:100%;\n            height:45px;\n            background-color: #fff;\n            text-align: center;\n        }\n        #calendarAdd .content{\n            bottom: 45px;\n        }\n    #calendarAdd footer button{\n        width:100%;\n        height:100%;\n        border:none;\n    }\n\t\t@media screen and (min-height:649px) and (max-height:1000px) {\n\t\t\t#calendarAdd .newUserTips_img {\n\t\t\t\theight: 15%;\n\t\t\t}\n\t\t\t.views{\n\t\t\t\tbackground-color: #f2f2f2;\n\t\t\t}\n\t\t}\n\t@media only screen and (min-device-width : 768px) and (max-device-width : 1024px) {\n\t\n\t\t.content {\n\t\t\ttop:0;\n\t\t}\n\t\t\n\t}\n\t\t@media screen and (min-height:628px) and (max-height:648px) {\n\t\t\t#calendarAdd .newUserTips_img {\n\t\t\t\theight: 20%;\n\t\t\t}\n\t\t}\n\t\t\n\t\t@media screen and (min-height:569px) and (max-height:627px) {\n\t\t\t#calendarAdd .newUserTips_img {\n\t\t\t\theight: 22%;\n\t\t\t}\n\t\t}\n\t\t\n\t\t@media screen and (min-height:481px)and (max-height:568px) {\n\t\t\t#calendarAdd .newUserTips_img {\n\t\t\t\theight: 29%;\n\t\t\t}\n\t\t\t.views{\n\t\t\t\theight: 568px;\n\t\t\t}\n\t\t}\n\t\t\n\t\t@media screen and (max-height:480px) {\n\t\t\t#calendarAdd .newUserTips_img {\n\t\t\t\theight: 31%;\n\t\t\t}\n\t\t\t#calendarAdd #calendar-moudel-calendarAdd {\n\t\t\t\theight: 500px;\n\t\t\t}\n\t\t\t#section_wrap {\n\t\t\t\t/*border: 1px solid red;*/\n\t\t\t\theight: 580px;\n\t\t\t}\n\t\t\t.views{\n\t\t\t\theight: 600px;\n\t\t\t}\n\t\t}\n\t\t/*新手指引*/\n\t    .ui-newerGuide{\n\t        position:absolute;\n\t        top:0;\n\t        left:0;\n\t        z-index:1000;\n\t        width:100%;\n\t        height:100%;\n\t        background-color: rgba(0,0,0,0.69);\n\t    }\n\t    .ui-newGuide-phone-add1{\n\t    \tposition: absolute;\n\t    \ttop:5px;\n\t    \tright: 10px;\n\t    \theight: 34px;\n\t    }\n\t    .ui-newGuide-phone-add2{\n\t    \tposition: absolute;\n\t    \ttop: 44px;\n\t    \tright: 40px;\n\t        height: 1.3rem;\n\t    }\n\t    .ui-newerGuide .guide-btn{\n\t    \tposition: absolute;\n\t    \tleft: 2%;\n\t    \twidth: 96%;\n\t    \theight: 44px;\n\t    }\n\t    .ui-newerGuide .guide-font{\n\t    \tposition: absolute;\n\t    \tleft: 25%;\n\t        height: 1.5rem;\n\t    }\n\t    .ui-newGuide-phone-add3{\n\t    \ttop:226px;\n\t    }\n\t    .ui-newGuide-phone-add4{\n\t    \ttop:314px;\n\t    }\n\t    .ui-newGuide-phone-add5{\n\t    \ttop:368px;\n\t    }\n\t    .ui-newGuide-phone-add6{\n\t    \ttop:414px;\n\t    }\n\t</style>\n\t<div id="module-calendarBf-calendarAdd">\n\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t<div class="ui3-row-12">\n\t\t\t<div class="ui3-col-3 ui3-icon-back back" data-click-title="添加日程" data-click-label="返回">返回</div>\n\t\t\t<div class="ui3-col-3 dialog-close" style="display:none;">取消</div>\n\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">新建事件</div>\n\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right dialog-save" data-click-title="添加日程" data-click-label="保存">保存</div>\n\t\t</div>\n\t</header>\n\n\t<!--<header class="bar bar-nav blue-bar top-background-color">\n\t\t<button class="btn btn-link btn-nav pull-left back">\n\t\t\t<span class="icon icon-left-nav back_icon slim"><span>返回</span></span>\n\t\t</button>\n\t\t<button i="title" title="cancel" class="btn btn-link btn-nav pull-left dialog-close" style="display:none;">\n\t\t\t<span class="icon icon-left-nav back_icon">取消</span>\n\t\t</button>\n\t\t<div class="title">新建事件</div>\n\t\t<button class="btn btn-link btn-nav pull-right dialog-save">\n\t\t\t保存\n\t\t</button>\n\t</header>-->\n\t<div class="content" style="background: #F2F2F2" id="calendar-moudel-calendarAdd">\n\t\t<div id="section_wrap">\n\t\t\t<form class="input-group">\n\t\t\t\t<div class="input-row add-input">\n\t\t\t\t\t<label>标题</label>\n\t\t\t\t\t<input id="tittle" class="canClear titleInput" type="text" maxlength="40" placeholder="40个文字以内" data-focus-title="添加日程" data-focus-label="标题">\n\t\t\t\t</div>\n\t\t\t\t<div class="input-row add-input">\n\t\t\t\t\t<label>地点</label>\n\t\t\t\t\t<input id="address" class="canClear addInput" type="text" maxlength="60" placeholder="60个文字以内" data-focus-title="添加日程" data-focus-label="地点">\n\t\t\t\t</div>\n\t\t\t</form>\n\n\t\t\t<ul class="table-view" style="margin-top:10px;">\n\t\t\t\t<li class="table-view-cell boldTxt">\n\t\t\t\t\t全天事件\n\t\t\t\t\t<div class="toggle" id="idAllDay" data-click-title="添加日程" data-click-label="开关" >\n\t\t\t\t\t\t<div class="toggle-handle" data-click-title="添加日程" data-click-label="开关"></div>\n\t\t\t\t\t</div>\n\t\t\t\t</li>\n\t\t\t</ul>\n\n\t\t\t<form class="input-group" id="formNoAll">\n\t\t\t\t<div class="input-row" data-focus-title="添加日程" data-focus-label="开始时间">\n\t\t\t\t\t<label for="startTime" style="color:#000;line-height: 47px;" data-focus-title="添加日程" data-focus-label="开始时间">开始</label>\n\t\t\t\t\t<input id="startTime" class="repeatStart" style="text-align:right;line-height: 47px;height: 100%;" value="2015-05-05 15:42" class="" readonly="readonly" name="startTime" type="text" data-focus-title="添加日程" data-focus-label="开始时间">\n\t\t\t\t</div>\n\t\t\t\t<div class="input-row" id="endTimeDiv" data-focus-title="添加日程" data-focus-label="结束时间">\n\t\t\t\t\t<label for="endTime" style="color:#000;line-height: 47px;" data-focus-title="添加日程" data-focus-label="结束时间">结束</label>\n\t\t\t\t\t<input id="endTime" class="repeatEnd" style="text-align:right;line-height: 47px;height: 100%;" value="2015-05-15 15:42" class="" readonly="readonly" name="endTime" type="text" data-focus-title="添加日程" data-focus-label="结束时间">\n\t\t\t\t</div>\n\n\t\t\t</form>\n\n\t\t\t<form class="input-group " id="formAll" style="display:none;">\n\t\t\t\t<div class="input-row" data-focus-title="添加日程" data-focus-label="开始时间">\n\t\t\t\t\t<label for="startTimeall" style="color:#000;line-height: 47px;" data-focus-title="添加日程" data-focus-label="开始时间">开始</label>\n\t\t\t\t\t<input id="startTimeall" class="repeatStart" style="text-align:right;height: 100%;line-height: 47px;" value="2015-05-05 15:42" class="" readonly="readonly" name="startTimeall" type="text" data-focus-title="添加日程" data-focus-label="开始时间">\n\t\t\t\t</div>\n\t\t\t\t<div class="input-row" id="endTimeDiv" data-focus-title="添加日程" data-focus-label="结束时间">\n\t\t\t\t\t<label for="endTimeall" style="color:#000;line-height: 47px;" data-focus-title="添加日程" data-focus-label="结束时间">结束</label>\n\t\t\t\t\t<input id="endTimeall" class="repeatEnd" style="text-align:right;height: 100%;line-height: 47px;" value="2015-05-15 15:42" class="" readonly="readonly" name="endTimeall" type="text" data-focus-title="添加日程" data-focus-label="结束时间">\n\t\t\t\t</div>\n\t\t\t</form>\n\n\t\t\t<ul class="table-view">\n\t\t\t\t<li class="table-view-cell" id="remindBtn">\n\t\t\t\t\t<a class="navigate-right boldTxt" id="remindBtn" data-click-title="添加日程" data-click-label="提醒时间">\n     \t\t\t\t\t提醒时间\n     \t\t\t\t\t<!--   \n\t\t\t\t\t\t\t无 ：0\n\t\t\t\t\t\t\t事件发生时：1\n\t\t\t\t\t\t\t5分钟前： 2\n\t\t\t\t\t\t\t15分钟前：3\n\t\t\t\t\t\t\t30分钟前：4\n\t\t\t\t\t\t\t1小时前： 5\n\t\t\t\t\t\t\t2小时前：6\n\t\t\t\t\t\t\t1周前：7\n\t     \t\t\t\t-->\n\t  \t\t\t\t\t<span class="pull-right" id="remind" data-type="0" data-click-title="添加日程" data-click-label="提醒时间">无</span>\n    \t\t\t\t</a>\n\t\t\t\t</li>\n\t\t\t</ul>\n\n\t\t\t<ul class="table-view" style="margin-top:10px;">\n\t\t\t\t<li class="table-view-cell" id="repeatBtn">\n\t\t\t\t\t<a class="navigate-right boldTxt" id="repeatBtn" data-click-title="添加日程" data-click-label="重复">\n     \t\t\t\t\t重复\n\n     \t\t\t\t<!--   \n\t\t\t\t\t\t永不：0\n\t\t\t\t\t\t每天：1\n\t\t\t\t\t\t每周： 2\n\t\t\t\t\t\t每两周：3\n\t\t\t\t\t\t每月：4\n\t\t\t\t\t\t每年： 5\n     \t\t\t\t-->\n\t  \t\t\t\t\t<span class="pull-right" id="repeat" data-type="0"  data-click-title="添加日程" data-click-label="重复">永不</span>\n    \t\t\t\t</a>\n\t\t\t\t</li>\n\t\t\t\t<li>\n\t\t\t\t\t<form class="input-group">\n\t\t\t\t\t\t<div class="input-row" id="thingEndTimeDiv" style="display:none">\n\t\t\t\t\t\t\t<label for="thingEndTime" style="color:#000;">重复结束</label>\n\t\t\t\t\t\t\t<input id="thingEndTime" class="repeatEnd" style="text-align:right;line-height: 47px;" value="" class="" readonly="readonly" name="thingEndTime" type="text">\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</form>\n\t\t\t\t</li>\n\t\t\t</ul>\n\n\t\t\t<ul class="table-view" style="margin-top:10px;">\n\t\t\t\t<li class="table-view-cell padding-right11">\n\t\t\t\t\t<textarea id="remarks" rows="" cols="4" style="padding: 0px;margin:0 -5px;height: 80px;border: none" maxlength="200" placeholder="备注 200个文字以内" data-focus-title="添加日程" data-focus-label="日程详情"></textarea>\n\t\t\t\t\t<span class="clearTextarea">X</span>\n\t\t\t\t\t\n\t\t\t\t</li>\n\t\t\t</ul>\n\t\t</div>\n\t</div>\n        <footer>\n            <button class="dialog-save save-btn">保存</button>\n        </footer>\n\t<div class="newUserTips phoneTips">\n\t\t<img src="images/phoneTips2_1.png">\n\t\t<img src="images/phoneTips2_2.png" class="newUserTips_img">\n\t\t<img src="images/phoneTips2_3.png">\n\t\t<img src="images/phoneTips2_2.png">\n\t</div>\n\t<div class="newUserTips ipadTips">\n\t\t<img src="images/ipadTips2.png">\n\t</div>\n\t <div class="ui-newerGuide" style="display:none">\n            <!--指引元素-->\n            <img class="ui-newGuide-phone-add1" src="./images/newGuide_phone_add1.png">\n            <img class="ui-newGuide-phone-add2 " src="./images/newGuide_phone_add2.png">\n            <img class="ui-newGuide-phone-add3 guide-font" src="./images/newGuide_phone_add3.png">\n            <img class="ui-newGuide-phone-add4 guide-btn" src="./images/newGuide_phone_add4.png">\n            <img class="ui-newGuide-phone-add5 guide-btn" src="./images/newGuide_phone_add5.png">\n            <img class="ui-newGuide-phone-add6 guide-font" src="./images/newGuide_phone_add6.png">\n    </div>\n</div>\n</div>';});


define('text!module_calendarBf/template/calendar-template.html',[],function () { return '<%function format(num){\n\tnum=""+num;\n\tif(parseInt(num)<10 && num.length<2){\n\t\treturn "0"+num;\n\t}else{\n\t\treturn num;\n\t}\n}%>\n<table width="100%" style="background-color:#F2F2F2;">\n\t<tr height="1px">\n\t\t<td colspan=7 style="border-bottom:1px solid  #D5D5D5;"></td>\n\t</tr>\n\t<% for(var i = 0; i <= monthArray.length; i++){ %>\n\t\t<%var formatedDay=format(monthArray[i]);\n\t\t  var formatedMonth=format(theMonth);\n\t\t%>\n\t\t<% if(i%7==0){%>\n\t\t\t<tr align="center">\n\t\t\t\t<td  style="padding:5px;color: #221816; position:relative;" class="calendar-day"\n\t\t\t\t <% if(monthArray[i]) { %>\n\t\t\t\t \tdata-date="<%=theYear%>-<%=formatedMonth%>-<%=formatedDay%>">\n\t\t\t\t <% }else {%>\n\t\t\t\t \t>\n\t\t\t\t <%}%>\n\t\t\t\t\t<% if(monthArray[i]){ %>\n\t\t\t\t\t\t<a href="javascript:;" class="now-day \n\t\t\t\t\t\t<%if(monthArray[i]==currentDate.nowDay && theYear==currentDate.nowYear && theMonth==currentDate.nowMonth){%> now-day-bg now-day-color<%}%> <%if(monthArray[i]==selectDate.date && theYear==selectDate.year && theMonth==selectDate.month){%> tap-day-bg<%}%>" data-date="<%=theYear%>-<%=formatedMonth%>-<%=formatedDay%>"><%=monthArray[i]%></a>\n\t\t\t\t\t<% } %>\n\t\t\t\t</td>\n\t\t<%} else {%>\n\t\t\t<%if(i%7==6){%>\n\t\t\t\t<td  style="padding:5px;color: #221816; position:relative;" class="calendar-day" \n\t\t\t\t <% if(monthArray[i]) { %>\n\t\t\t\t \tdata-date="<%=theYear%>-<%=formatedMonth%>-<%=formatedDay%>">\n\t\t\t\t <% }else {%>\n\t\t\t\t \t>\n\t\t\t\t <%}%>\n\t\t\t\t\t<% if(monthArray[i]){ %>\n\t\t\t\t\t\t<a href="javascript:;" class="now-day \n\t\t\t\t\t\t<%if(monthArray[i]==currentDate.nowDay && theYear==currentDate.nowYear && theMonth==currentDate.nowMonth){%> now-day-bg now-day-color<%}%> <%if(monthArray[i]==selectDate.date && theYear==selectDate.year && theMonth==selectDate.month){%> tap-day-bg<%}%>" data-date="<%=theYear%>-<%=formatedMonth%>-<%=formatedDay%>"><%=monthArray[i]%></a>\n\t\t\t\t\t<% } %>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t<%} else {%>\t\n\t\t\t\t<td  style="padding:5px;color: #221816; position:relative;" class="calendar-day" \n\t\t\t\t <% if(monthArray[i]) { %>\n\t\t\t\t \tdata-date="<%=theYear%>-<%=formatedMonth%>-<%=formatedDay%>">\n\t\t\t\t <% }else {%>\n\t\t\t\t \t>\n\t\t\t\t <%}%>\n\t\t\t\t\t<% if(monthArray[i]){ %>\n\t\t\t\t\t\t<a href="javascript:;" class="now-day \n\t\t\t\t\t\t<%if(monthArray[i]==currentDate.nowDay && theYear==currentDate.nowYear && theMonth==currentDate.nowMonth){%> now-day-bg now-day-color<%}%> <%if(monthArray[i]==selectDate.date && theYear==selectDate.year && theMonth==selectDate.month){%> tap-day-bg<%}%>" data-date="<%=theYear%>-<%=formatedMonth%>-<%=formatedDay%>"><%=monthArray[i]%></a>\n\t\t\t\t\t<% } %>\n\t\t\t\t</td>\n\t\t\t<%} %>\t\t \n\t\t<%}%>\n\t<%}%>\n\t<tr height="1px">\n\t\t<td colspan=7 style="border-bottom:1px solid  #EEE;"></td>\n\t</tr>\n</table>\n';});


define('text!module_calendarBf/template/eventList-template.html',[],function () { return '\n<div class="list" style="padding: 10px 16px;border-bottom:1px solid #eee;background: #FFFFFF;" data-group-type="<%=groupType%>" data-mark="<%=mark%>"  data-date="<%=date%>" data-address="<%=address%>" data-title="<%=title%>" data-startTime="<%=startTime%>" data-endTime="<%=endTime%>" data-allDay="<%=allDay%>" data-itemId="<%=id%>" data-remind="<%=remind%>" data-repeat="<%=repeat%>" data-remarks="<%=remarks%>" data-remindMark="<%=remindMark%>" data-thingid="<%=thingid%>" data-thingEndTime="<%=thingEndTime%>" data-from-search="<%=fromSearch%>" data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>">\n\t<div class="titles"  data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>"><%=title%></div>\n\t<div style="color: #9B9B9B;padding-top: 5px;width: 100%;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;"  data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>">\n\t\t<span  data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>">\n\t\t<%if(noDate){    //月历页面\n\t\t\tif(allDay == "true"){%>\n  \t\t\t\t全天\n\t\t\t<%}else{%>\n\t\t\t\t<%=startTimeHourMin%>-<%=endTimeHourMin%>\n\t\t\t<%}\n\t\t}else{  //搜索页面\n\t\t\tif(endDate==dateTime){//不跨天%>\n\t\t\t\t<%if(allDay == "true"){%>\n\t\t\t\t\t<%=dateTime%> 全天\n    \t\t\t<%}else{%>\n   \t\t\t\t\t<%=dateTime%> <%=startTimeHourMin%>-<%=endTimeHourMin%>\n   \t\t\t\t<%}%>\n \t\t\t<%}else{//跨天\n \t\t\t\tif(allDay == "true"){%>\n\t\t\t\t\t<%=dateTime%> 全天-<%=endDate%> 全天\n    \t\t\t<%}else{%>\n    \t\t\t\t<%=dateTime%> <%=startTimeHourMin%>-<%=endDate%> <%=endTimeHourMin%>\n    \t\t\t<%}\n \t\t\t}\n\t\t}%>\n\t\t</span>\n\t\t<span style="padding-left:5px;padding-right:5px" data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>">|</span><%=address==\'\'? \'待定\': address%>\n\t</div>\n</div>\n';});

/**
 * HTML5本地存储模块，DB实例
 */
define('module_calendarBf/../../butterfly/components/store',['zepto'], function($){

	var Store = function(){
		
	}

	Store.saveObject = function(key, object) {
		//做一下参数判断
		if(typeof object == "undefined" || object == null){
			object = null  ;  //赋值为空值，否则程序报错
		}
		window.localStorage[key] = JSON.stringify(object);
	}

	Store.loadObject = function(key) {
		var objectString =  window.localStorage[key];
		return objectString == null ? null : JSON.parse(objectString);
	}

	Store.deleteObject = function(key) {
		window.localStorage[key] = null;
	}

	Store.clear = function() {
		window.localStorage.clear();
	}

	return Store;
});
/**
 * 1、重复事件的日期间隔验证
 * 2、开始和结束时间验证
 */
define('module_calendarBf/js/validator',['jquery', './moment.min'], function($, moment) {
	// 获取页面对象
	var _getJQ = function(pageId, itemId) {
		return $('#' + pageId).find('#' + itemId);
	};
	
	var Validator = {
		// 为空 return false
		isEmpty: function(pageId, itemId) {
			if (_getJQ(pageId, itemId).val().trim() == '') {
				return false;
			} else {
				return true;
			}
		},

		// 判断开始时间是否小于 结束时间 
		setTimeIsRight: function(pageId, startTimeId, endTimeId, isAllDay) {
			//获取开始时间，结束时间

			var s_Time = _getJQ(pageId, startTimeId).val();
			var e_Time = _getJQ(pageId, endTimeId).val();
			if (endTimeId == "thingEndTime") {
				e_Time = e_Time + " 23:59";
			}
			// 处理时间
			var strarr = s_Time.split(' ');
			var endarr = e_Time.split(' ');
			//创建开始时间 结束 时间的对象
			if (isAllDay) {
				var strdate = new Date(parseInt(strarr[0].split('-')[0]), parseInt(strarr[0].split('-')[1]) - 1, parseInt(strarr[0].split('-')[2]));
				var enddate = new Date(parseInt(endarr[0].split('-')[0]), parseInt(endarr[0].split('-')[1]) - 1, parseInt(endarr[0].split('-')[2]));
			} else {
				var strdate = new Date(parseInt(strarr[0].split('-')[0]), parseInt(strarr[0].split('-')[1]) - 1, parseInt(strarr[0].split('-')[2]), parseInt(strarr[1].split(':')[0]), parseInt(strarr[1].split(':')[1]));
				var enddate = new Date(parseInt(endarr[0].split('-')[0]), parseInt(endarr[0].split('-')[1]) - 1, parseInt(endarr[0].split('-')[2]), parseInt(endarr[1].split(':')[0]), parseInt(endarr[1].split(':')[1]));
			}
			if (strdate.getTime() > enddate.getTime()) {
				return false;
			} else {
				return true;
			}
		},

		// 判断 开始时间 和结束 时间 的间隔
		setTimeDistance: function(pageId, startTimeId, endTimeId) {
			var stime, etime;
			if (startTimeId == "startTime") {
				stime = moment(_getJQ(pageId, startTimeId).val()).unix();
				etime = moment(_getJQ(pageId, endTimeId).val()).unix();
			} else {
				stime = moment(_getJQ(pageId, startTimeId).val()).unix();
				etime = moment(_getJQ(pageId, endTimeId).val()).add(23, "h").add(59, "m").add(59, "s").unix();
			};
			var startAndEnd = etime - stime;
			var arr_checklist = [];
			// alert(stime+" "+etime);
			// 间隔大于1天
			if (startAndEnd >= 60 * 60 * 24) {
				//return "day";
				arr_checklist.push("day");
			}
			// 间隔大于一周
			if (startAndEnd >= 60 * 60 * 24 * 7) {
				//return "week";
				arr_checklist.push("week");
			}

			// 间隔大于两周
			if (startAndEnd >= 60 * 60 * 24 * 14) {
				//return "two-week";
				arr_checklist.push("two-week");
			}

			//是否同一个月
			//console.log(moment(stime).format("YYYY")+" "+moment(etime).format("YYYY")+" "+moment(stime).format("MM")+" "+moment(etime).format("MM"))
			var isSameMonth = true;
			if (moment.unix(stime).format("YYYY") == moment.unix(etime).format("YYYY") && moment.unix(stime).format("MM") == moment.unix(etime).format("MM")) {
				isSameMonth = true;
			} else {
				isSameMonth = false;
			}

			// 间隔大于一个月
			if (startAndEnd >= 60 * 60 * 24 * 28 && !isSameMonth) {
				//return "month";
				arr_checklist.push("month");
			}
			var isSameYear = true;
			if (moment.unix(stime).format("YYYY") == moment.unix(etime).format("YYYY")) {
				isSameYear = true;
			} else {
				isSameYear = false;
			}
			// 间隔大于一年
			if (startAndEnd >= 60 * 60 * 24 * 365 && !isSameYear) {
				//return "year";
				arr_checklist.push("year");
			}
			return arr_checklist;
		},

		// repeat 和 时间间隔 类型 是否匹配的验证。
		repeatAndTime: function(pageId, startTimeId, endTimeId, repeatType) {

			var timeDistance = this.setTimeDistance(pageId, startTimeId, endTimeId);
			//alert(timeDistance);alert(repeatType);
			var returnText = '';
			switch (parseInt(repeatType)) {
				case 1:
					if ($.inArray("day", timeDistance) != -1) {
						returnText = "事件时间间隔过大，无法创建重复事件。";
					}
					break;
				case 2:
					if ($.inArray("week", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
					break;
				case 3:
					if ($.inArray("two-week", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
					break;
				case 4:
					if ($.inArray("month", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
					break;
				case 5:
					if ($.inArray("year", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
			}
			return returnText;
		}
	};
	return Validator;
});
/**
 * [新手指引方法]
 * by dyz 2016-08-03
 * @type {Object}
 */
/*
使用方法：
1,在页面中构造好指引遮罩和样式--html
2,初始化设置：isShowNewerGuide({//设置新手指引
                modal:"calendarBf",//模块唯一标识
                parentSelector:"#main",//模块顶级元素
                padId:".ui-newerGuide",//pad显示新手指引对应的html
                phoneId:".ui-newerGuide"//phone显示新手指引对应的html
            });
3,存储数据集获取：isShowNewerGuide("saveKey");
4,判断设备类型：isShowNewerGuide("deviceType");
5,清空新手指引已存在数据：isShowNewerGuide("clear");
*/
 
define('commonBf/js/isShowNewerGuide',[], function() {
    function NewerGuide(option) {
        this.setConfig(option);
        var canShow;
        if (!this.modal) { //必须传入要显示新手指引的页面唯一标识
            return;
        }
        //判断是否需要显示
        canShow=this.getFlag(this.modal);
      //  canShow = true; //测试
        if (!canShow) {
            return;
        }
        this.show();
        this._attachEvents();
    }
    NewerGuide.prototype = {
        uniqAttr:"ui-newer-guide", //新手指引模板唯一标识属性
        saveKey:"newerGuide_20180803",//存放新手指引显示与否唯一标识的前缀
        setConfig: function(option) {
          //  this.uniqAttr = "ui-newer-guide"; //新手指引模板唯一标识属性
          //  this.saveKey = "newerGuide_20180803"; //存放新手指引显示与否唯一标识的前缀
            //option参数
            this.modal = option.modal;//唯一模块标识，如日程管理模块，可用calendarBf,日程新增可用calendarAdd
            this.parentSelector = option.parentSelector || "body";//生成的新手指引dom所在的父元素
            this.padId=option.padId;//新手指引元素id--pad使用
            this.phoneId=option.phoneId;//新手指引元素id--phone使用

           // this.padUrl = option.padUrl;//新手指引图片url--pad使用
           // this.phoneUrl = option.phoneUrl;//新手指引图片url--phone使用
        },
        _events: [],
        _attachEvents: function() {
            // this._detachEvents();
            //绑定关闭事件
            var that = this;
            var uniqAttr = "[" + that.uniqAttr + "]";
            $(uniqAttr).one("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                that.remove();
            });
        },
        _detachEvents: function() {},
        /**
         * 显示新手指引元素
         * @return {[string]}  [无返回值]
         */
        show: function() {
            var tpl;
            var that = this;

            //标记已显示
            that.setFlag(that.modal);
            //删除旧的遮罩
            that.remove();
            //构造并显示
            tpl = that.create(); //构造新手指引元素
            //显示
           // $(that.parentSelector).append(tpl);

        },
        remove: function() { //关闭
            var that = this;
            var uniqAttr,parentSelector;
            parentSelector=that.parentSelector;
            uniqAttr = "[" + that.uniqAttr + "]";
            if ($(parentSelector+" "+uniqAttr).length) {
               // $(uniqAttr).remove();
               $(parentSelector+" "+uniqAttr).css("display","none");
            }
        },
        /**
         * [构造新手指引]
         * @return {[string]}  [返回模板字符串]
         */
        create: function() {
            var parentSelector,uniqAttr,padId,phoneId,id,height;
            var that=this;
            uniqAttr = that.uniqAttr;
            parentSelector=that.parentSelector;
            padId=that.padId;
            phoneId=that.phoneId;
            height=document.body.clientHeight;
            id = that.deviceType() === "pad" ? padId : phoneId;
            $(parentSelector+" "+id).attr(uniqAttr,true);
            $(parentSelector+" "+id).css("display","block");
            $(parentSelector+" "+id).height(height);
        },
        /**
         * [设置模块已显示过新手指引]
         * @param {[string]} modal [需要设置已显示新手指引标识的页面唯一标识符]
         */
        setFlag: function(modal) {
            var that = this;
            var saveKey = that.saveKey
            val = true;
            modal = modal.replace(/\.|\/|\\/g, "_");

            var obj = window.localStorage.getItem(saveKey);
            obj = obj ? $.parseJSON(obj) : {};
            obj[modal] = true;

            window.localStorage.setItem(saveKey, JSON.stringify(obj));
        },
        /**
         * [获取模块是否已显示新手指引]
         * @param  {[string]} modal [需要判断的页面唯一标识符]
         * @return {[boolen]}       [需要显示返回true,不需要显示返回false]
         */
        getFlag: function(modal) {
            var that = this;
            var saveKey = that.saveKey;
            modal = modal.replace(/\.|\/|\\/g, "_");
            var obj = window.localStorage.getItem(saveKey);

            obj = obj ? $.parseJSON(obj) : {};

            return !obj[modal];
        },
        /**
         * 检测当前设备
         * @return {[string]} [若是pad则返回pad,否则返回phone]
         */
        deviceType: function() {
            var pad = ["iPad"],
                padReg = new RegExp('(.+\\\()(' + pad.join("\|") + ')(.+\\\).+)');
            var brand = window.navigator.appVersion.replace(padReg, '$2');
           //   var brand=bsl.infinitus.tools.getCommonParam()[0].brand;//使用原生方式判断机型
            if (pad.indexOf(brand) !== -1) {
                return "pad";
            } else {
                return "phone";
            }
        },
        clear:function(){//清空新手指引数据
            var saveKey = this.saveKey;
            window.localStorage.removeItem(saveKey);
        }
    };

   return function(){
        //显示新手指引---by dyz 2016-08-03
        //参数详见setConfig
        var args = Array.apply(null, arguments);
        if(typeof args[0]==="string"){
            if(!NewerGuide.prototype[args[0]]){
                return ;
            }
            if(typeof NewerGuide.prototype[args[0]]==="function"){
                return NewerGuide.prototype[args[0]]();
            }else{
                return NewerGuide.prototype[args[0]];
            }
        }else{
            new NewerGuide(args[0]);
        }
   };
});

define('module_calendarBf/calendarAdd',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'bsl',
	'../../butterfly/components/store',
	 './js/validator', './js/calendarFunc', './js/common', './js/moment.min','init','jroll',
	'../commonBf/js/isShowNewerGuide'

], function($, View, calendarTpl, eventListTpl, EMCSUtil, bsl, Store, Validator, Func, CalendarCommon, moment, init, JRoll,isShowNewerGuide) {
	/**
	 * 设置返回动作，默认直接返回；设置动作后由开发者控制返回操作
	 * @param sFunName String 点击返回键或返回按钮时调用的JS 参数可选
	 */

	window.backAction = function() {
		var localsion = window.location.href;
		var localcalendarAdd = localsion.indexOf("calendarAdd"); //新建事件
		var localcalendarDetails = localsion.indexOf("calendarDetails"); //事件详情
		var localcalendarEdit = localsion.indexOf("calendarEdit"); //编辑事件
		var localcalendarSearch = localsion.indexOf("calendarSearch"); //搜索事件
		var localcalendarRemind = localsion.indexOf("calendarRemind"); //非全天提醒
		var localcalendarRemindAllday = localsion.indexOf("calendarRemind-Allday"); //全天提醒
		var localcalendarRepeat = localsion.indexOf("calendarRepeat"); //重复
		var localmain = localsion.indexOf("main");
		var activeName = document.activeElement.nodeName;
		if (activeName == "INPUT" || activeName == "TEXTAREA") {
			$("input").blur();
			$("textarea").blur();
			return;
		};
		if (localmain > -1) {
			bsl.infinitus.transfer.returnBack(true);
		} else if (localcalendarAdd > -1) {
			//$(window).trigger('resetClickTimes');
			if (Store.loadObject("calendarBf_remind") == "remind") {
				Store.deleteObject("calendarBf_remind");
				$("#calendarRemind").remove();
			} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
				Store.deleteObject("calendarBf_remindAllday");
				$("#calendarRemind-Allday").remove();
			} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
				Store.deleteObject("calendarBf_repeat");
				$("#calendarRepeat").remove();
			} else {
				if (Store.loadObject("calendarBf_add") == "add") {
					//bsl.infinitus.transfer.returnBack(false, "", function(data) {});
					$("#calendarAdd .back").trigger("click");
				}
			}
		} else if (localcalendarDetails > -1) {
			if ($("#calendarDetails #DivYY").css("display") != "none") {
				$("#calendarDetails #DivYY").hide();
				$("#calendarDetails #deleteDiv").hide();
				$("#calendarDetails #deleteDivOnly").hide();
			} else {
				if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
					//Util.navigate('module_calendarBf/calendarSearch');
					window.butterfly.navigate('module_calendarBf/calendarSearch', {
						trigger: true
					});
				} else {
					window.butterfly.navigate('module_calendarBf/main', {
						trigger: true
					});
				}
			}
		} else if (localcalendarEdit > -1) {
			if ($("#calendarEdit #DivYY").css("display") != "none") {
				$("#calendarEdit #DivYY").hide();
				$("#calendarEdit #saveDiv").hide();
			} else {
				//$(window).trigger('resetClickTimes');
				if (Store.loadObject("calendarBf_remind") == "remind") {
					Store.deleteObject("calendarBf_remind");
					$("#calendarRemind").remove();
				} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
					Store.deleteObject("calendarBf_remindAllday");
					$("#calendarRemind-Allday").remove();
				} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
					Store.deleteObject("calendarBf_repeat");
					$("#calendarRepeat").remove();
				} else {
					if (Store.loadObject("calendarBf_edit") == "edit") {
						//bsl.infinitus.transfer.returnBack(false, "", function(data) {});
						$("#calendarEdit .back").trigger("tap");
					}
				}
			}
		} else if (localcalendarSearch > -1) {
			window.butterfly.navigate('module_calendarBf/main', {
				trigger: true
			});
		}

	};
	var me = null;
	var dealerNo = '';

	var remindArrText = ["无", "事件发生时", "5分钟前", "15分钟前", "30分钟前", "1小时前", "2小时前", "1天前", "2天前", "1周前", "当天(9:00)", "1天前(9:00)", "2天前(9:00)", "1周前(9:00)"];
	var repeatArrText = ["永不", "每天", "每周", "每两周", "每月", "每年"];

	var isPad = Store.loadObject("calendarBf_isPad"); // 判断 ipad

	var isApple = Store.loadObject("calendarBf_isApple"); // 判断 是否 苹果设备

	//------chenjm
	
	var remindMark = null; // 生成的重复 事件的，统一id， 删除全部事件用这个 id
	var ipadSave = true; // 用于解决ipad 重复显示的问题
	var value, saveDone = false;
	var jroll;
	var model = View.extend({
		events: {
			"click #module-calendarBf-calendarAdd #remindBtn": "remind",
			"click #module-calendarBf-calendarAdd #repeatBtn": "repeat",
			"touchend #module-calendarBf-calendarAdd .toggle": "statu_change",
			"click #module-calendarBf-calendarAdd .dialog-save": "dialogSave", //保存
			//日历选择插件
			"tap #module-calendarBf-calendarAdd #startTime, #module-calendarBf-calendarAdd #endTime": "setTime",
			"tap #module-calendarBf-calendarAdd #startTimeall, #module-calendarBf-calendarAdd #endTimeall, #module-calendarBf-calendarAdd #thingEndTime": "setTimeall",
			"focus #module-calendarBf-calendarAdd input": "showBtnClear",
			"input #module-calendarBf-calendarAdd input": "showBtnClear",
			"blur #module-calendarBf-calendarAdd input": "hideBtnClear",
			"input #module-calendarBf-calendarAdd .canClear": "checkNum",
			"tap #module-calendarBf-calendarAdd textarea": "focusArea"
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		render: function() {
			me = this;
			me.noDoubleTap();
		},
		getBack: function() {
			me.animateSlideOutRight();
			//me.parentView.refreshInf();
			me.parentView.addPage = null;
			setTimeout(function() {
				$(me.el).remove();
				$("#shadow-dialg").css({
					"z-index": "-1"
				})
			}, 200);
			$("#pad-dialog").css("border", "none");
		},
		remindPage: null,
		remind: function() {
			$("#calendarAdd #tittle").blur();
			$("#calendarAdd #address").blur();
			$("#calendarAdd #remarks").blur();
			if (me.tapTime == 1) { //防止多次点击
				me.noDoubleTap();
				if ($("#calendarAdd #idAllDay").hasClass('active')) {
					me.showInnerPage(me.remindPage, "calendarRemind-Allday");
					if (!isPad) {
						Store.saveObject("calendarBf_remindAllday", "remindAllday");
					}
				} else {
					me.showInnerPage(me.remindPage, "calendarRemind");
					if (!isPad) {
						Store.saveObject("calendarBf_remind", "remind");
					}

				}
			}

		},
		repeatPage: null,
		resetClickTimes: function() {
			me.clickTimes = 1;
		},
		repeat: function() {
			$("#calendarAdd #tittle").blur();
			$("#calendarAdd #address").blur();
			$("#calendarAdd #remarks").blur();
			if (me.tapTime == 1) { //防止多次点击
				me.noDoubleTap();
				me.showInnerPage(me.repeatPage, "calendarRepeat");
			}
			if (!isPad) {
				Store.saveObject("calendarBf_repeat", "repeat");
			}
		},

		//全天设置时间
		setTimeall: function(e) {
			$("input").blur();
			if (me.tapTime != 1) return; //打开了其它页面，就不要再弹出时间了
			var target = e.target;
			var realtarget;
			var repeatType = Store.loadObject("calendarBf_repeat_type");
			if (target.id == "startTimeall") {
				realtarget = $("#calendarAdd #startTime");
			} else if (target.id == "endTimeall") {
				realtarget = $("#calendarAdd #endTime");
			} else if (target.id == "thingEndTime") {
				realtarget = $("#calendarAdd #thingEndTime");
			}
			var dateJson = {
				"selectDate": $(target).val() + " 00:00:00",
				"MaxDate": "2100-01-01 00:00:00",
				"MinDate": "2000-01-01 00:00:00"
			};
			if (target.id == "thingEndTime") {
				dateJson.MaxDate = me.calThingEndTime() + " 00:00:00";
				dateJson.MinDate = $("#calendarAdd #endTime").val() + ":00";
			};

			if (isApple) {
				bsl.infinitus.tools.showDatePicker(0, JSON.stringify(dateJson), function(date) {
					var time = $(realtarget).val().split(' ')[1];
					$(realtarget).val(date.split(' ')[0] + " " + time);
					$("#calendarAdd #startTimeall").val($("#calendarAdd #startTime").val().split(' ')[0]);
					$("#calendarAdd #endTimeall").val($("#calendarAdd #endTime").val().split(' ')[0]);
					$("#calendarAdd #thingEndTime").val($("#calendarAdd #thingEndTime").val().split(' ')[0]);
					if (!Validator.setTimeIsRight("calendarAdd", "startTime", "endTime")) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					var endTime = moment($("#calendarAdd #endTime").val()).unix();
					var thingEngTime = moment($("#calendarAdd #thingEndTime").val() + ' 23:59:59').unix();
					if (endTime > thingEngTime && parseInt(repeatType) != 0) {
						bsl.infinitus.tools.showToast("重复结束时间 必须 大于 结束时间", 2000);
					}
					if (target.id != "thingEndTime") {
						me.calThingEndTime(); //重新计算重复结束的默认时间。
					};
				});
			} else {
				bsl.infinitus.tools.showDatePicker(0, JSON.stringify(dateJson), function(date) {
					var time = $(realtarget).val().split(' ')[1];
					$(realtarget).val(date + ' ' + time);
					$("#calendarAdd #startTimeall").val($("#calendarAdd #startTime").val().split(' ')[0]);
					$("#calendarAdd #endTimeall").val($("#calendarAdd #endTime").val().split(' ')[0]);
					$("#calendarAdd #thingEndTime").val($("#calendarAdd #thingEndTime").val().split(' ')[0]);
					if (!Validator.setTimeIsRight("calendarAdd", "startTime", "endTime")) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					var endTime = moment($("#calendarAdd #endTime").val()).unix();
					var thingEngTime = moment($("#calendarAdd #thingEndTime").val() + ' 23:59:59').unix();
					if (endTime > thingEngTime && parseInt(repeatType) != 0) {
						bsl.infinitus.tools.showToast("重复结束时间 必须 大于 结束时间", 2000);
					}
					if (target.id != "thingEndTime") {
						me.calThingEndTime(); //重新计算重复结束的默认时间。
					};
				});
			}

		},

		//设置时间
		setTime: function(e) {
			//alert("设置时间");
			$("input").blur();
			if (me.tapTime != 1) return; //打开了其它页面，就不要再弹出时间了
			var target = e.target;
			// ios 和 android 处理方式不同。ios直接选择时间日期， Android分开进行
			if (isApple) {
				bsl.infinitus.tools.showDatePicker(2, $(target).val() + ":00", function(date) {
					$(target).val(date.slice(0, -3));

					if (!Validator.setTimeIsRight("calendarAdd", "startTime", "endTime")) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					if (target.id != "thingEndTime") {
						me.calThingEndTime(); //重新计算重复结束的默认时间。
					};
				});
			} else {
				bsl.infinitus.tools.showDatePicker(1, $(target).val() + ":00", function(date) {
					$(target).val(date.slice(0, -3));
					if (!Validator.setTimeIsRight("calendarAdd", "startTime", "endTime")) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					if (target.id != "thingEndTime") {
						me.calThingEndTime(); //重新计算重复结束的默认时间。
					};

				});
			}
		},

		// 获取当前时间并返回 固定格式 参数为分钟
		getNowDate: function(time) {
			time = time ? time : 0;
			var theDate = new Date(new Date().getTime() + (1000 * 60 * time));

			var hours = theDate.getHours() < 10 ? "0" + theDate.getHours() : theDate.getHours();
			var minutes = theDate.getMinutes() < 10 ? "0" + theDate.getMinutes() : theDate.getMinutes();
			return ' ' + hours + ':' + minutes;
		},
		// 设置开始时间和结束时间的间隔
		setHour: function() {
			var userTapDate = moment(Store.loadObject("calendarBf_userClickDate"), "YYYY-M-D").format("YYYY-MM-DD");
			$("#calendarAdd #startTime").val(userTapDate + me.getNowDate());
			$("#calendarAdd #endTime").val(moment($("#calendarAdd #startTime").val()).add(1, "h").format("YYYY-MM-DD HH:MM"));
		},
		onShow: function() {
			bsl.infinitus.tools.getUserInfo(function(data) {
				if (typeof(data) == "string") {
	                data = JSON.parse(data);
	            }
				dealerNo = data.authAttr.dealerNo;
			});
			isShowNewerGuide({//设置新手指引-by dyz --2016-08-03
				modal:"calendarBf_calendarAdd",
				parentSelector:"#calendarAdd",
				padId:".ui-newerGuide",
				phoneId:".ui-newerGuide"			
			});
			$(window).bind('calThingEndTime', function() {
				me.calThingEndTime();
			});
			if (!isPad) {
				Store.saveObject("calendarBf_add", "add");
				if (isInApp) {
					bsl.infinitus.tools.setBackAction(backAction);
				} else {}
			}

			remindMark = Func.randomString(8); // 更新重复事件统一id
			// 如果是pad 修改头部显示信息
			if (isPad) {
				$("#calendarAdd span.icon-left-nav").text("取消");
				$("#calendarAdd span.icon-left-nav").css("font-size", "16px");
				$("#calendarAdd span.icon-left-nav").removeClass("icon-left-nav");
				$("#calendarAdd .bar").css("position", "absolute");
			}

			// 设置开始时间和结束时间的间隔(1小时)
			me.setHour();

			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			Store.saveObject("calendarBf_isFirstEnter_two", true);

			if (isPad) {
				$("#shadow-dialg").off("tap");
			}
			$("#calendarAdd .back").on("tap", function() {
				$("#calendarAdd #tittle").blur();
				$("#calendarAdd #address").blur();
				$("#calendarAdd #remarks").blur();
				if ($("#calendarAdd #tittle").val() == "" && $("#calendarAdd #address").val() == "" && $("#calendarAdd #remarks").val() == "") {
					if (isPad) {
						me.getBack();
					} else {
						window.butterfly.navigate('module_calendarBf/main', {
							trigger: true
						});
					}
				} else {
					bsl.infinitus.tools.showDialog("提示", "是否保存内容？", ['是', '否'], function(tap) {
						if (!tap) {
							me.dialogSave();
						} else {
							if (isPad) {
								me.getBack();
							} else {
								window.butterfly.navigate('module_calendarBf/main', {
									trigger: true
								});
							}
						}
					});
				}
			});
			me.set_repeat_remind();
			Func._addDeleteBtn(10, 2);
			me.showNewUserTips();

			jroll = new JRoll("#calendar-moudel-calendarAdd", {
				bounce: true,
				scrollX: false
			});

			$("#remarks").blur(function(){
				jroll.refresh();
			});
			bsl.infinitus.cat.analytics({
                "category": "添加日程",
                "action": "浏览",
                "label": "",
                "value": ""
            });
		},
		showNewUserTips: function() {
			var tipsData = localStorage.getItem("calendarBf_addTips"),
				tips = $("#calendarAdd .newUserTips");
			if (tipsData !== "yes") {
				if (isPad) {
					$("#calendarAdd .ipadTips").css("display", "block");
				} else {
					$("#calendarAdd .phoneTips").css("display", "block");
				};
				tips.on("click", function() {
					tips.css("display", "none");
					localStorage.setItem("calendarBf_addTips", "yes");
				});
			};
		},
		// 设置 重复事件 和 重复事件的值
		set_repeat_remind: function() {

			if (typeof Store.loadObject("calendarBf_remind_type") !== 'undefined') {
				$("#calendarAdd #remind").text(remindArrText[Store.loadObject("calendarBf_remind_type")]);
				$("#calendarAdd #remind").attr("data-type", Store.loadObject("calendarBf_remind_type"));
			}

			if (typeof Store.loadObject("calendarBf_repeat_type") !== "undefined") {
				$("#calendarAdd #repeat").text(repeatArrText[Store.loadObject("calendarBf_repeat_type")]);
				$("#calendarAdd #repeat").attr("data-type", Store.loadObject("calendarBf_repeat_type"));
				var date = new Date();
				//$("#calendarAdd #thingEndTime").val(moment().format('YYYY-MM-DD'));
				Store.loadObject("calendarBf_repeat_type") != 0 ? $("#calendarAdd #thingEndTimeDiv").show() : $("#calendarAdd #thingEndTimeDiv").hide();

			}


		},
		// 开关切换
		statu_change: function() {
			$("#calendarAdd #idAllDay").toggleClass("active");
			if ($("#calendarAdd #idAllDay").hasClass("active")) {
				$("#calendarAdd #startTimeall").val($("#calendarAdd #startTime").val().split(' ')[0]);
				$("#calendarAdd #endTimeall").val($("#calendarAdd #endTime").val().split(' ')[0]);

				$("#calendarAdd #formNoAll").hide();
				$("#calendarAdd #formAll").show();
				me.remind_initialize();
			} else {
				var Sval = $("#calendarAdd #startTime").val().split(' ')[1];
				var Eval = $("#calendarAdd #endTime").val().split(' ')[1]
				$("#calendarAdd #formNoAll").show();
				$("#calendarAdd #formAll").hide();
				me.remind_initialize();
			}
		},
		// 初始化提醒“无”
		remind_initialize: function() {
			$("#calendarAdd #remind").text(remindArrText[0]);
			$("#calendarAdd #remind").attr("data-type", 0);
			Store.saveObject("calendarBf_remind_type", "0");
		},
		dialogSave: function() {
			$("input").blur();
			var allDay = false;
			var overTimeIsOK = true;
			var repeatType = parseInt(Store.loadObject("calendarBf_repeat_type"));
			var repeatype = $("#calendarAdd #repeat").attr("data-type");
			if ($("#calendarAdd #idAllDay").hasClass("active")) {
				allDay = true;
			};
			var timeIsOk = Validator.setTimeIsRight("calendarAdd", "startTime", "endTime", allDay);
			var isTitleEmpty = Validator.isEmpty("calendarAdd", "tittle");
			if (repeatType != 0) {
				overTimeIsOK = Validator.setTimeIsRight("calendarAdd", "endTime", "thingEndTime", allDay);
			}

			if (!isTitleEmpty) {
				bsl.infinitus.tools.showDialog("提示", "请输入事件标题。", ["确定"], function() {});
				return;
			}

			if (!timeIsOk) {
				bsl.infinitus.tools.showDialog("提示", "无法存储事件，开始时间必须早于结束时间。", ["确定"], function() {});
				return;
			}
			if (!overTimeIsOK) {
				bsl.infinitus.tools.showDialog("提示", "无法存储事件，结束重复时间必须晚于结束时间。", ["确定"], function() {});
				return;
			};
			if (allDay) {
				var timeText = Validator.repeatAndTime("calendarAdd", "startTimeall", "endTimeall", repeatype);
			} else {
				var timeText = Validator.repeatAndTime("calendarAdd", "startTime", "endTime", repeatype);
			}

			if (timeText != '') {
				bsl.infinitus.tools.showDialog("提示", timeText, ["确定"], function() {});
				return;
			}


			// 标明是ipad的存储
			if (isPad) {
				ipadSave = true;
			}

			if (me.tapTime == 1 && !me.saveDone) { //防止多次点击
				me.saveDone = true;
				me.noDoubleTap();
				me.getNewInfSave($("#calendarAdd #startTime").val(), $("#calendarAdd #endTime").val());
			}
		},

		// 获取页面数据 并存储
		getNewInfSave: function(startTime, endTime) {
			if (!Store.loadObject("calendarBf_isApple") && isInApp) bsl.infinitus.tools.showLoading("保存中 ...");
			//获取页面数据
			var theObj = Func.getPageInf('calendarAdd', remindMark);

			// 增加事件

			var thing = Func.getThingInf('calendarAdd', remindMark);
			thing.datafrom = 'client';
			thing.readonly = false;
			thing.dealerNo = dealerNo;
			thing.groupType = 99;
			thing.state = 1;
			thing.type = '';
			thing.showApply = false;
			thing.isApply = 0;

			CalendarCommon.init();
			CalendarCommon.pageCalendarAdd(thing, function(data) {
				var mainDate = theObj.startTime.split(' ')[0];
				if (theObj.repeat == 0) {
					var currentDate = mainDate.replace(/-0/g, '-');
					Store.saveObject("calendarBf_displayDate", currentDate);
				}
				var mainDateObj = {};
				mainDateObj = {
					year: mainDate.split('-')[0],
					month: mainDate.split('-')[1],
					date: mainDate.split('-')[2],
				}
				Store.saveObject("calendarBf_selectDate", mainDateObj);
				//添加提醒
				CalendarCommon.initRemind(function() {
					// 判断是否是ipad
					var theObj = Func.getPageInf('calendarAdd', remindMark);
					var isIos = Store.loadObject("calendarBf_isApple");
					if (parseInt(theObj.remind) != 0 && isIos == true) { //有提醒且是IOS系统
						bsl.infinitus.lcnotifiction.getNavigationStatus(function(sCallback) {
							if (parseInt(sCallback) == 0) {
								bsl.infinitus.tools.showDialog("提示", "如果开启提醒功能，请在系统设置中，开启通知", ['关闭', '前往设置'], function(tap) {
									if (!tap) {
										me.goback();
									} else {
										// 系统设置代码
										me.goback();
										bsl.infinitus.tools.openSettingsURLString();
									}
								});
							} else {
								me.goback();
							}
						})

					} else {
						me.goback();
					}


				});

			}, function(err) {
				bsl.infinitus.tools.showToast('添加失败', 2000);
			});
		},
		goback: function() {

			// 判断是否是ipad
			if (isPad && ipadSave) {
				ipadSave = false;
				// 保证在存储过程中ipad 只执行一次。
				setTimeout(function() {
					me.animateSlideOutDown();
					me.parentView.addPage = null;
					me.parentView.show();
					setTimeout(function() {
						$(me.el).remove();
						$("#shadow-dialg").css({
							"z-index": "-1"
						})
					}, 200);
					bsl.infinitus.tools.dismissLoading();
				}, 500);
			} else {
				window.butterfly.navigate('module_calendarBf/main', {
					trigger: true
				});
			};

		},
		showDbSelectThing: function() {
			CalendarCommon.pageCalendarSelectAllThing(
				function(itemArr) {
					var log = "";

					for (var i = 0; i < itemArr.length; i++) {
						var item = itemArr.item(i);
						log += 'title:' + item.title + ',allDay:' + item.allDay + ',address:' + item.address + ',startTime:' + item.startTime + ',endTime:' + item.endTime + ',remarks:' + item.remarks + ',remindMark:' + item.remindMark + ',thingEndTime:' + item.thingEndTime + ',remind:' + item.remind + ',repeat:' + item.repeat + ',modifyids:' + item.modifyids + '\n';
					};
					$("#remarks").val(log);
				},
				function() {

				}
			);
		},

		showDbSelectItem: function() {
			var startTime = 1;
			var endTime = 100000000000000000;
			CalendarCommon.pageGetCalendarItemByStartEndTime(startTime, endTime,
				function(itemArr) {
					var log = "";
					for (var i = 0; i < itemArr.length; i++) {
						var item = itemArr[i];
						log += " item:" + item.id + ",thingid:" + item.thingid + ",date:" + item.date + ',title:' + item.title + ',allDay:' + item.allDay + ',address:' + item.address + ',startTime:' + item.startTime + ',endTime:' + item.endTime + ',remarks:' + item.remarks + ',remindMark:' + item.remindMark + ',remindTime:' + item.remindTime + ',modify:' + item.modify + '\n';
					};
					$("#remarks").val(log);
				},
				function(e) {
					$("#remarks").val("error");
				}
			);
		},

		// 页面内加载页面
		showInnerPage: function(pageObjet, html) {
			if (pageObjet) {
				pageObjet.show();
				pageObjet.$el.css({
					'display': 'block'
				});
				pageObjet.animateSlideInUp();
			} else {
				require(['view!module_calendarBf/' + html + '.html'], function(ViewClass) {
					pageObjet = new ViewClass();
					pageObjet.$el.css({
						'position': 'absolute',
						'top': '0px',
						'bottom': '0px',
						'width': '100%',
						'z-index': 1000
					});
					pageObjet.parentView = me;
					pageObjet.render();
					me.el.appendChild(pageObjet.el);
					pageObjet.show();
				}, function(err) {
					bsl.infinitus.tools.showToast("操作失败，请重试", 2000);
				});
			};
		},

		showBtnClear: function(e) {
			var target = e.target;
			var val = $(target).val();
			if (val != "") {
				$(target).next("span").show();
			} else {
				$(target).next("span").hide();
			};
		},
		hideBtnClear: function(e) {
			var target = e.target;
			$(target).next("span").hide();
		},
		checkNum: function(e) {
			var target = e.target;
			var val = $(target).val();
			if ($(target).hasClass("titleInput")) {
				if (val.length <= 40) {
					value = val;
				} else {
					$(target).val(value);
				};
			} else {
				if (val.length <= 60) {
					value = val;
				} else {
					$(target).val(value);
				};
			};
		},
		noDoubleTap: function() {
			me.tapTime = 2;
			setTimeout(function() {
				me.tapTime = 1;
			}, 1000);
		},
		focusArea: function() {
			$("#calendarAdd textarea").focus();
			if (!isPad) {
				setTimeout(function() {
					$("#calendarAdd .content").scrollTop(300);
				}, 500);
			};
		},
		calThingEndTime: function() {
			var val;
			var endTime = moment($("#calendarAdd #endTime").val());
			var thingEndTime = $("#calendarAdd #thingEndTime");
			var repeatType = parseInt(Store.loadObject("calendarBf_repeat_type"));
			if (repeatType == 1) {
				val = moment(endTime).add(7, "days");
				maxVal = moment(endTime).add(1, "years");
				if (thingEndTime.val() == "") { //如果为空时，表示之前未激活，填入默认结束重复时间
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix(); //如果不为空，获取已有的结束时间
					var unixEndTime = moment(endTime).unix(); //获取此时的事件结束时间
					var unixMaxVal = moment(maxVal).unix(); //将最大结束重复时间转为unix时间
					if (unixThingEndTime <= unixEndTime) { //如果小于或等于结束时间，则设置为结束时间（即重复的最小值）
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) { //如果大于或等于最大结束重复时间，则设置为结束重复最大值
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == 2) {
				val = moment(endTime).add(1, "months");
				maxVal = moment(endTime).add(3, "years");
				if (thingEndTime.val() == "") {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == 3) {
				val = moment(endTime).add(2, "months");
				maxVal = moment(endTime).add(5, "years");
				if (thingEndTime.val() == "") {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == 4) {
				val = moment(endTime).add(1, "years");
				maxVal = moment(endTime).add(10, "years");
				if (thingEndTime.val() == "") {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == 5) {
				val = moment(endTime).add(5, "years");
				maxVal = moment(endTime).add(20, "years");
				if (thingEndTime.val() == "") {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			}
		}
	});
	return model;
});

define('text!module_calendarBf/calendarDetails.html',[],function () { return '<div data-view="calendarDetails" id="calendarDetails" class="views" style="overflow: hidden;">\n\t<style>\n        #calendarDetails{\n\t\tbackground:#F2F2F2 ;\n\t\t}\n    #calendarDetails #section_wrap{\n    \tpadding-top:10px;\n    \tfont-family: arial,YouYuan;\n    }\n\n    #calendarDetails .padding-right11{\n    \tpadding-right:11px;\n    }\n   \t#calendarDetails .margin-right11{\n   \t\tmargin-right:-11px;\n   \t}\n   \t#calendarDetails .table-view-cell{\n   \t\tcolor:#000;\n   \t\tpadding-top:15px;\n   \t\tpadding-bottom:15px;\n   \t}\n   \t#calendarDetails .content-padded{\n   \t\tmargin:0;\n   \t\tpadding:2px 11px 11px 15px;\n   \t\tbackground-color: #fff;\n   \t}\n   \t\n\n\t#calendarDetails .sure-btn{border-right: 1px solid #e4e4e4;border-bottom-left-radius:8px;}\n\t#calendarDetails .close-btn{border-bottom-right-radius:8px;}\n\t#calendarDetails .del-made-title{padding:8px 0;}\n\t#calendarDetails .del-title{\n\t\tdisplay: block;\n\t    height: 30px;\n\t    font-size: 20px;\n\t    line-height: 45px;\n\t    color: #5BABA2;\n\t}\n\t#calendarDetails .del-conter{\n\t\theight: 110px;\n\t    display: block;\n\t    line-height: 110px;\n\t    border-top: 1px solid #e4e4e4;\n\t    font-size: 16px;\n\t}\n\t#calendarDetails #tittle{\n\t\tcolor: #5D5755;\n\t}\n\t#calendarDetails #remarks{\n\t\tfont-size:15px;\n\t\tcolor:#9D9D9D;\n\t\tword-break: break-word;\n\t}\n\t#calendarDetails #address{\n\t\tfont-size:15px;\n\t\tcolor:#9D9D9D;\n\t\t\n    \tmargin-bottom: 1%;\n\t}\n\t#calendarDetails li{\n\t\tcolor: #9D9D9D;\n\t}\n\n\t#calendarDetails li span{\n\t\tcolor: #9D9D9D\n\t}\n\t#calendarDetails div .content-padded{\n\t\tmargin-top: 3%;\n\t}\n\n\t#calendarDetails .bar-tab .tab-item span{\n\t\t\tfont-size: 20px;\n\t\t\tcolor:#5baba2;\n\t}\n\n\t#calendarDetails .bar-tab .tab-item .icon{\n\t\ttop:0;\n\t}\n\n\t#calendarDetails .bar-tab .tab-item .icon, .bar-tab .tab-item span{\n\t\tdisplay:inline-block;\n\t\tborder-radius: 50%;\n\t\tborder:1px solid #5baba2;\n\t\theight:36px;\n\t\twidth:36px;\n\t\tline-height:36px;\n\t}\n\t#calendarDetails #DivYY{\n\t    background-color: rgba(0,0,0,0.5);\n\t    width:100%;\n\t    height:100%;\n\t    position:absolute;\n\t    left:0;top:0;\n\t    display: none;\n\t    transition:0.3s;\n\t    z-index: 10;\n  \t}\n\t#calendarDetails .Details-titles{\t\n\t\theight: 30px;\n\t    display: block;\n\t    line-height: 30px;\n\t    text-align: center;\n\t    margin-bottom: 5px;\n\t}\n\t#edit{\n\t\tbackground-image: url(./images/edit.png);\n\t\tbackground-size: 36px;\n\t\tborder-width: 0px;\n\t\tmargin-top: 7px;\n\t}\n\t.back .font16{\n\t\tfont-size: 16px;\n\t}\n\t</style>\n\t<div id=\'module-calendarBf-calendarDetails\'>\n\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t<div class="ui3-row-12">\n\t\t\t<div class="ui3-col-3 ui3-icon-back back" data-click-label="返回">返回</div>\n\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">事件详情</div>\n\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"></div>\n\t\t</div>\n\t</header>\n\n    <!--<header class="bar bar-nav blue-bar top-background-color">\n        <button class="btn btn-link btn-nav pull-left back">\n            <span class="icon icon-left-nav  back_icon rachicons font16"><span class="youyuan">返回</span></span>\n        </button>\n        <h1 class="title">事件详情</h1>\n    </header>-->\n    <div class="content" style="background: #F2F2F2;overflow-y: auto;position: absolute;top:0.88rem;left:0px;right:0px;bottom:51px"><!-- 重要,如果调整了content上下的固定栏的高度,这里也要做相应的调整 -->\n\n    \t<!--fix ipad可上下拖动body-->\n    \t<div style="height:0px;overflow:hidden"><span><section><ul><li></li></ul></section></span></div>\n    \t<section id="section_wrap">\n    \t\t\n    \t\t<ul class="table-view" style="margin-top:6%;border-bottom:none;">\n\t\t\t  \t<li class="table-view-cell padding-right11">\n\t\t\t  \t\t<span style="display:none;">标题</span><span class="" id="tittle" ></span>\n\t\t\t  \t</li>\n\t\t\t  \t<li class="table-view-cell padding-right11">\n\t\t\t  \t\t<span style="display:none;">备注</span><span class="" id="remarks" ></span>\n\t\t\t  \t</li>\n\t\t\t \t<li class="table-view-cell padding-right11">\n\t\t\t \t\t<span style="display:none;">地点</span><span class="" id="addrs" ></span>\n\t\t\t \t</li>\n\t\t\t</ul>\n    \t\t<ul class="table-view" style="margin-top:6%;border-bottom:none;">\n\t  \t\t\t<li class="table-view-cell padding-right11 no-all-time">\n\t  \t\t\t\t开始时间\n\t  \t\t\t\t<span class="pull-right" id="startTime"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11 no-all-time">\n\t  \t\t\t\t结束时间\n\t  \t\t\t\t<span class="pull-right" id="endTime"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11 all-time"style="display:none;">\n\t  \t\t\t\t时间\n\t  \t\t\t\t<span class="pull-right"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11 all-time-start"style="display:none;">\n\t  \t\t\t\t开始时间\n\t  \t\t\t\t<span class="pull-right"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11 all-time-end"style="display:none;">\n\t  \t\t\t\t结束时间\n\t  \t\t\t\t<span class="pull-right"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11 oneday-time" style="display:none;">\n\t  \t\t\t\t时间\n\t  \t\t\t\t<span class="pull-right"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11">\n\t  \t\t\t\t提醒时间\n\t  \t\t\t\t<span class="pull-right" id="extendInf"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11">\n\t  \t\t\t\t重复\n\t  \t\t\t\t<span class="pull-right" id="extendInf_repeat"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11 repeat_over" style="display: none;">\n\t  \t\t\t\t重复结束\n\t  \t\t\t\t<span class="pull-right" id="extendInf_repeat_over"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li style="height: 50px;background-color: #F2F2F2;"></li>\n\t  \t\t</ul>\n    \t</section>\n\n\t</div>\n\n\t<nav class="bar bar-tab">\n\t\t<a class="tab-item" href="javascript:;">\n\t\t    <span class="icon icons icon-trash rachicons" id="del"></span>\n\t\t</a>\n\t\t<a class="tab-item" href="javascript:;" >\n\t\t    <!-- <span class="icon icons icon-compose rachicons" id="edit"></span> -->\n\t\t    <span class="" id="edit"></span>\n\t\t</a>\n\t</nav>\n\t<div id="DivYY"></div>\n\t<div id="deleteDiv" style="position:absolute;padding:10px; width:100%; z-index:1000; background:#fff;transition:0.5s;bottom:-285px;display: none">\n\t\t<span class="Details-titles">此为重复事件</span>\n\t\t<button class="btn btn-weight btn-block btn-outlined del" data-type="only">删除当前事件</button>\n\t\t<button class="btn btn-weight btn-block btn-outlined del" data-type="all">删除全部事件</button>\n\t\t<button class="btn btn-weight btn-block btn-outlined closeDelete" style="background:#f2f2f2; border:none;">取消</button>\n\t</div>\n\t\n\t<div id="deleteDivOnly" style="position:absolute;padding:10px; width:100%; z-index:1000; background:#fff;transition:0.5s;bottom:-285px;display: none;">\n\t\t<button class="btn btn-weight btn-block btn-outlined del" data-type="only">删除当前事件</button>\n\t\t<button class="btn btn-weight btn-block btn-outlined closeDelete" style="background:#f2f2f2; border:none;">取消</button>\n\t</div>\n\t</div>\n</div>\n';});

define('module_calendarBf/calendarDetails',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store',
	'bsl', './js/common', './js/moment.min','init','./api'
], function($, View, calendarTpl, eventListTpl, EMCSUtil, Store, bsl, CalendarCommon, moment, init,api) {
	window.backAction = function() {
		var localsion = window.location.href;
		var localcalendarAdd = localsion.indexOf("calendarAdd"); //新建事件
		var localcalendarDetails = localsion.indexOf("calendarDetails"); //事件详情
		var localcalendarEdit = localsion.indexOf("calendarEdit"); //编辑事件
		var localcalendarSearch = localsion.indexOf("calendarSearch"); //搜索事件
		var localcalendarRemind = localsion.indexOf("calendarRemind"); //非全天提醒
		var localcalendarRemindAllday = localsion.indexOf("calendarRemind-Allday"); //全天提醒
		var localcalendarRepeat = localsion.indexOf("calendarRepeat"); //重复
		var localmain = localsion.indexOf("main");
		if (localmain > -1) {
			if (isInApp) bsl.infinitus.transfer.returnBack(true);
		} else if (localcalendarAdd > -1) {
			if (Store.loadObject("calendarBf_remind") == "remind") {
				Store.deleteObject("calendarBf_remind");
				$("#calendarRemind").remove();
			} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
				Store.deleteObject("calendarBf_remindAllday");
				$("#calendarRemind-Allday").remove();
			} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
				Store.deleteObject("calendarBf_repeat");
				$("#calendarRepeat").remove();
			} else {
				if (Store.loadObject("calendarBf_add") == "add") {
					bsl.infinitus.transfer.returnBack(false, "", function(data) {});
				}
			}
		} else if (localcalendarDetails > -1) {
			if ($("#calendarDetails #DivYY").css("display") != "none") {
				$("#calendarDetails #DivYY").hide();
				$("#calendarDetails #deleteDiv").hide();
				$("#calendarDetails #deleteDivOnly").hide();
			} else {
				if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
					//Util.navigate('module_calendarBf/calendarSearch');
					window.butterfly.navigate('module_calendarBf/calendarSearch', {
						trigger: true
					});
				} else {
					window.butterfly.navigate('module_calendarBf/main', {
						trigger: true
					});
				}
			}
		} else if (localcalendarEdit > -1) {
			if ($("#calendarEdit #DivYY").css("display") != "none") {
				$("#calendarEdit #DivYY").hide();
				$("#calendarEdit #saveDiv").hide();
			} else {
				if (Store.loadObject("calendarBf_remind") == "remind") {
					Store.deleteObject("calendarBf_remind");
					$("#calendarRemind").remove();
				} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
					Store.deleteObject("calendarBf_remindAllday");
					$("#calendarRemind-Allday").remove();
				} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
					Store.deleteObject("calendarBf_repeat");
					$("#calendarRepeat").remove();
				} else {
					if (Store.loadObject("calendarBf_edit") == "edit") {
						bsl.infinitus.transfer.returnBack(false, "", function(data) {});
					}
				}
			}
		} else if (localcalendarSearch > -1) {
			window.butterfly.navigate('module_calendarBf/main', {
				trigger: true
			});
		}
	};
	var me = null;
	var currentDate = null;
	var remindArrText = ["无", "事件发生时", "5分钟前", "15分钟前", "30分钟前", "1小时前", "2小时前", "1天前", "2天前", "1周前", "当天(9:00)", "1天前(9:00)", "2天前(9:00)", "1周前(9:00)"];
	var repeatArrText = ["永不", "每天", "每周", "每两周", "每月", "每年"];

	var isPad = Store.loadObject("calendarBf_isPad");

	var model = View.extend({

		events: {
			"click #module-calendarBf-calendarDetails #del": "delDetails", //删除
			"click #module-calendarBf-calendarDetails #edit": "showEdit", //修改
			"click #module-calendarBf-calendarDetails #deleteDiv .del": "hideDelete",
			"click #module-calendarBf-calendarDetails #deleteDivOnly .del": "hideDeleteOnly",
			"click #module-calendarBf-calendarDetails .closeDelete": "closeDelete",
			//"click .back": "getBack"
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			me = this;
		},
		getBack: function() {
			setTimeout(function() {
				me.animateSlideOutRight();
				me.parentView.detailPage = null;
				setTimeout(function() {
					$(me.el).remove()
				}, 250);
			}, 200);
		},
		getSearchBack: function() {
			me.animateSlideOutRight();
			me.parentView.detailPage = null;
			setTimeout(function() {
				$(me.el).remove()
			}, 200);
			$(window).trigger("PadReSearch");
		},

		//月事件查询
		selectDatebase: function(theId) {
			//清除 id
			localStorage.removeItem("calendarBf_noticeId");
			CalendarCommon.init();
			//获取指定的item数据
			var item = {
				id: theId
			};
			CalendarCommon.pageCalendarSelectOneItem(item, function(data) {
				var show_obj = data.item(0);
				Store.saveObject("calendarBf_show_detail_obj", show_obj);
				me.refreshInf();
			});

		},
		onShow: function() {
			if (isInApp && !Store.loadObject("calendarBf_isApple")) bsl.infinitus.tools.setBackAction(backAction);
			if (localStorage.getItem("calendarBf_noticeId")) {
				// 存储 查询到的数据到 ls
				//alert(localStorage.getItem("noticeId"))
				me.selectDatebase(Store.loadObject("calendarBf_noticeId"));
			} else {
				me.refreshInf();
			}


			if (isPad) {
				$("#calendarDetails .bar").css("position", "absolute");
				// $("#calendarDetails .content").css("height", "524px");
			}

			$("#calendarDetails .back").off("click").on("click", function() {
				if (isPad) {
					if (Store.loadObject("calendarBf_padSearchEnter")) {
						me.getSearchBack();
					} else {
						me.animateSlideOutDown();
						me.parentView.show();
						me.parentView.detailPage = null;
						setTimeout(function() {
							$(me.el).remove();
							$("#shadow-dialg").css({
								"z-index": "-1"
							})
						}, 200);
					}

				} else {
					if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
						window.butterfly.navigate('module_calendarBf/calendarSearch', {
							trigger: true
						});
					} else {
						window.butterfly.navigate('module_calendarBf/main', {
							trigger: true
						});
					}
				}
			});
			var show_obj = Store.loadObject("calendarBf_show_detail_obj");
			bsl.infinitus.cat.analytics({
                "category": "事件详情",
                "action": "浏览",
                "label": "",
                "value": show_obj.id
            });

            // console
            // 参数：年份数字
            // 月份数字
            // 成功时回调
            api.getCalendarItemCountByMonth(2016,10,function(result){
            	console.log(result);	//返回数字
            },function(e){
            	console.log(e);
            });
            
		},

		// 显示 事件信息
		refreshInf: function() {
			var show_obj = Store.loadObject("calendarBf_show_detail_obj");
			Store.saveObject("calendarBf_repeat_type", show_obj.repeat);
			Store.saveObject("calendarBf_remind_type", show_obj.remind);
			var thisstart = moment.unix(show_obj.startTime).format('YYYY-MM-DD HH:mm');
			var thisend = moment.unix(show_obj.endTime).format('YYYY-MM-DD HH:mm');
			var thisRepeatOver = moment.unix(show_obj.thingEndTime).format('YYYY-MM-DD');
			var resouce = new Date(parseInt(thisstart.split('-')[0]), parseInt(thisstart.split('-')[1]) - 1, parseInt(thisstart.split('-')[2]));
			var endresouce = new Date(parseInt(thisend.split('-')[0]), parseInt(thisend.split('-')[1]) - 1, parseInt(thisend.split('-')[2]));
			var tag = resouce.getDay();
			var endtag = endresouce.getDay();
			var weekday = '';
			var endweekday = '';
			if (show_obj.fromSearch == 'true') {
				if (show_obj.allDay == true) {
					Store.saveObject('calendarBf_currentDateTime', moment.unix(show_obj.startTime).startOf('day').unix()); //获取第一条数的日期作为默认值作为详情页返回的起始时间
				} else {
					Store.saveObject('calendarBf_currentDateTime', show_obj.startTime); //获取第一条数的日期作为默认值作为详情页返回的起始时间
				}
			}

			switch (tag) {
				case 0:
					{
						weekday = '周日';
					}
					break;
				case 1:
					{
						weekday = '周一';
					}
					break;
				case 2:
					{
						weekday = '周二';
					}
					break;
				case 3:
					{
						weekday = '周三';
					}
					break;
				case 4:
					{
						weekday = '周四';
					}
					break;
				case 5:
					{
						weekday = '周五';
					}
					break;
				case 6:
					{
						weekday = '周六';
					}

			}
			switch (endtag) {
				case 0:
					{
						endweekday = '周日';
					}
					break;
				case 1:
					{
						endweekday = '周一';
					}
					break;
				case 2:
					{
						endweekday = '周二';
					}
					break;
				case 3:
					{
						endweekday = '周三';
					}
					break;
				case 4:
					{
						endweekday = '周四';
					}
					break;
				case 5:
					{
						endweekday = '周五';
					}
					break;
				case 6:
					{
						endweekday = '周六';
					}

			}
			$("#calendarDetails #tittle").text(show_obj.title);
			$("#calendarDetails #tittle").show();
			if (show_obj.remarks && show_obj.remarks != "") {
				$("#calendarDetails #remarks").text(show_obj.remarks);
				$("#calendarDetails #remarks").parent().show();
				$("#calendarDetails #remarks").show();
			} else {
				$("#calendarDetails #remarks").parent().hide();
			}
			if (show_obj.address && show_obj.address != null) {
				$("#calendarDetails #addrs").text(show_obj.address);
				$("#calendarDetails #addrs").parent().show();
				$("#calendarDetails #addrs").show();
			} else {
				$("#calendarDetails #addrs").parent().hide();
			}

			$("#calendarDetails #startTime").html(thisstart.split(' ')[0] + ' ' + weekday + ' ' + thisstart.split(' ')[1]);
			$("#calendarDetails #endTime").html(thisend.split(' ')[0] + ' ' + endweekday + ' ' + thisend.split(' ')[1]);
			$("#calendarDetails #extendInf").text(remindArrText[parseInt(show_obj.remind)]);
			$("#calendarDetails #extendInf_repeat").text(repeatArrText[parseInt(show_obj.repeat)]);
			$("#calendarDetails #edit").attr('itemId', show_obj.id);

			$("#calendarDetails .back").attr("data-click-title","事件详情");
			$("#calendarDetails #edit").attr('data-click-title', "事件详情");
			$("#calendarDetails #edit").attr('data-click-label', "编辑");
			$("#calendarDetails #edit").attr('data-click-value', show_obj.id);
			$("#calendarDetails #del").attr('data-click-title', "事件详情");
			$("#calendarDetails #del").attr('data-click-value',show_obj.id);
			$("#calendarDetails #del").attr('data-click-label', "删除");

			if (show_obj.allDay == "true" || show_obj.allDay == true) {
				if (thisstart.split(' ')[0] === thisend.split(' ')[0]) {
					$(".all-time").find("span").html(thisstart.split(' ')[0] + ' ' + endweekday + ' 全天');
					$(".no-all-time").hide();
					$(".oneday-time").hide();
					$(".all-time-start").hide();
					$(".all-time-end").hide();
					$(".all-time").show();
				} else {
					$(".all-time-start").find("span").html(thisstart.split(' ')[0] + ' ' + weekday + ' 全天');
					$(".all-time-end").find("span").html(thisend.split(' ')[0] + ' ' + endweekday + ' 全天');
					$(".all-time").hide();
					$(".no-all-time").hide();
					$(".oneday-time").hide();
					$(".all-time-start").show();
					$(".all-time-end").show();
				}


			} else {
				$(".no-all-time").show();
				$(".all-time").hide();
				$(".all-time-start").hide();
				$(".all-time-end").hide();
			};
			if (parseInt(show_obj.repeat) != 0) {
				$("#calendarDetails .repeat_over").show();
				$("#calendarDetails #extendInf_repeat_over").html(thisRepeatOver);
			} else {
				$("#calendarDetails .repeat_over").hide();
			};


		},

		editPage: null,
		hideEditDetails: function(e) {

			var target = e.target;
			var type = $(target).data("type");
			if (type == "all" || type == "only") {
				Store.saveObject("calendarBf_edit-type", type);
			} else {
				me.transitionHideFn("calendarDetails", "DivYY");
				me.transitionHideFn("calendarDetails", "editDiv");
				return;
			}

			if (isPad) {
				me.showInDialog(me.editPage, 'calendarEdit');
			} else {
				window.butterfly.navigate('module_calendarBf/calendarEdit', {
					trigger: true
				});
				me.transitionHideFn("calendarDetails", "DivYY");
				me.transitionHideFn("calendarDetails", "editDiv");

			}

		},
		/**
		 * [transitionHideFn 隐藏div]
		 * @type {[type]}
		 * @param {[type] string} [varname pageId] [页面id]
		 * @param {[type] string} [varname idName] [元素id]
		 */
		transitionHideFn: function(pageId, idName) {
			$("#" + pageId + " #" + idName).css("transform", "translateY(0)");
			setTimeout(function() {
				$("#" + pageId + " #" + idName).hide();
			}, 500);
		},

		//非重复事件的详情页面,点击了"删除当天"按钮
		hideDeleteOnly: function(e) {
			var target = e.target;
			if ($(target).data("type") == "only") {
				me.deleteData(Store.loadObject("calendarBf_show_detail_obj"), "only", function() {
					bsl.infinitus.tools.showToast("删除成功", 2000);
					if (isPad) {
						if (Store.loadObject("calendarBf_padSearchEnter")) {
							me.getSearchBack();
						} else {
							me.animateSlideOutDown();
							me.parentView.show();
							me.parentView.detailPage = null;
							setTimeout(function() {
								$(me.el).remove();
								$("#shadow-dialg").css({
									"z-index": "-1"
								})
							}, 200);
						}
					} else {
						if (Store.loadObject("calendarBf_searchEnter")) {
							window.butterfly.navigate('module_calendarBf/calendarSearch', {
								trigger: true
							});
						} else {
							window.butterfly.navigate('module_calendarBf/main', {
								trigger: true
							});
						}
					}
				});
			}
		},
		showEdit: function() {
			if (isPad) {
				me.showInDialog(me.editPage, 'calendarEdit');
			} else {
				window.butterfly.navigate('module_calendarBf/calendarEdit', {
					trigger: true
				});
				me.transitionHideFn("calendarDetails", "DivYY");
				me.transitionHideFn("calendarDetails", "editDiv");
			}
		},
		showDelete: function() {
			$("#calendarDetails #deleteDiv").show();
			$("#calendarDetails #DivYY").show();
			$("#calendarDetails #deleteDiv").css("transform", "translateY(-285px)");
		},
		//隐藏阴影层
		closeDelete: function() {
			$("#deleteDiv").hide();
			$("#deleteDivOnly").hide();
			$("#calendarDetails #DivYY").hide();

		},

		//重复事件的详情页面,点击了按钮
		hideDelete: function(e) {
			var target = e.target;
			var callback = function() {
				//添加提醒
				CalendarCommon.initRemind();
				bsl.infinitus.tools.showToast("删除成功", 2000);
				if (isPad) {
					if (Store.loadObject("calendarBf_padSearchEnter")) {
						me.getSearchBack();
					} else {
						me.animateSlideOutDown();
						me.parentView.show();
						me.parentView.detailPage = null;
						setTimeout(function() {
							$(me.el).remove();
							$("#shadow-dialg").css({
								"z-index": "-1"
							})
						}, 200);
					}
				} else {
					if (Store.loadObject("calendarBf_searchEnter")) {
						window.butterfly.navigate('module_calendarBf/calendarSearch', {
							trigger: true
						});
					} else {
						window.butterfly.navigate('module_calendarBf/main', {
							trigger: true
						});
					}
				}
			};
			if ($(target).data("type") == "only") {
				me.deleteData(Store.loadObject("calendarBf_show_detail_obj"), "only", callback);
			} else {
				me.deleteData(Store.loadObject("calendarBf_show_detail_obj"), "all", callback);
			}
		},

		delDetails: function() {
			var show_obj = Store.loadObject("calendarBf_show_detail_obj");
			if (parseInt(show_obj.repeat) == 0) {
				me.noRepeatDelete();
			} else {
				me.showDelete();
			}
		},

		// 非重复事件的删除
		noRepeatDelete: function() {
			$("#calendarDetails #deleteDivOnly").show();
			$("#calendarDetails #DivYY").show();
			$("#calendarDetails #deleteDivOnly").css("transform", "translateY(-285px)");
		},

		// 计算提醒时间
		calcRemindTime: function(type, startTime) {
			var theDate = startTime.split(" ")[0];
			var time = startTime.split(" ")[1];

			// 开始时间对象
			var thisObj = new Date(theDate.split('-')[0], theDate.split('-')[1], theDate.split('-')[2], time.split(":")[0], time.split(":")[1], "00");

			var dateObj = null;

			// 提前的分钟数
			var mins = 0;

			switch (type) {

				case 2:
					mins = 5; //5分钟前
					break;
				case 3:
					mins = 15; //15分钟前
					break;
				case 4:
					mins = 30; //30分钟前
					break;
				case 5:
					mins = 60; //1小时前
					break;
				case 6:
					mins = 120; //2小时前
					break;
				case 7:
					mins = 1440; //1天前
					break;
				case 8:
					mins = 2880; //2天前
					break;
				case 9:
					mins = 10080; //1周前
					break;

			}
			dateObj = new Date(thisObj.getTime() - 1000 * 60 * mins);

			// 处理个位数情况
			var mon = (dateObj.getMonth()) < 10 ? '0' + (dateObj.getMonth()) : (dateObj.getMonth());
			var d = dateObj.getDate() < 10 ? '0' + dateObj.getDate() : dateObj.getDate();
			var h = dateObj.getHours() < 10 ? '0' + dateObj.getHours() : dateObj.getHours();
			var min = dateObj.getMinutes() < 10 ? '0' + dateObj.getMinutes() : dateObj.getMinutes();
			return dateObj.getFullYear() + "-" + mon + "-" + d + " " + h + ":" + min + ":00";

		},

		deleteData: function(theObj, type, callback) {
			if (type == "only") {
				CalendarCommon.pageCalendarDeleteOneItem(theObj, function() {
					callback();
				}, function(e) {
					if (e) {
						bsl.infinitus.tools.showToast(e, 2000);
					} else {
						bsl.infinitus.tools.showToast("删除失败", 2000);
					}
				});
			} else {
				var thing = {
					id: theObj.thingid
				};
				CalendarCommon.pageCalendarDeleteAllItem(thing, function() {
					callback();
				}, function(e) {
					if (e) {
						bsl.infinitus.tools.showToast(e, 2000);
					} else {
						bsl.infinitus.tools.showToast("删除失败", 2000);
					}
				});
			}

		},

		// pad中 显示 页面内加载 dialog html为 页面名称，需要在本页面创建一个页面对象传进去。
		showInDialog: function(pageName, html) {

			if (pageName) {
				pageName.show();
				pageName.$el.css({
					'display': 'block'
				});
				pageName.animateSlideInUp();
			} else {
				require(['view!module_calendarBf/' + html + '.html'], function(ViewClass) {
					pageName = new ViewClass();
					pageName.$el.css({
						'position': 'absolute',
						'top': '0px',
						'bottom': '0px',
						'width': '100%',
						'z-index': 1000
					});
					pageName.parentView = me;
					pageName.render();
					me.el.appendChild(pageName.el);
					pageName.show();
					pageName.animateSlideInRight();
				}, function(err) {
					Toast("操作失败，请重试");
				});
			};
		},
		detailReOnhsow: function() {
			setTimeout(function() {
				me.onShow();
			}, 1000);
		}
	});
	return model;
});

define('text!module_calendarBf/calendarEdit.html',[],function () { return '<div data-view="calendarEdit" id="calendarEdit" class="views">\n\n\t<style>\n\t\t#calendarEdit #calendar-moudel-calendarEdit {\n\t\t\toverflow-y: auto;\n\t\t\tfont-family: arial,YouYuan;\n\t\t}\n\t\t\n\t\t#calendarEdit .list {\n\t\t\tmargin-top: 10px;\n\t\t\tpadding: 0 0 0 15px;\n\t\t\tbackground-color: #fff;\n\t\t\tborder-top: 1px solid #eee;\n\t\t\tborder-bottom: 1px solid #eee;\n\t\t}\n\t\t\n\t\t#calendarEdit #section_wrap {\n\t\t\tpadding-top: 10px;\n\t\t}\n\t\t\n\t\t#calendarEdit .padding-right11 {\n\t\t\tpadding-right: 11px;\n\t\t}\n\t\t\n\t\t#calendarEdit .margin-right11 {\n\t\t\tmargin-right: -11px;\n\t\t}\n\t\t\n\t\t#calendarEdit .input-row {\n\t\t\theight: 47px;\n\t\t\tcolor: #7a7a7a;\n\t\t}\n\t\t\n\t\t#calendarEdit .input-row input {\n\t\t\theight: 47px;\n\t\t}\n\t\t\n\t\t#calendarEdit .input-row label {\n\t\t\tline-height: 47px;\n\t\t\tpadding: 0 15px;\n\t\t\tfont-family: YouYuan!important;\n\t\t\tfont-weight: bold;\n\t\t}\n\t\t\n\t\t#calendarEdit .input-row input {\n\t\t\tfloat: left;\n\t\t\tpadding-left: 15px;\n\t\t}\n\t\t\n\t\t#calendarEdit .table-view {\n\t\t\tpadding-left: 0;\n\t\t\tmargin-top: 0;\n\t\t\tmargin-bottom: 15px;\n\t\t\tlist-style: none;\n\t\t\tbackground-color: #fff;\n\t\t\tborder-top: none;\n\t\t\tborder-bottom: 1px solid #ddd;\n\t\t}\n\t\t\n\t\t#calendarEdit .toggle.active:before {\n\t\t\tcontent: "开";\n\t\t\tfont-size: 16px;\n\t\t}\n\t\t\n\t\t#calendarEdit .toggle:before {\n\t\t\tcontent: "关";\n\t\t\tfont-size: 16px;\n\t\t}\n\t\t\n\t\t#calendarEdit .lineThrough {\n\t\t\ttext-decoration: line-through;\n\t\t}\n\t\t\n\t\t#calendarEdit #DivYY {\n\t\t\tbackground-color: rgba(0, 0, 0, 0.5);\n\t\t\twidth: 100%;\n\t\t\theight: 100%;\n\t\t\tposition: absolute;\n\t\t\tleft: 0;\n\t\t\ttop: 0;\n\t\t\tdisplay: none;\n\t\t\ttransition: 0.3s;\n\t\t\tz-index: 10;\n\t\t}\n\t\t\n\t\t#calendarEdit .Details-titles {\n\t\t\theight: 30px;\n\t\t\tdisplay: block;\n\t\t\tline-height: 30px;\n\t\t\ttext-align: center;\n\t\t\tmargin-bottom: 5px;\n\t\t}\n        #calendarEdit footer{\n            position: absolute;\n            left:0;\n            bottom: 0;\n            width:100%;\n            height:45px;\n            background-color: #fff;\n            text-align: center;\n        }\n        #calendarEdit .content{\n            bottom: 45px;\n        }\n        #calendarEdit footer button{\n            width:100%;\n            height:100%;\n            border:none;\n        }\n\t.back .font16{\n\t\tfont-size: 16px;\n\t}\n\t#calendarEdit .pull-right{color: rgb(122,122,122);font-weight: normal;}\n\t</style>\n\t<div id="module-calendarBf-calendarEdit">\n\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t<div class="ui3-row-12">\n\t\t\t<div class="ui3-col-3 ui3-icon-back back" data-click-title="标题" data-click-label="返回">返回</div>\n\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">事件详情</div>\n\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right save" data-click-title="标题" data-click-label="保存">保存</div>\n\t\t</div>\n\t</header>\n\t<!--<header class="bar bar-nav blue-bar top-background-color">\n\t\t<button class="btn btn-link btn-nav pull-left back">\n\t\t\t<span class="icon icon-left-nav back_icon rachicons font16"><span class="youyuan">返回</span></span>\n\t\t</button>\n\t\t<div class="title">编辑事件</div>\n\t\t<button class="btn btn-link btn-nav pull-right save" style="position: absolute;right: 10px;font-size: 20px;">\n\t\t\t保存\n\t\t</button>\n\t</header>-->\n\t<div class="content" style="background: #F2F2F2;" id="calendar-moudel-calendarEdit">\n\t\t<section id="section_wrap">\n\t\t\t<form class="input-group">\n\t\t\t\t<div class="input-row" data-focus-title="标题" data-focus-label="标题">\n\t\t\t\t\t<label for="d_title" style="display:none;color:#000;border-bottom:none;" data-focus-title="标题" data-focus-label="标题">标题</label>\n\t\t\t\t\t<input type="text" class="canClear titleInput" id="tittle" style="width:95%;text-align:left;" value="" maxlength="40" placeholder="40个文字以内" data-focus-title="标题" data-focus-label="标题">\n\t\t\t\t</div>\n\t\t\t\t<div class="input-row" data-focus-title="标题" data-focus-label="地点">\n\t\t\t\t\t<label style="display:none;color:#000;border-bottom:none;" data-focus-title="标题" data-focus-label="地点">地点</label>\n\t\t\t\t\t<input type="text" id="address" class="canClear" style="text-align:left;width:95%" value="" maxlength="60" placeholder="60个文字以内" data-focus-title="标题" data-focus-label="地点">\n\t\t\t\t</div>\n\t\t\t</form>\n\n\t\t\t<ul class="table-view" style="margin-top:10px;" data-click-title="标题" data-click-label="开关">\n\t\t\t\t<li class="table-view-cell" style="color:#000;border-bottom:none;font-weight: bold;" data-click-title="标题" data-click-label="开关">\n\t\t\t\t\t全天事件\n\t\t\t\t\t<div class="toggle" id="idAllDay" data-click-title="标题" data-click-label="开关">\n\t\t\t\t\t\t<div class="toggle-handle" data-click-title="标题" data-click-label="开关"></div>\n\t\t\t\t\t</div>\n\t\t\t\t</li>\n\t\t\t</ul>\n\n\t\t\t<form class="input-group" id="formNoAll">\n\t\t\t\t<div class="input-row" data-focus-title="标题" data-focus-label="开始时间">\n\t\t\t\t\t<label for="startTime" style="color:#000;" data-focus-title="标题" data-focus-label="开始时间">开始</label>\n\t\t\t\t\t<input id="startTime" class="repeatStart" style="text-align:right;" value="" class="" readonly="readonly" name="startTime" type="text" data-focus-title="标题" data-focus-label="开始时间">\n\t\t\t\t</div>\n\t\t\t\t<div class="input-row" id="endTimeDiv" data-focus-title="标题" data-focus-label="结束时间">\n\t\t\t\t\t<label for="endTime" style="color:#000;border-bottom:none;" data-focus-title="标题" data-focus-label="结束时间">结束</label>\n\t\t\t\t\t<input id="endTime" class="repeatEnd" style="text-align:right;" value="" class="" readonly="readonly" name="endTime" type="text" data-focus-title="标题" data-focus-label="结束时间">\n\t\t\t\t</div>\n\t\t\t</form>\n\n\t\t\t<form class="input-group " id="formAll" style="display:none;">\n\t\t\t\t<div class="input-row" data-focus-title="标题" data-focus-label="开始时间">\n\t\t\t\t\t<label for="startTimeall" style="color:#000;" data-focus-title="标题" data-focus-label="开始时间">开始</label>\n\t\t\t\t\t<input id="startTimeall" class="repeatStart" style="text-align:right;" value="" class="" readonly="readonly" name="startTimeall" type="text" data-focus-title="标题" data-focus-label="开始时间">\n\t\t\t\t</div>\n\t\t\t\t<div class="input-row" id="endTimeDiv" data-focus-title="标题" data-focus-label="结束时间">\n\t\t\t\t\t<label for="endTimeall" style="color:#000;" data-focus-title="标题" data-focus-label="结束时间">结束</label>\n\t\t\t\t\t<input id="endTimeall" class="repeatEnd" style="text-align:right;" value="" class="" readonly="readonly" name="endTimeall" type="text" data-focus-title="标题" data-focus-label="结束时间">\n\t\t\t\t</div>\n\t\t\t</form>\n\n\t\t\t<ul class="table-view" data-click-title="标题" data-click-label="提醒时间">\n\t\t\t\t<li class="table-view-cell" id="remindBtn" data-click-title="标题" data-click-label="提醒时间">\n\t\t\t\t\t<a class="navigate-right" id="remindBtn" style="color:#000;border-bottom:none;font-weight: bold;" data-click-title="标题" data-click-label="提醒时间">\n     \t\t\t\t\t提醒时间\n\t  \t\t\t\t\t<span class="pull-right" id="remind" data-type="0" data-click-title="标题" data-click-label="提醒时间">15分钟前</span>\n    \t\t\t\t</a>\n\t\t\t\t</li>\n\t\t\t</ul>\n\n\t\t\t<ul class="table-view" style="margin-top:10px;">\n\t\t\t\t<li class="table-view-cell" id="repeatBtn" data-click-title="标题" data-click-label="重复">\n\t\t\t\t\t<a class="navigate-right" style="color:#000;border-bottom:none;font-weight: bold;" data-click-title="标题" data-click-label="重复">\n     \t\t\t\t\t重复\n\t  \t\t\t\t\t<span class="pull-right" id="repeat" data-type = "0" data-click-title="标题" data-click-label="重复">永不</span>\n    \t\t\t\t</a>\n\t\t\t\t</li>\n\t\t\t\t<li>\n\t\t\t\t\t<form class="input-group">\n\t\t\t\t\t\t<div class="input-row" id="thingEndTimeDiv" style="display:none">\n\t\t\t\t\t\t\t<label for="thingEndTime" style="color:#000;">重复结束</label>\n\t\t\t\t\t\t\t<input id="thingEndTime" class="repeatEnd" style="text-align:right;" value="" class="" readonly="readonly" name="thingEndTime" type="text">\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</form>\n\t\t\t\t</li>\n\t\t\t</ul>\n\n\t\t\t<ul class="table-view" style="margin-top:10px;" id="ipadMy" data-focus-title="标题" data-focus-label="日程详情">\n\t\t\t\t<li class="table-view-cell padding-right11" data-focus-title="标题" data-focus-label="日程详情">\n\t\t\t\t\t<textarea id="remarks" rows="" cols="4" style="padding: 0px;margin:0 -5px;border: none" value="" maxlength="200" placeholder="备注 200个文字以内" data-focus-title="标题" data-focus-label="日程详情"></textarea>\n\t\t\t\t\t<input type="text" id="forNothing" style="display:none;" data-focus-title="标题" data-focus-label="日程详情"></input>\n\t\t\t\t</li>\n\t\t\t</ul>\n\t\t</section>\n\t</div>\n\t\t<footer>\n\t\t\t<button class="dialog-save save-btn">保存</button>\n\t\t</footer>\n\t<div id="DivYY"></div>\n\t<div id="saveDiv" style="position:absolute;padding:10px; width:100%; z-index:10; background:#fff;transition:0.5s;bottom:0px;display: none;">\n\t\t<span class="Details-titles">此为重复事件</span>\n\t\t<button class="btn btn-weight btn-block btn-outlined" data-type="only">仅修改当前事件</button>\n\t\t<button class="btn btn-weight btn-block btn-outlined" data-type="all">修改所有事件</button>\n\t\t<button class="btn btn-weight btn-block btn-outlined" id="saveclose" style="background:#f2f2f2; border:none;">取消</button>\n\t</div>\n</div>\n</div>';});

define('module_calendarBf/calendarEdit',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store',
	'bsl','./js/validator', './js/calendarFunc', './js/common', './js/moment.min','init'
], function($, View, calendarTpl, eventListTpl, EMCSUtil, Store, bsl, Validator, Func, CalendarCommon, moment, init) {
	window.backAction = function() {
		var localsion = window.location.href;
		var localcalendarAdd = localsion.indexOf("calendarAdd"); //新建事件
		var localcalendarDetails = localsion.indexOf("calendarDetails"); //事件详情
		var localcalendarEdit = localsion.indexOf("calendarEdit"); //编辑事件
		var localcalendarSearch = localsion.indexOf("calendarSearch"); //搜索事件
		var localcalendarRemind = localsion.indexOf("calendarRemind"); //非全天提醒
		var localcalendarRemindAllday = localsion.indexOf("calendarRemind-Allday"); //全天提醒
		var localcalendarRepeat = localsion.indexOf("calendarRepeat"); //重复
		var localmain = localsion.indexOf("main");
		var activeName = document.activeElement.nodeName;
		if (activeName == "INPUT" || activeName == "TEXTAREA") {
			$("input").blur();
			$("textarea").blur();
			return;
		};
		if (localmain > -1) {
			bsl.infinitus.transfer.returnBack(true);
		} else if (localcalendarAdd > -1) {
			if (Store.loadObject("calendarBf_remind") == "remind") {
				Store.deleteObject("calendarBf_remind");
				$("#calendarRemind").remove();
			} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
				Store.deleteObject("calendarBf_remindAllday");
				$("#calendarRemind-Allday").remove();
			} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
				Store.deleteObject("calendarBf_repeat");
				$("#calendarRepeat").remove();
			} else {
				if (Store.loadObject("calendarBf_add") == "add") {
					//bsl.infinitus.transfer.returnBack(false, "", function(data) {});
					$("#calendarAdd .back").trigger("click");
				}
			}
		} else if (localcalendarDetails > -1) {
			if ($("#calendarDetails #DivYY").css("display") != "none") {
				$("#calendarDetails #DivYY").hide();
				$("#calendarDetails #deleteDiv").hide();
				$("#calendarDetails #deleteDivOnly").hide();
			} else {
				if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
					//Util.navigate('module_calendarBf/calendarSearch');
					window.butterfly.navigate('module_calendarBf/calendarSearch', {
						trigger: true
					});
				} else {
					window.butterfly.navigate('module_calendarBf/main', {
						trigger: true
					});
				}
			}
		} else if (localcalendarEdit > -1) {
			if ($("#calendarEdit #DivYY").css("display") != "none") {
				$("#calendarEdit #DivYY").hide();
				$("#calendarEdit #saveDiv").hide();
			} else {
				if (Store.loadObject("calendarBf_remind") == "remind") {
					Store.deleteObject("calendarBf_remind");
					$("#calendarRemind").remove();
				} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
					Store.deleteObject("calendarBf_remindAllday");
					$("#calendarRemind-Allday").remove();
				} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
					Store.deleteObject("calendarBf_repeat");
					$("#calendarRepeat").remove();
				} else {
					if (Store.loadObject("calendarBf_edit") == "edit") {
						$("#calendarEdit .back").trigger("tap");
					}
				}
			}
		} else if (localcalendarSearch > -1) {
			window.butterfly.navigate('module_calendarBf/main', {
				trigger: true
			});
		}
	};
	var me = null;
	var currentDate = null;
	var remindArrText = ["无", "事件发生时", "5分钟前", "15分钟前", "30分钟前", "1小时前", "2小时前", "1天前", "2天前", "1周前", "当天(9:00)", "1天前(9:00)", "2天前(9:00)", "1周前(9:00)"];
	var repeatArrText = ["永不", "每天", "每周", "每两周", "每月", "每年"];
	var isPad = Store.loadObject("calendarBf_isPad");
	var isApple = Store.loadObject("calendarBf_isApple"); // 判断 是否 苹果设备

	var ipadSave = true; // 用于解决ipad 重复显示的问题
	var remindMark = null;

	// 判断是不是重复事件
	var pageType = null;
	// 日程本身的重复类型
	var repeatType;
	var itemId;
	var thingId;
	var thingEndTime;
	var value;
	var inputVal; //记录输入框的值
	var model = View.extend({

		events: {
			"tap #module-calendarBf-calendarEdit #remindBtn": "remind", //提醒
			"tap #module-calendarBf-calendarEdit #repeatBtn": "repeat", //重复
			"tap #module-calendarBf-calendarEdit .dialog-save": "showSaveDiv", //保存
			"touchend #module-calendarBf-calendarEdit #idAllDay": "statu_change", //开关
			"tap #module-calendarBf-calendarEdit #startTime, #module-calendarBf-calendarEdit #endTime": "setTime",
			"tap #module-calendarBf-calendarEdit #startTimeall, #module-calendarBf-calendarEdit #endTimeall, #module-calendarBf-calendarEdit #thingEndTime": "setTimeall",
			"click #module-calendarBf-calendarEdit #saveDiv .btn": "saveFun",
			//"click #calendarEdit #saveclose": "saveclose",
			"focus #module-calendarBf-calendarEdit input": "showBtnClear",
			"input #module-calendarBf-calendarEdit input": "showBtnClear",
			"blur #module-calendarBf-calendarEdit input": "hideBtnClear",
			"input #module-calendarBf-calendarEdit .canClear": "checkNum",
			"tap #module-calendarBf-calendarEdit textarea": "focusArea"
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		getBack: function() {
			me.animateSlideOutRight();
			me.parentView.refreshInf();
			me.parentView.editPage = null;
			setTimeout(function() {
				$(me.el).remove()
			}, 200);
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			Store.saveObject("calendarBf_isFirstEnter_two", true);
			me = this;
			me.noDoubleTap();
		},
		remindPage: null,
		remind: function() {
			me.noDoubleTap();
			$("#calendarEdit #tittle").blur();
			$("#calendarEdit #address").blur();
			$("#calendarEdit #remarks").blur();
			if ($("#calendarEdit #idAllDay").hasClass('active')) {
				me.showInnerPage(me.remindPage, "calendarRemind-Allday");
				if (!isPad) {
					Store.saveObject("calendarBf_remindAllday", "remindAllday");
				}
			} else {
				me.showInnerPage(me.remindPage, "calendarRemind");
				if (!isPad) {
					Store.saveObject("calendarBf_remind", "remind");
				}
			}

		},
		repeatPage: null,
		repeat: function() {
			me.noDoubleTap();
			$("#calendarEdit #tittle").blur();
			$("#calendarEdit #address").blur();
			$("#calendarEdit #remarks").blur();
			me.showInnerPage(me.repeatPage, "calendarRepeat");
			if (!isPad) {
				Store.saveObject("calendarBf_repeat", "repeat");
			}
		},

		// 开关切换
		statu_change: function() {
			$("#calendarEdit #idAllDay").toggleClass("active");
			if ($("#calendarEdit #idAllDay").hasClass("active")) {

				$("#calendarEdit #startTimeall").val($("#calendarEdit #startTime").val().split(' ')[0]);
				$("#calendarEdit #endTimeall").val($("#calendarEdit #endTime").val().split(' ')[0]);

				$("#calendarEdit #formNoAll").hide();
				$("#calendarEdit #formAll").show();
				//初始化提醒
				me.remind_initialize();
			} else {

				$("#calendarEdit #formNoAll").show();
				$("#calendarEdit #formAll").hide();
				//初始化提醒
				me.remind_initialize();
			}
		},

		//全天设置时间
		setTimeall: function(e) {
			$("input").blur();
			if (me.tapTime != 1) return;
			var target = e.target;
			var realtarget;
			var repeatType = Store.loadObject("calendarBf_repeat_type");
			if (target.id == "startTimeall") {
				realtarget = $("#calendarEdit #startTime");
			} else if (target.id == "endTimeall") {
				realtarget = $("#calendarEdit #endTime");
			} else if (target.id == "thingEndTime") {
				realtarget = $("#calendarEdit #thingEndTime");
			};
			var dateJson = {
				"selectDate": $(target).val() + " 00:00:00",
				"MaxDate": "2100-01-01 00:00:00",
				"MinDate": "2000-01-01 00:00:00"
			};
			if (target.id == "thingEndTime") {
				dateJson.MaxDate = me.calThingEndTimeEdit() + " 00:00:00";
				dateJson.MinDate = $("#calendarEdit #endTime").val() + ":00";
			};
			if (isApple) {
				bsl.infinitus.tools.showDatePicker(0, JSON.stringify(dateJson), function(date) {
					var time = $(realtarget).val().split(' ')[1];
					$(realtarget).val(date.split(' ')[0] + " " + time);
					$("#calendarEdit #startTimeall").val($("#calendarEdit #startTime").val().split(' ')[0]);
					$("#calendarEdit #endTimeall").val($("#calendarEdit #endTime").val().split(' ')[0]);
					$("#calendarEdit #thingEndTime").val($("#calendarEdit #thingEndTime").val().split(' ')[0]);
					if (!Validator.setTimeIsRight("calendarEdit", "startTime", "endTime")) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					var endTime = moment($("#calendarEdit #endTime").val()).unix();
					var thingEngTime = moment($("#calendarEdit #thingEndTime").val() + ' 23:59:59').unix();
					if (endTime > thingEngTime && parseInt(repeatType) != 0) {
						bsl.infinitus.tools.showToast("重复结束时间 必须 大于 结束时间", 2000);
					}
					if (target.id != "thingEndTime") {
						me.calThingEndTimeEdit();
					};
				});
			} else {
				bsl.infinitus.tools.showDatePicker(0, JSON.stringify(dateJson), function(date) {
					var time = $(realtarget).val().split(' ')[1];
					$(realtarget).val(date + ' ' + time);
					$("#calendarEdit #startTimeall").val($("#calendarEdit #startTime").val().split(' ')[0]);
					$("#calendarEdit #endTimeall").val($("#calendarEdit #endTime").val().split(' ')[0]);
					$("#calendarEdit #thingEndTime").val($("#calendarEdit #thingEndTime").val().split(' ')[0]);

					if (!Validator.setTimeIsRight("calendarEdit", "startTime", "endTime")) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					var startTime = moment($("#calendarEdit #endTime").val()).unix();
					var thingEngTime = moment($("#calendarEdit #thingEndTime").val() + ' 23:59:59').unix();
					if (endTime > thingEngTime) {
						bsl.infinitus.tools.showToast("重复结束时间 必须 大于 结束时间", 2000);
					}
					//});
					if (target.id != "thingEndTime") {
						me.calThingEndTimeEdit();
					};
				});
			}
		},
		//设置时间
		setTime: function(e) {
			$("input").blur();
			if (me.tapTime != 1) return;
			var target = e.target;
			// ios 和 android 处理方式不同。ios直接选择时间日期， Android分开进行
			if (isApple) {
				bsl.infinitus.tools.showDatePicker(2, $(target).val() + ":00", function(date) {
					$(target).val(date.slice(0, -3));

					if (!me.setTimeIsRight($("#calendarEdit #startTime").val(), $("#calendarEdit #endTime").val())) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					}
					if (target.id != "thingEndTime") {
						me.calThingEndTimeEdit();
					};
				});
			} else {
				bsl.infinitus.tools.showDatePicker(1, $(target).val() + ":00", function(date) {
					$(target).val(date.slice(0, -3));
					if (!me.setTimeIsRight($("#calendarEdit #startTime").val(), $("#calendarEdit #endTime").val())) {
						bsl.infinitus.tools.showToast("开始时间 必须 小于 结束时间", 2000);
					};
					if (target.id != "thingEndTime") {
						me.calThingEndTimeEdit();
					};
				});
			}
		},

		// 判断 开始时间是否小于结束时间
		setTimeIsRight: function(startime, endtime) {
			if (!$("#calendarEdit #idAllDay").hasClass('active')) { //取值年月日 时分
				var strarr = startime.split(' ');
				var endarr = endtime.split(' ');
				var strdate = new Date(parseInt(strarr[0].split('-')[0]), parseInt(strarr[0].split('-')[1]) - 1, parseInt(strarr[0].split('-')[2]), parseInt(strarr[1].split(':')[0]), parseInt(strarr[1].split(':')[1]));
				var enddate = new Date(parseInt(endarr[0].split('-')[0]), parseInt(endarr[0].split('-')[1]) - 1, parseInt(endarr[0].split('-')[2]), parseInt(endarr[1].split(':')[0]), parseInt(endarr[1].split(':')[1]));
			} else { //取值年月日
				var strdate = new Date(parseInt(startime.split('-')[0]), parseInt(startime.split('-')[1]) - 1, parseInt(startime.split('-')[2]));
				var enddate = new Date(parseInt(endtime.split('-')[0]), parseInt(endtime.split('-')[1]) - 1, parseInt(endtime.split('-')[2]));
			}
			var stime = strdate.getTime();
			var endtime = enddate.getTime();

			if (stime > endtime) {
				return false;
			}
			return true;
		},

		// 设置 重复事件 和 重复事件的值
		set_repeat_remind: function() {

			if (typeof Store.loadObject("calendarBf_remind_type") !== 'undefined') {
				$("#calendarEdit #remind").text(remindArrText[Store.loadObject("calendarBf_remind_type")]);
				$("#calendarEdit #remind").attr("data-type", Store.loadObject("calendarBf_remind_type"));
			}

			if (typeof Store.loadObject("calendarBf_repeat_type") !== "undefined") {

				$("#calendarEdit #repeat").text(repeatArrText[Store.loadObject("calendarBf_repeat_type")]);
				$("#calendarEdit #repeat").attr("data-type", Store.loadObject("calendarBf_repeat_type"));
				Store.loadObject("calendarBf_repeat_type") != 0 ? $("#calendarEdit #thingEndTimeDiv").show() : $("#calendarEdit #thingEndTimeDiv").hide();

			}
		},
		// 初始化提醒“无”
		remind_initialize: function() {
			$("#calendarEdit #remind").text(remindArrText[0]);
			$("#calendarEdit #remind").attr("data-type", 0);
			Store.saveObject("calendarBf_remind_type", "0");
		},

		onShow: function() {
			$(window).bind("calThingEndTimeEdit", function() {
				me.calThingEndTimeEdit();
			})
			if (!isPad) {
				Store.saveObject("calendarBf_edit", "edit");
				if (isInApp && !Store.loadObject("calendarBf_isApple")) {
					bsl.infinitus.tools.setBackAction(backAction);
				}
				$("#remarks").css("height", "80px");
			}
			if (isPad) {
				$("#calendarEdit .bar").css("position", "absolute");
				$("#ipadMy").css("margin-top", "0");
				$("#remarks").css("overflow", "hidden");
			}

			$("#calendarEdit .back").on("tap", function() {
				$("#calendarEdit #tittle").blur();
				$("#calendarEdit #address").blur();
				$("#calendarEdit #remarks").blur();
				if ($("#calendarEdit #tittle").val() == "") {
					if (isPad) {
						me.getBack();
					} else {
						if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
							window.butterfly.navigate('module_calendarBf/calendarDetails', {
								trigger: true
							});
						} else {
							window.butterfly.navigate('module_calendarBf/calendarDetails', {
								trigger: true
							});
						}
					}
				} else {
					bsl.infinitus.tools.showDialog("提示", "是否修改内容？", ['是', '否'], function(tap) {
						//$("#shadow-dialg").hide();
						if (!tap) {
							me.showSaveDiv();
						} else {
							if (isPad) {
								me.getBack();
							} else {
								if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
									window.butterfly.navigate('module_calendarBf/calendarDetails', {
										trigger: true
									});
								} else {
									window.butterfly.navigate('module_calendarBf/calendarDetails', {
										trigger: true
									});
								}
							}
						}
					});
				}
			});


			var show_obj = Store.loadObject("calendarBf_show_detail_obj");
			CalendarCommon.init();
			var item = {
				id: $("#calendarDetails #edit").attr('itemId')
			};
			CalendarCommon.pageCalendarSelectOneItem(item, function(data) {

				var show_obj = data.item(0);

				$("#calendarEdit #tittle").val(show_obj.title);
				$("#calendarEdit #remarks").val(show_obj.remarks);
				$("#calendarEdit #address").val(show_obj.address);

				thingEndTime = show_obj.thingEndTime; //设置为默认值
				remindMark = show_obj.remindMark;

				// 全天事件开关按钮显示
				if (show_obj.allDay == 'true') {
					//开
					$("#calendarEdit #idAllDay").addClass("active");
					var time = moment().format('HH:mm:ss');
					var SDate = moment.unix(show_obj.startTime).format("YYYY-MM-DD HH:mm");
					var EDate = moment.unix(show_obj.endTime).format("YYYY-MM-DD HH:mm");
					$("#calendarEdit #startTime").val(moment(SDate.split(" ")[0] + ' ' + time).format('YYYY-MM-DD HH:mm'));
					$("#calendarEdit #endTime").val(moment(EDate.split(" ")[0] + ' ' + time).add(1, 'hours').format('YYYY-MM-DD HH:mm'));
					$("#calendarEdit #startTimeall").val($("#calendarEdit #startTime").val().split(' ')[0]);
					$("#calendarEdit #endTimeall").val($("#calendarEdit #endTime").val().split(' ')[0]);
					$("#calendarEdit #formNoAll").hide();
					$("#calendarEdit #formAll").show();

				} else {
					//关
					$("#calendarEdit #startTime").val(moment.unix(show_obj.startTime).format("YYYY-MM-DD HH:mm"));
					$("#calendarEdit #endTime").val(moment.unix(show_obj.endTime).format("YYYY-MM-DD HH:mm"));
					$("#calendarEdit #idAllDay").removeClass("active");
					$("#calendarEdit #formNoAll").show();
					$("#calendarEdit #formAll").hide();
				};



				repeatType = show_obj.repeat;
				itemId = show_obj.id;
				thingId = show_obj.thingid;
				Func._addDeleteBtn(10, 2);
				me.set_repeat_remind();
				if (typeof Store.loadObject("calendarBf_repeat_type") !== "undefined") {
					if (parseInt(thingEndTime) == 0) {
						$("#calendarEdit #thingEndTime").val(thingEndTime);
					} else {
						$("#calendarEdit #thingEndTime").val(moment.unix(thingEndTime).format('YYYY-MM-DD'));
					};

				}
				$("#forNothing").val("dd");

				$('[data-click-title="标题"]').attr("data-click-title","编辑事件");
			    $('[data-focus-title="标题"]').attr("data-focus-title","编辑事件");
			});
			me.calThingEndTimeEdit();
			bsl.infinitus.cat.analytics({
                "category": "编辑事件",
                "action": "浏览",
                "label": "",
                "value": show_obj.id
            });
		},
		// 设置开始时间和结束时间的间隔
		setHour: function(date) {
			var time = moment().format('HH:mm:ss');
			$("#calendarEdit #startTime").val(moment(date + ' ' + time).format('YYYY-MM-DD HH:mm'));
			$("#calendarEdit #endTime").val(moment(date + ' ' + time).add(1, 'hours').format('YYYY-MM-DD HH:mm'));
		},

		// 存储开始时间 和 结束时间
		start_end_save: function() {
			var show_obj = Store.loadObject("calendarBf_show_detail_obj");
			$("#calendarEdit #startTime").val(show_obj.startTime.split(' ')[0]);
			$("#calendarEdit #endTime").val(show_obj.endTime.split(' ')[0]);
		},

		showSaveDiv: function() {
			$("input").blur();
			var allDay = false;
			var repeatype = $("#calendarEdit #repeat").attr("data-type");
			if ($("#calendarEdit #idAllDay").hasClass("active")) {
				allDay = true;
			}

			var timeIsOk = Validator.setTimeIsRight("calendarEdit", "startTime", "endTime", allDay);
			var isTitleEmpty = Validator.isEmpty("calendarEdit", "tittle");

			if (!isTitleEmpty) {
				bsl.infinitus.tools.showDialog("提示", "请输入事件标题。", ["确定"], function() {});
				return;
			}

			if (!timeIsOk) {
				bsl.infinitus.tools.showDialog("提示", "无法储存事件，开始时间必须早于结束时间", ["确定"], function() {});
				return;
			}
			if (allDay) {
				var timeText = Validator.repeatAndTime("calendarEdit", "startTimeall", "endTimeall", repeatype);
			} else {
				var timeText = Validator.repeatAndTime("calendarEdit", "startTime", "endTime", repeatype);
			}
			if (timeText != '') {
				bsl.infinitus.tools.showDialog("提示", timeText, ["确定"], function() {});
				return;
			}


			var theObj = Store.loadObject('calendarBf_show_detail_obj');
			var thingEndTime = moment($('#calendarEdit #thingEndTime').val()).unix();
			pageType = $("#calendarEdit #repeat").attr("data-type");

			if (repeatType == 0) { //日程本身为非重复事件
				if (pageType != "0") { //在页面选择了重复事件
					me.saveAllData();
				} else {
					Store.saveObject("calendarBf_editPageType", "only");
					me.saveOneData();
				}
			} else if (repeatType == pageType && theObj.thingEndTime == thingEndTime) { //日程本身重复类型与所选重复类型一致
				$("#calendarEdit #saveDiv .btn[data-type='only']").show()
				$("#calendarEdit #saveDiv").show();
				$("#calendarEdit #DivYY").show();
			} else {
				$("#calendarEdit #saveDiv .btn[data-type='only']").hide();
				$("#calendarEdit #saveDiv").show();
			}

		},
		//隐藏阴影层
		saveclose: function() {
			$("#calendarEdit #DivYY").hide();
		},
		/**
		 * [transitionHideFn 隐藏div]
		 * @type {[type]}
		 * @param {[type] string} [varname pageId] [页面id]
		 * @param {[type] string} [varname idName] [元素id]
		 */
		transitionHideFn: function(pageId, idName) {
			$("#" + pageId + " #" + idName).hide();
		},
		//修改单条数据
		saveOneData: function() {

			var item = Func.getThingInf('calendarEdit', remindMark);
			item.id = itemId;
			CalendarCommon.pageCalendarModifyOneItem(item, function(data) {
				me.saveDone();
			}, function() {
				bsl.infinitus.tools.showToast('修改失败', 2000);
			});
		},
		saveDone: function(itemId) {
			//添加提醒
			CalendarCommon.initRemind();
			//获取页面数据
			var theObj = Func.getThingInf('calendarEdit', remindMark);
			if (itemId) { //如果是修改全部
				theObj.id = itemId;
			}
			Store.saveObject("calendarBf_show_detail_obj", _.extend(Store.loadObject("calendarBf_show_detail_obj"), theObj));
			Store.saveObject("calendarBf_remind_type", theObj.remind);
			Store.saveObject("calendarBf_repeat_type", theObj.repeat);
			Store.saveObject("calendarBf_allDay_type", theObj.allDay);
			me.showSetTips();
			if (isPad) me.parentView.refreshInf();
		},
		showSetTips: function() {
			var theObj = Func.getThingInf('calendarEdit', remindMark);
			var isIos = Store.loadObject("calendarBf_isApple");
			if (parseInt(theObj.remind) != 0 && isIos == true) { //有提醒且是IOS系统
				bsl.infinitus.lcnotifiction.getNavigationStatus(function(sCallback) {
					if (parseInt(sCallback) == 0) {
						bsl.infinitus.tools.showDialog("提示", "如果开启提醒功能，请在系统设置中，开启通知", ['关闭', '前往设置'], function(tap) {
							if (!tap) {

								if (isPad) {
									me.getBack();
								} else {
									window.butterfly.navigate('module_calendarBf/calendarDetails', {
										trigger: true
									});
								}

							} else {

								if (isPad) {
									me.getBack();
								} else {
									window.butterfly.navigate('module_calendarBf/calendarDetails', {
										trigger: true
									});
								}

								// 系统设置代码
								bsl.infinitus.tools.openSettingsURLString();
							}
						});
					} else {
						if (isPad) {
							me.getBack();
						} else {
							window.butterfly.navigate('module_calendarBf/calendarDetails', {
								trigger: true
							});
						}
					}
				})

			} else {
				if (isPad) {
					me.getBack();
				} else {
					window.butterfly.navigate('module_calendarBf/calendarDetails', {
						trigger: true
					});
				}
			}
		},
		//修改所有数据
		saveAllData: function() {
			var thing = Func.getThingInf('calendarEdit', remindMark);
			thing.id = thingId;
			CalendarCommon.pageCalendarModifyAllItem(thing, function(itemId) {
				me.saveDone(itemId);
			}, function(err) {
				bsl.infinitus.tools.showToast('修改失败', 2000);
			});
		},
		showDbSelectThing: function() {
			CalendarCommon.pageCalendarSelectAllThing(
				function(itemArr) {
					var log = "";
					for (var i = 0; i < itemArr.length; i++) {
						var item = itemArr.item(i);
						log += 'title:' + item.title + ',allDay:' + item.allDay + ',address:' + item.address + ',startTime:' + item.startTime + ',endTime:' + item.endTime + ',remarks:' + item.remarks + ',remindMark:' + item.remindMark + ',thingEndTime:' + item.thingEndTime + ',remind:' + item.remind + ',repeat:' + item.repeat + ',modifyids:' + item.modifyids + '\n';
					};
					$("#remarks").val(log);
				},
				function() {

				}
			);
		},
		showDbSelectItem: function() {
			var startTime = 1;
			var endTime = 100000000000000000;
			CalendarCommon.pageGetCalendarItemByStartEndTime(startTime, endTime,
				function(itemArr) {
					var log = "";
					for (var i = 0; i < itemArr.length; i++) {
						var item = itemArr[i];
						log += " item:" + item.id + ",thingid:" + item.thingid + ",date:" + item.date + ',title:' + item.title + ',allDay:' + item.allDay + ',address:' + item.address + ',startTime:' + item.startTime + ',endTime:' + item.endTime + ',remarks:' + item.remarks + ',remindMark:' + item.remindMark + ',remindTime:' + item.remindTime + ',modify:' + item.modify + '\n';
					};
					$("#calendarEdit #remarks").val(log);
				},
				function() {
					$("#calendarEdit #remarks").val("error");
				}
			);
		},

		saveFun: function(e) {

			var theObj = Func.getPageInf('calendarEdit', remindMark);
			var thing = Func.getThingInf('calendarEdit', remindMark);

			theObj.mark = Store.loadObject("calendarBf_show_detail_obj").mark;

			var target = e.target;
			if ($(target).data("type") == "only") {

				Store.saveObject("calendarBf_editPageType", "only");
				me.saveOneData();

			} else if ($(target).data("type") == "all") {

				Store.saveObject("calendarBf_editPageType", "all");
				me.saveAllData();
			} else {
				me.transitionHideFn("calendarEdit", "saveDiv");
				$("#calendarEdit #DivYY").hide();
				return;
			}

		},
		// 页面内加载页面
		showInnerPage: function(pageObjet, html) {
			if (pageObjet) {
				pageObjet.show();
				pageObjet.$el.css({
					'display': 'block'
				});
				pageObjet.animateSlideInUp();
			} else {
				require(['view!module_calendarBf/' + html + '.html'], function(ViewClass) {
					pageObjet = new ViewClass();
					pageObjet.$el.css({
						'position': 'absolute',
						'top': '0px',
						'bottom': '0px',
						'width': '100%',
						'z-index': 1000
					});
					pageObjet.parentView = me;
					pageObjet.render();
					me.el.appendChild(pageObjet.el);
					pageObjet.show();
				}, function(err) {
					bsl.infinitus.tools.showToast("操作失败，请重试", 2000);
				});
			};
		},
		showBtnClear: function(e) {
			var target = e.target;
			var val = $(target).val();
			if (val != "") {
				$(target).next("span").show();
			} else {
				$(target).next("span").hide();
			};
			if ($(target).hasClass("titleInput")) {
				inputVal = $(target).val().substring(0, 40);
			} else {
				inputVal = $(target).val().substring(0, 60);
			};
		},
		hideBtnClear: function(e) {
			var target = e.target;
			$(target).next("span").hide();
		},
		getInputVal: function(e) { //此方法移到showBtnClear 里去了
			var target = e.target;
			if ($(target).hasClass("titleInput")) {
				inputVal = $(target).val().substring(0, 40);
			} else {
				inputVal = $(target).val().substring(0, 60);
			};
		},
		checkNum: function(e) {
			var target = e.target;
			val = $(target).val();
			if ($(target).hasClass("titleInput")) {
				if (val.length <= 40) {
					inputVal = val;
				} else {
					$(target).val(inputVal);
				};
			} else {
				if (val.length <= 60) {
					inputVal = val;
				} else {
					$(target).val(inputVal);
				};
			};
		},
		noDoubleTap: function() {
			me.tapTime = 2;
			setTimeout(function() {
				me.tapTime = 1;
			}, 500);
		},
		focusArea: function() {
			$("#calendarEdit textarea").focus();
			if (!isPad) {
				setTimeout(function() {
					$("#calendarEdit .content").scrollTop(300);
				}, 500);
			};
		},
		calThingEndTimeEdit: function() {
			var val;
			var endTime = moment($("#calendarEdit #endTime").val()); //获取结束时间
			var thingEndTime = $("#calendarEdit #thingEndTime");
			var repeatType = parseInt(Store.loadObject("calendarBf_repeat_type")); //获取重复类型
			if (repeatType == "1") {
				val = moment(endTime).add(7, "days"); //默认结束重复是7天后
				maxVal = moment(endTime).add(1, "years"); //最大重复周期为1年
				if (thingEndTime.val() == 0) { //如果为空时，表示之前未激活，填入默认结束重复时间
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix(); //如果不为空，获取已有的结束时间
					var unixEndTime = moment(endTime).unix(); //获取此时的事件结束时间
					var unixMaxVal = moment(maxVal).unix(); //将最大结束重复时间转为unix时间
					if (unixThingEndTime <= unixEndTime) { //如果小于或等于结束时间，则设置为结束时间（即重复的最小值）
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) { //如果大于或等于最大结束重复时间，则设置为结束重复最大值
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD'); //返回结束重复最大值供上面限制时间控件使用
			} else if (repeatType == "2") {
				val = moment(endTime).add(1, "months");
				maxVal = moment(endTime).add(3, "years");
				if (thingEndTime.val() == 0) {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == "3") {
				val = moment(endTime).add(2, "months");
				maxVal = moment(endTime).add(5, "years");
				if (thingEndTime.val() == 0) {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == "4") {
				val = moment(endTime).add(1, "years");
				maxVal = moment(endTime).add(10, "years");
				if (thingEndTime.val() == 0) {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			} else if (repeatType == "5") {
				val = moment(endTime).add(5, "years");
				maxVal = moment(endTime).add(20, "years");
				if (thingEndTime.val() == 0) {
					thingEndTime.val(moment(val).format('YYYY-MM-DD'));
					return;
				} else {
					var unixThingEndTime = moment(thingEndTime.val()).unix();
					var unixEndTime = moment(endTime).unix();
					var unixMaxVal = moment(maxVal).unix();
					if (unixThingEndTime <= unixEndTime) {
						thingEndTime.val(moment(endTime).format('YYYY-MM-DD'));
					} else if (unixThingEndTime >= unixMaxVal) {
						thingEndTime.val(moment(maxVal).format('YYYY-MM-DD'));
					};
				};
				return maxVal = moment(maxVal).format('YYYY-MM-DD');
			}
		}
	});
	return model;
});

define('text!module_calendarBf/calendarRemind-Allday.html',[],function () { return '<div data-view="calendarRemind-Allday" id="calendarRemind-Allday" class="views">\n\t<style>\n\t\t#calendarRemind-Allday .padding-right11{\n\t    \tpadding-right:11px;\n\t    }\n\t    #calendarRemind-Allday .icon-check{\n\t    \tfont-family: Ratchicons;\n\t    \tcolor:#5baaa4;\n\t    }\n\t    #calendarRemind-Allday .li_top{\n\t    \tline-height: 24px;\n\t    \tcolor: #000;\n\t    \tfont-family: arial,YouYuan;\n\t    }\n\t    #calendarRemind-Allday .li_top +span{\n\t    \tdisplay: none;\n\t    }\n\t    #calendarRemind-Allday .table-view-cell{\n\t    \tcolor: #000;\n\t    \tpadding-top: 10px;\n\t    \tpadding-bottom: 10px;\n\t    }\n\t    \n\n\t</style>\n\t<div id=\'module-calendarBf-calendarRemind-Allday\'>\n\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t<div class="ui3-row-12">\n\t\t\t<div class="ui3-col-3 ui3-icon-back back">返回</div>\n\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">事件提醒</div>\n\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"></div>\n\t\t</div>\n\t</header>\n\n   <!-- <header class="bar bar-nav blue-bar top-background-color">\n        <button class="btn btn-link btn-nav pull-left back">\n            <span class="icon icon-left-nav  back_icon rachicons"><span>返回</span></span>\n        </button>\n        <h1 class="title">事件提醒</h1>\n    </header>-->\n    <div class="content" style="background: #F2F2F2">\n    \t<section id="section_wrap">\n\t   \t\t<ul class="table-view" style="margin-top:10px;">\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="0">\n\t  \t\t\t\t<span class="li_top" id="top_id" data-type="0">无</span><span style="display:inline" class="icon icon-check pull-right" data-type="0"></span>\n\t  \t\t\t</li>\n\t\t  \t</ul>\n    \t\t<ul class="table-view" style="margin-top:5px;">\n\t  \t\t\t\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="10">\n\t  \t\t\t<span class="li_top" data-type="10">当天(9:00)</span><span class="icon icon-check pull-right rachicons" data-type="10"></span>\n\t  \t\t\t\t\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="11">\n\t  \t\t\t\t<span class="li_top" data-type="11">1天前(9:00)</span><span class="icon icon-check pull-right rachicons" data-type="11"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="12">\n\t  \t\t\t\t<span class="li_top" data-type="12">2天前(9:00)</span><span class="icon icon-check pull-right rachicons" data-type="12"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="13">\n\t  \t\t\t\t<span class="li_top" data-type="13">1周前(9:00)</span><span class="icon icon-check pull-right rachicons" data-type="13"></span>\n\t  \t\t\t</li>\n\t  \t\t\t\n\t  \t\t</ul>\n    \t</section>\n\t</div>\n\t</div>\n</div>\n';});

define('module_calendarBf/calendarRemind-Allday',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store','init'
], function($, View, calendarTpl, eventListTpl, EMCSUtil, Store, init) {
	var me = null;
	var currentDate = null;
	var isPad = Store.loadObject('calendarBf_isPad');
	var model = View.extend({

		events: {
			'tap #module-calendarBf-calendarRemind-Allday li': 'event_remind',
			'tap #module-calendarBf-calendarRemind-Allday .back': "getBack"
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			me = this;
		},
		getBack: function() {
			setTimeout(function() {
				me.animateSlideOutRight();
				me.parentView.remindPage = null;
				setTimeout(function() {
					$(me.el).remove()
				}, 100);
			}, 300);
		},
		onShow: function() {
			if (isPad) {
				$("#calendarRemind-Allday .bar").css("position", "absolute");
			}

			$("li").each(function() {
				if ($(this).data("type") == Store.loadObject("calendarBf_remind_type")) {
					$(this).find(".icon-check").css("display", "inline");
				} else {
					$(this).find(".icon-check").hide();
				}
			})

		},
		event_remind: function(e) {
			var target = e.target;
			Store.saveObject("calendarBf_remind_type", $(target).data("type"));
			var li = e.currentTarget;
			var my_tar = li.children[1];
			$(my_tar).show();
			var check = $(my_tar).css('display');
			if (check != 'none') {
				var test = $('li');
				for (var i = 0; i < test.length; i++) {
					var mm = test[i].children[1];
					if (mm !== my_tar) {
						$(mm).hide();
					}
				}
			}
			me.parentView.set_repeat_remind();
			me.getBack();
		}

	});
	return model;
});

define('text!module_calendarBf/calendarRemind.html',[],function () { return '<div data-view="calendarRemind" id="calendarRemind" class="views">\n\t<style>\n\t\t#calendarRemind .padding-right11{\n\t    \tpadding-right:11px;\n\t    }\n\t    #calendarRemind .icon-check{\n\t    \tcolor:#5baaa4;\n\t    \tfont-family: Ratchicons;\n\t    }\n\t    #calendarRemind .li_top{\n\t    \tline-height: 24px;\n\t    \tcolor: #000;\n\t    \tfont-family: arial,YouYuan;\n\t    }\n\t    #calendarRemind .li_top +span{\n\t    \tdisplay: none;\n\t    }\n\t    #calendarRemind .table-view-cell{\n\t    \tcolor: #000;\n\t    \tpadding-top: 10px;\n\t    \tpadding-bottom: 10px;\n\t    }\n\t    #calendarRemind #calendar-moudel-calendarRemind{overflow: auto;}\n\n\t</style>\n\t<div id="module-calendarBf-calendarRemind">\n\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t<div class="ui3-row-12">\n\t\t\t<div class="ui3-col-3 ui3-icon-back back">返回</div>\n\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">事件提醒</div>\n\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"></div>\n\t\t</div>\n\t</header>\n    <!--<header class="bar bar-nav blue-bar top-background-color">\n        <button class="btn btn-link btn-nav pull-left back">\n            <span class="icon icon-left-nav  back_icon rachicons"><span class="youyuan">返回</span></span>\n        </button>\n        <div class="title">事件提醒</div>\n    </header>-->\n    <div class="content" style="background: #F2F2F2" id="calendar-moudel-calendarRemind">\n    \t<section id="section_wrap">\n\t   \t\t<ul class="table-view" style="margin-top:10px;">\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="0">\n\t  \t\t\t\t<span class="li_top" id="top_id" data-type="0">无</span><span style="display:inline" class="icon icon-check pull-right rachicons" data-type="0"></span>\n\t  \t\t\t</li>\n\t\t  \t</ul>\n    \t\t<ul class="table-view" style="margin-top:5px;">\n\t  \t\t\t\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="1">\n\t  \t\t\t<span class="li_top" data-type="1">事件发生时</span><span class="icon icon-check pull-right rachicons" data-type="1"></span>\n\t  \t\t\t\t\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="2">\n\t  \t\t\t\t<span class="li_top" data-type="2">5分钟前</span><span class="icon icon-check pull-right rachicons" data-type="2"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="3">\n\t  \t\t\t\t<span class="li_top" data-type="3">15分钟前</span><span class="icon icon-check pull-right rachicons" data-type="3"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="4">\n\t  \t\t\t\t<span class="li_top" data-type="4">30分钟前</span><span class="icon icon-check pull-right rachicons" data-type="4"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="5">\n\t  \t\t\t\t<span class="li_top" data-type="5">1小时前</span><span class="icon icon-check pull-right rachicons" data-type="5"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="6">\n\t  \t\t\t\t<span class="li_top" data-type="6">2小时前</span><span class="icon icon-check pull-right rachicons" data-type="6"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="7">\n\t  \t\t\t\t<span class="li_top" data-type="7">1天前</span><span class="icon icon-check pull-right rachicons" data-type="7"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="8">\n\t  \t\t\t\t<span class="li_top" data-type="8">2天前</span><span class="icon icon-check pull-right rachicons" data-type="8"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="9">\n\t  \t\t\t\t<span class="li_top" data-type="9">1周前</span><span class="icon icon-check pull-right rachicons" data-type="9"></span>\n\t  \t\t\t</li>\n\t  \t\t</ul>\n    \t</section>\n\t</div>\n\t</div>\n</div>\n';});

define('module_calendarBf/calendarRemind',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store','init'
], function($, View, calendarTpl, eventListTpl, EMCSUtil, Store, init) {
	var me = null;
	var currentDate = null;
	var isPad = Store.loadObject('calendarBf_isPad');
	var model = View.extend({

		events: {
			'tap #module-calendarBf-calendarRemind li': 'event_remind',
			'tap #module-calendarBf-calendarRemind .back': "getBack"
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			me = this;
		},
		getBack: function() {
			setTimeout(function() {
				me.animateSlideOutRight();
				me.parentView.remindPage = null;
				setTimeout(function() {
					$(me.el).remove()
				}, 250);
			}, 200);
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		onShow: function() {
			if (isPad) {
				$("#calendarRemind .bar").css("position", "absolute");
			}

			$("li").each(function() {
				if ($(this).data("type") == Store.loadObject("calendarBf_remind_type")) {
					$(this).find(".icon-check").css("display", "inline");
				} else {
					$(this).find(".icon-check").hide();
				}
			});

		},
		event_remind: function(e) {
			var target = e.target;
			Store.saveObject("calendarBf_remind_type", $(target).data("type"));
			var li = e.currentTarget;
			var my_tar = li.children[1];
			$(my_tar).show();
			var check = $(my_tar).css('display');
			if (check != 'none') {
				var test = $('li');
				for (var i = 0; i < test.length; i++) {
					var mm = test[i].children[1];
					if (mm !== my_tar) {
						$(mm).hide();
					}
				}
			}

			me.parentView.set_repeat_remind();
			setTimeout(function() {
				me.getBack();
			}, 200);

		}

	});
	return model;
});

define('text!module_calendarBf/calendarRepeat.html',[],function () { return '<div data-view="calendarRepeat" id="calendarRepeat" class="views">\n\t<style>\n\t\t#calendarRepeat .padding-right11{\n\t    \tpadding-right:11px;\n\t    }\n\t    #calendarRepeat .icon-check{\n\t    \tcolor:#5baaa4;\n\t    }\n\t    #calendarRepeat .li_top{\n\t    \tline-height: 24px;\n\t    \tcolor: #000;\n\t    \tfont-family: arial,YouYuan;\n\t    }\n\t    #calendarRepeat .li_top +span{\n\t    \tdisplay: none;\n\t    }\n\t    #calendarRepeat .active_border{\n\t    \t\n\t    \tborder-bottom: 1px solid #A4A4A4;\n\t    }\n\t</style>\n\t<div id=\'module-calendarBf-calendarRepeat\'>\n\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t<div class="ui3-row-12">\n\t\t\t<div class="ui3-col-3 ui3-icon-back back">返回</div>\n\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">重复</div>\n\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"></div>\n\t\t</div>\n\t</header>\n\n   <!-- <header class="bar bar-nav blue-bar top-background-color">\n        <button class="btn btn-link btn-nav pull-left back">\n            <span class="icon icon-left-nav back_icon rachicons"><span>返回</span></span>\n        </button>\n        <h1 class="title" style="color:#fff">重复</h1> \n    </header>-->\n    <div class="content" style="background: #F2F2F2">\n    \t<section id="section_wrap">\n   \t\t\t<ul class="table-view" style="margin-top:10px;">\n\t  \t\t\t\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="0">\n\t  \t\t\t\t<span class="li_top" data-type="0">永不</span><span style="display:inline" class="icon icon-check pull-right rachicons" data-type="0"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="1">\n\t  \t\t\t\t<span class="li_top" data-type="1">每天</span><span class="icon icon-check pull-right rachicons" data-type="1"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="2">\n\t  \t\t\t\t<span class="li_top" data-type="2">每周</span><span class="icon icon-check pull-right rachicons" data-type="2"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="3">\n\t  \t\t\t\t<span class="li_top" data-type="3">每两周</span><span class="icon icon-check pull-right rachicons" data-type="3"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="4">\n\t  \t\t\t\t<span class="li_top" data-type="4">每月</span><span class="icon icon-check pull-right rachicons" data-type="4"></span>\n\t  \t\t\t</li>\n\t  \t\t\t<li class="table-view-cell padding-right11" data-type="5">\n\t  \t\t\t\t<span class="li_top" data-type="5">每年</span><span class="icon icon-check pull-right rachicons" data-type="5"></span>\n\t  \t\t\t</li>\n\t  \t\t\t\n\t  \t\t</ul>\n    \t</section>\n\t</div>\n\t</div>\n</div>\n';});

define('module_calendarBf/calendarRepeat',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../../butterfly/components/store',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store',
	'bsl', './js/validator', './js/moment.min', 'init'
], function($, View, calendarTpl, eventListTpl, Store, EMCSUtil, Store, bsl, Validator, moment, init) {
	var me = null;
	var currentDate = null;
	var isPad = Store.loadObject('calendarBf_isPad');
	var model = View.extend({

		events: {
			'tap #module-calendarBf-calendarRepeat li': 'if_check',
			'tap #module-calendarBf-calendarRepeat .back': "getBack"
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			me = this;
		},
		getBack: function() {
			setTimeout(function() {
				$(window).trigger('calThingEndTime'); //修改重复周期后，重新计算结束重复时间
				$(window).trigger('calThingEndTimeEdit'); //修改重复周期后，重新计算结束重复时间
				me.animateSlideOutRight();
				me.parentView.repeatPage = null;
				setTimeout(function() {
					$(me.el).remove()
				}, 250);
			}, 200);
		},
		onShow: function() {
			if (isPad) {
				$("#calendarRepeat .bar").css("position", "absolute");
			}

			$("li").each(function() {
				if ($(this).data("type") == Store.loadObject("calendarBf_repeat_type")) {
					$(this).find(".icon-check").css("display", "inline");
				} else {
					$(this).find(".icon-check").hide();
				}
			})
		},

		// 判断 事件开始 事件是不是 29 30 31 号
		isLastMonth: function() {
			// 不能加页面id 
			var startime = $('.repeatStart').val().split(" ")[0];
			var date = startime.split('-')[2];
			return date;
		},

		// 判断时间间隔
		getTimeDistence: function(repeatType, timeDistance) {
			var returnText = '';
			switch (repeatType) {
				case 1:
					if ($.inArray("day", timeDistance) != -1) {
						returnText = "事件时间间隔过大，无法创建重复事件。";
					}
					break;
				case 2:
					if ($.inArray("week", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
					break;
				case 3:
					if ($.inArray("two-week", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
					break;
				case 4:
					if ($.inArray("month", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
					break;
				case 5:
					if ($.inArray("year", timeDistance) != -1) {

						returnText = "事件时间间隔过大，无法创建重复事件。";

					}
			}
			return returnText;
		},

		if_check: function(e) {
			var target = e.target;
			var timeType = me.setTimeIsRight($('.repeatStart'), $('.repeatEnd'));
			var repeatype = $(target).data("type");
			var text = me.getTimeDistence(repeatype, timeType);
			if (text != '') {
				bsl.infinitus.tools.showDialog("提示", text, ["确定"], function() {});
				return;
			}
			if (repeatype >= '4' || repeatype == '1') {
				if (me.isLastMonth() == '29') {
					bsl.infinitus.tools.showDialog("提示", "没有29日的月份将不产生该重复事件", ["确定"], function() {});
				} else if (me.isLastMonth() == '30') {
					bsl.infinitus.tools.showDialog("提示", "没有30日的月份将不产生该重复事件", ["确定"], function() {});
				} else if (me.isLastMonth() == '31') {
					bsl.infinitus.tools.showDialog("提示", "没有31日的月份将不产生该重复事件", ["确定"], function() {});
				}
			}
			Store.saveObject("calendarBf_repeat_type", $(target).data("type"));
			var li = e.currentTarget;
			var my_tar = li.children[1];
			$(my_tar).show();
			var check = $(my_tar).css('display');
			if (check != 'none') {
				var test = $('li');
				for (var i = 0; i < test.length; i++) {
					var mm = test[i].children[1];
					if (mm !== my_tar) {
						$(mm).hide();
						$(test[i]).removeClass('active_border');
					}
				}
			}
			me.parentView.set_repeat_remind();
			setTimeout(function() {
				me.getBack();
			}, 200);
		},

		// 判断 开始时间 和结束 时间 的间隔
		setTimeIsRight: function(startime, endtime) {
			var stime, etime;
			if ($("#calendarAdd #idAllDay").hasClass('active')) {
				stime = moment(startime.val().split(" ")[0]).unix();
				etime = moment(endtime.val().split(" ")[0]).add(23, "h").add(59, "m").add(59, "s").unix();
			} else {
				stime = moment(startime.val()).unix();
				etime = moment(endtime.val()).unix();
			};
			var startAndEnd = etime - stime;
			var arr_checklist = [];
			// 间隔大于1天
			if (startAndEnd >= 60 * 60 * 24) {
				arr_checklist.push("day");
			}
			// 间隔大于一周
			if (startAndEnd >= 60 * 60 * 24 * 7) {
				arr_checklist.push("week");
			}

			// 间隔大于两周
			if (startAndEnd >= 60 * 60 * 24 * 14) {
				arr_checklist.push("two-week");
			}

			//是否同一个月
			var isSameMonth = true;
			if (moment.unix(stime).format("YYYY") == moment.unix(etime).format("YYYY") && moment.unix(stime).format("MM") == moment.unix(etime).format("MM")) {
				isSameMonth = true;
			} else {
				isSameMonth = false;
			}

			// 间隔是否大于一个月
			if (startAndEnd >= 60 * 60 * 24 * 28 && !isSameMonth) {
				arr_checklist.push("month");
			}
			var isSameYear = true;
			if (moment.unix(stime).format("YYYY") == moment.unix(etime).format("YYYY")) {
				isSameYear = true;
			} else {
				isSameYear = false;
			}
			// 间隔大于一年
			if (startAndEnd >= 60 * 60 * 24 * 365 && !isSameYear) {
				arr_checklist.push("year");
			}
			return arr_checklist;
		}

	});
	return model;
});

define('text!module_calendarBf/calendarSearch.html',[],function () { return '<div data-view="calendarSearch" id="calendarSearch" class="views">\n\t<style>\n\t\n  \t#calendarSearch input[type=text]{\n  \t   height:48px;\n  \t   border-radius: 10px;\n  \t}\n\n    #calendarSearch .padding-right11{\n    \tpadding-right:11px;\n    }\n   \t#calendarSearch .margin-right11{\n   \t\tmargin-right:-11px;\n   \t}\n\n   \t#calendarSearch .table-view-cell{\n   \t\tcolor:#000;\n   \t\tpadding-top:15px;\n   \t\tpadding-bottom:15px;\n   \t}\n\n   \t#calendarSearch .content-padded{\n   \t\tmargin:0;\n   \t\tpadding:11px 11px 11px 15px;\n   \t\tbackground-color: #fff;\n   \t}\n    \n\n    #calendarSearch #nav-list-repeat{\n      position: absolute;\n      width: 100%;\n      top: 80px;\n\n      \n      /*width: 100%;\n      float: left;*/\n    }\n    #calendarSearch .creatDate_tag {\n      border-bottom: 1px solid #D1D1D1;\n      display: none;\n    }\n    #calendarSearch .creatDate_tag li{\n      color: #A7D0CC;\n      text-align: center;\n      text-decoration: underline;\n      text-decoration-color:#A7D0CC;\n\n    }\n    #calendarSearch .up_content{\n      margin-bottom: 10px;\n    }\n  \n    #calendarSearch .up_content span{\n      font-size: 1.2em;\n      \n    }\n    #calendarSearch .bottom_content span{\n      color:#A4A4A4;\n    }\n    #calendarSearch .bottom_content .fengefu{\n      color: #E1E1E1;\n    }\n    #calendarSearch .titles{\n        overflow: hidden; /*自动隐藏文字*/\n        text-overflow: ellipsis;/*文字隐藏后添加省略号*/\n        white-space: nowrap;/*强制不换行*/\n        width: 18em;/*不允许出现半汉字截断*/\n    }\n    #calendarSearch #searchList_JRoll{\n      padding:0;\n      margin:0;\n      background-color:#FFFFFF;\n      z-index: 99;\n\n    }\n\n\n    /*loading*/\n#calendarSearch .spinner {\n  width: 10px;\n  height: 10px;\n  background-color: #FF6906;\n \n  border-radius: 100%;\n  display: inline-block;\n  -webkit-animation: bouncedelay 1.4s infinite ease-in-out;\n  animation: bouncedelay 1.4s infinite ease-in-out;\n  /* Prevent first frame from flickering when animation starts */\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n}\n\n@-webkit-keyframes bouncedelay {\n  0%, 80%, 100% { -webkit-transform: scale(0.0) }\n  40% { -webkit-transform: scale(1.0) }\n}\n \n@keyframes bouncedelay {\n  0%, 80%, 100% {\n    transform: scale(0.0);\n    -webkit-transform: scale(0.0);\n  } 40% {\n    transform: scale(1.0);\n    -webkit-transform: scale(1.0);\n  }\n}\n\t</style>\n\t\n  <script type="text/template" id="nav-scroll">   \n        <ul class="table-view" style="margin-top:10px;">\n            <div class="creatDate_tag">\n                <li class="table-view-cell padding-right11">\n                    查看2015-01-10之前\n                  </li>\n            </div>\n          \n             \n              <li class="table-view-cell padding-right11">\n                <div class="up_content"><span class="li_top">二月份工作讨论</span></div>\n                <div class="bottom_content">\n                  &nbsp;<span>全天</span>&nbsp;<span class="fengefu">|</span>\n                  <span>待定</span>\n                  </div>\n              </li>\n        </ul>\n  </script>\n  <div id="module-calendarBf-calendarSearch">\n    <header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n        <div class="ui3-row-12">\n            <div class="ui3-col-3 ui3-icon-back back" data-click-title="日程搜索" data-click-label="返回">返回</div>\n            <div class="ui3-col-6 ui3-fontsize-1 text-center header-title">搜索</div>\n            <div class="ui3-col-3 ui3-theme-color ui3-header-right"></div>\n        </div>\n    </header>\n\n   <!-- <header class="bar bar-nav blue-bar top-background-color">\n        <button class="btn btn-link btn-nav pull-left back">\n            <span class="icon icon-left-nav back_icon rachicons"><span>返回</span></span>\n        </button>\n        <div class="title">搜索</div>\n    </header>-->\n    <div class="content" style="background: #ffffff">\n    \t<section id="section_wrap">\n    \t\t\n    \t\t<ul class="table-view">\n   \t\t\t\t<li class="table-view-cell" style="background-color:#f2f2f2; border-bottom:none">\n   \t\t\t\t\t<input id="searchText" class="canClear" type="text" placeholder="请输入关键词" style="margin-bottom:0; border:none;" data-focus-title="日程搜索" data-focus-label="搜索内容">\n            <button id="searchBtn" direction="normal" class="btn btn-link" style="font-size:0.3rem; right:2px; color:#5baba2">搜索</button>\n   \t\t\t\t</li>\n   \t\t\t</ul>\n    \t</section>\n\t</div>\n  <!--<div class="creatDate_tag"style="line-height:40px;padding:0;top:130px;height:40px;position:absolute; text-align:center;width:100%;border-bottom:1px solid #eee;">\n                <li id="searchPre" class="table-view-cell padding-right11" style="list-style-type:none;line-height:40px;padding-top:0px;padding-bottom:0px;" date="">\n                    <span id="preString"></span>\n                  </li>\n  </div>-->\n  <div id="nav-list-repeat" class="iscroll-list"  style="position: relative;" >\n    <div class="item-content-repeat" >\n        <div id="searchList_JRoll" data-click-title="日程搜索" data-click-label="事件详情">\n          \n        </div>\n     </div>\n  </div>\n  <!--<div class="creatDate_tag" style="position:absolute;bottom:0px;border-top:1px solid #eee;border-bottom:none; text-align:center;width:100%;" date="">\n                <li id="searchBehind"class="table-view-cell padding-right11" style="list-style-type:none;">\n                    <span id="nextString"></span>\n                  </li>\n  </div>-->\n\t</div>\n\t\n</div>\n';});

define('module_calendarBf/calendarSearch',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'bsl',
	'../../butterfly/components/store',
	'./js/calendarFunc',
	 './js/common', './js/moment.min', 'init'
], function($, View, calendarTpl, eventListTpl, EMCSUtil, bsl, Store, Func, calendarCommon, moment, init) {
	window.backAction = function() {
		var localsion = window.location.href;
		var localcalendarAdd = localsion.indexOf("calendarAdd"); //新建事件
		var localcalendarDetails = localsion.indexOf("calendarDetails"); //事件详情
		var localcalendarEdit = localsion.indexOf("calendarEdit"); //编辑事件
		var localcalendarSearch = localsion.indexOf("calendarSearch"); //搜索事件
		var localcalendarRemind = localsion.indexOf("calendarRemind"); //非全天提醒
		var localcalendarRemindAllday = localsion.indexOf("calendarRemind-Allday"); //全天提醒
		var localcalendarRepeat = localsion.indexOf("calendarRepeat"); //重复
		var localmain = localsion.indexOf("main");
		if (localmain > -1) {
			bsl.infinitus.transfer.returnBack(true);
		} else if (localcalendarAdd > -1) {
			if (Store.loadObject("calendarBf_remind") == "remind") {
				Store.deleteObject("calendarBf_remind");
				$("#calendarRemind").remove();
			} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
				Store.deleteObject("calendarBf_remindAllday");
				$("#calendarRemind-Allday").remove();
			} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
				Store.deleteObject("calendarBf_repeat");
				$("#calendarRepeat").remove();
			} else {
				if (Store.loadObject("calendarBf_add") == "add") {
					bsl.infinitus.transfer.returnBack(false, "", function(data) {});
				}
			}
		} else if (localcalendarDetails > -1) {
			if ($("#calendarDetails #DivYY").css("display") != "none") {
				$("#calendarDetails #DivYY").hide();
				$("#calendarDetails #deleteDiv").hide();
				$("#calendarDetails #deleteDivOnly").hide();
			} else {
				if (Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
					//Util.navigate('module_calendarBf/calendarSearch');
					window.butterfly.navigate('module_calendarBf/calendarSearch', {
						trigger: true
					});
				} else {
					window.butterfly.navigate('module_calendarBf/main', {
						trigger: true
					});
				}
			}
		} else if (localcalendarEdit > -1) {
			if ($("#calendarEdit #DivYY").css("display") != "none") {
				$("#calendarEdit #DivYY").hide();
				$("#calendarEdit #saveDiv").hide();
			} else {
				if (Store.loadObject("calendarBf_remind") == "remind") {
					Store.deleteObject("calendarBf_remind");
					$("#calendarRemind").remove();
				} else if (Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
					Store.deleteObject("calendarBf_remindAllday");
					$("#calendarRemind-Allday").remove();
				} else if (Store.loadObject("calendarBf_repeat") == "repeat") {
					Store.deleteObject("calendarBf_repeat");
					$("#calendarRepeat").remove();
				} else {
					if (Store.loadObject("calendarBf_edit") == "edit") {
						bsl.infinitus.transfer.returnBack(false, "", function(data) {});
					}
				}
			}
		} else if (localcalendarSearch > -1) {
			window.butterfly.navigate('module_calendarBf/main', {
				trigger: true
			});
		}
	};
	var me = null;
	var currentDate = null;
	var isPad = Store.loadObject('calendarBf_isPad');
	var upDate; //保存向上日期
	var downDate; //保存向下日期
	var isEmpty = false;
	var model = View.extend({
		events: {
			"tap #module-calendarBf-calendarSearch #searchBtn, #module-calendarBf-calendarSearch #preString, #module-calendarBf-calendarSearch #nextString": "search",
			"tap #module-calendarBf-calendarSearch .list": "details",
			"input input": "showBtnClear",
			"focus input": "showBtnClear",
			"blur input": "hideBtnClear"
		},
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			Store.saveObject("calendarBf_isFirstEnter_two", true);
			me = this;
		},
		onShow: function() {
			if (isInApp && !Store.loadObject("calendarBf_isApple")) bsl.infinitus.tools.setBackAction(backAction);
			if ($("#calendarSearch #searchText").val() !== '') {
				me.search();
			} else {
				$("#calendarSearch #searchList_JRoll").html('<div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
			}
			$("#calendarSearch .back").off("tap").on("tap", function() {
				$("#calendarSearch #searchText").blur();
				window.butterfly.navigate('module_calendarBf/main', {
					trigger: true
				});
			});
			Func._addDeleteBtn(25, 67);
			/*bsl.infinitus.cat.analytics({
                "category": "日程搜索",
                "action": "浏览",
                "label": "",
                "value": ""
            });*/
		},

		// 设置高度
		setHeight: function() {
			var winHeight = $(window).height();
			var div = document.querySelector("#calendarSearch .item-content-repeat");
			var height = (winHeight - div.offsetParent.offsetTop);
			div.style.height = height + "px";
			$('#calendarSearch #searchList_JRoll').css('min-height', height + 'px');
		},
		// 进入事件详情页面
		details: function(e) {
			var theObj = {};
			var target = e.currentTarget;

			// while ($(target).attr("class") != "list") target = target.parentNode;
			theObj = {

				date: $(target).attr("data-date"),
				title: $(target).attr("data-title"),
				address: $(target).attr("data-address"),
				startTime: $(target).attr("data-startTime"),
				endTime: $(target).attr("data-endTime"),
				allDay: $(target).attr("data-allDay"),
				remind: $(target).attr("data-remind"),
				repeat: $(target).attr("data-repeat"),
				remarks: $(target).attr("data-remarks"),
				mark: $(target).attr("data-mark"),
				remindMark: $(target).attr("data-remindMark"),
				id: parseInt($(target).attr("data-itemId")),
				thingid: parseInt($(target).attr("data-thingid")),
				thingEndTime: $(target).attr("data-thingEndTime"),
				fromSearch: $(target).attr("data-from-search"),
                groupType:$(target).attr("data-group-type")
			}
			Store.saveObject("calendarBf_show_detail_obj", theObj);
			Store.saveObject("calendarBf_remind_type", $(target).data("remind"));
			Store.saveObject("calendarBf_repeat_type", $(target).data("repeat"));
			Store.saveObject("calendarBf_allDay_type", $(target).attr("data-allDay"));
			Store.saveObject("calendarBf_DetailsPrepage", "Search");
			Store.saveObject("calendarBf_searchEnter", true);
            var url = 'calendarDetails';
            if(theObj.groupType != '99'){//如果不是个人事件
                url="companyActivityDetail";
            }
			window.butterfly.navigate('module_calendarBf/'+url, {
				trigger: true
			});
		},

		renderTemplate: function() {

			var tpl = $(this.el).find("#nav-scroll").html();
			$(this.el).find("#searchList_JRoll").append(tpl);
		},

		openDatabase: function(dbName) {
			var DEFAULT_SIZE = 5000000;
			// return bsl.sqlite.openDatabase(dbName, "1.0", "calendar", DEFAULT_SIZE);
			return bsl.sqlite.openDatabase({name:dbName, location: 'default'});
		},

		//搜索
		search: function(e) {
			
		
			var value_search = $("#calendarSearch #searchText").val();
			if(value_search!=""){
				bsl.infinitus.cat.analytics({
	                "category": "日程搜索", 
	               	"action": "点击",
					"label":"搜索",
					"value":value_search
	            });
			}
			if ($("#calendarSearch #searchText").val() == '') return;
			var times = 1;
			var canSearch = false; //当执行过loading才可以search
			if (!me.Search_scroll) {
				me.Search_scroll = new JRoll("#calendarSearch .item-content-repeat", {
					bounce: true
				});

				me.Search_scroll.on("scroll", function(e) {
					if (this.y >= 50 && isEmpty == false && times == 1) {
						$('#calendarSearch .item-content-repeat').prepend('<div style="position:absolute;top:0px;width:100%" class="uploading"><div style="width:180px;margin:0px auto"><div class="spinner"></div> <span>下拉加载更多事件</span></div></div>');
						canSearch = true;
						times++;
					}
					if (this.y <= this.maxScrollY - 60 && isEmpty == false && times == 1) { //向上拉，往下搜索
						$('#calendarSearch .item-content-repeat').prepend('<div style="position:absolute;bottom:10px;width:100%;z-index:0" class="downloading"><div style="width:180px;margin:0px auto"><div class="spinner"></div> <span>上拉加载更多事件</span></div></div>');
						canSearch = true;
						times++;
					}
				});
				me.Search_scroll.on("scrollEnd", function(e) {
					if (this.y >= 0 && canSearch) { //向下拉，往上搜索
						me.doSearch('up', upDate, false);
					}

					if (this.y <= this.maxScrollY && canSearch) { //向上拉，往下搜索
						me.doSearch('down', downDate, false);
					}
					times = 1;
					canSearch = false;
					$('#calendarSearch .item-content-repeat .uploading').remove();
					$('#calendarSearch .item-content-repeat .downloading').remove();
				});
			}

			$("#calendarSearch #searchList_JRoll").html("");
			var now = Store.loadObject('calendarBf_currentDateTime') ? Store.loadObject('calendarBf_currentDateTime') : moment().startOf('day').unix();
			Store.saveObject('calendarBf_currentDateTime', '');
            me.setHeight();
            me.Search_scroll.scrollTo(0, 0);
            me.Search_scroll.refresh();
			setTimeout(function() {
				me.doSearch('normal', now, true);
			}, 500);

		},

		doSearch: function(direction, dateTime, isFirst) {
			var array = [];
			var search_text = $("#calendarSearch #searchText").val();
			if (!search_text) {
				$("#calendarSearch #searchList_JRoll").html('<div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
				return;
			}

			if (isEmpty) {
				$("#calendarSearch #searchList_JRoll").html("");
			}

			var searchConf = {
				key: search_text,
				dateTime: dateTime,
				direction: direction,
				isFirst: isFirst
			};
			calendarCommon.init();
			calendarCommon.pageGetCalendarItemByKeyWord(searchConf, function(res, direction) {
				for (var i = 0; i < res.length; i++) {
					theObj = {
						date: res[i].date,
						title: res[i].title,
						allDay: res[i].allDay,
						address: res[i].address,
						startTime: res[i].startTime,
						endTime: res[i].endTime,
						endDate: moment.unix(res[i].endTime).format('YYYY-MM-DD'),
						remind: res[i].remind,
						repeat: res[i].repeat,
						remarks: res[i].remarks,
						// mark 同一条记录的 mark 一致
						mark: res[i].mark,
						remindMark: res[i].remindMark,
						id: res[i].id,
						startTimeHourMin: res[i].startTimeHourMin,
						endTimeHourMin: res[i].endTimeHourMin,
						thingid: res[i].thingid,
						dateTime: moment.unix(res[i].startTime).format('YYYY-MM-DD'),
						thingEndTime: res[i].thingEndTime,
						fromSearch: 'true',
						groupType: res[i].groupType
					};
					array.push(theObj);
				}
				if (array.length) {
					// 显示到页面中
					me.shouDateThing(array, direction);
					var arrayLastRecord = array[array.length - 1];
					var arrayFristRecord = array[0];
					$("#calendarSearch .creatDate_tag").show();
					downDate = $('#calendarSearch #searchList_JRoll .list').last().attr('data-starttime');
					upDate = $('#calendarSearch #searchList_JRoll .list').first().attr('data-starttime');
					isEmpty = false;
				} else {
					if (direction != 'normal' && direction != 'again') {
						bsl.infinitus.tools.showToast("已加载全部", 2000);
						if (isEmpty) {
							$("#calendarSearch #searchList_JRoll").html('<div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
						}
					} else {
						upDate = downDate = dateTime;
						isEmpty = true;
						$("#calendarSearch #searchList_JRoll").html('<div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
						setTimeout(function(){
                        me.setHeight();
						me.Search_scroll.scrollTo(0, 0);
						me.Search_scroll.refresh();
                        })
					}
				}
			}, function(e) {});
		},

		// 查询显示 搜索结果
		shouDateThing: function(theArray, direction) {

			// var arr = [
			//    {title:'2月份员工会议工作讨论', allDay:true, address:'待定'},
			//    {title:'自助终端刷卡支付技术方案讨论会',startTime:'11:00',endTime:'12:00',address:'无限极中心 1906'},
			//    {title:'E帆网分享功能技术研讨会',startTime:'14:00',endTime:'16:00',address:'保利威座 2501A'}
			// ];
			if (direction == 'again' || direction == 'normal') { //防止连续点击搜索没有清空
				$("#calendarSearch #searchList_JRoll").html("");
			}
			var eventList = '';
			_.each(theArray,
				function(elem, index) {
					elem.noDate = false;
					var eventListHtml = _.template(eventListTpl, elem);
					if (direction == 'down' || direction == 'normal') {
						eventList = eventList + eventListHtml;
					}

					if (direction == 'up' || direction == 'again') {
						eventList = eventListHtml + eventList;
					}
				});
			var html = $("#calendarSearch #searchList_JRoll").html();
			if (direction == 'down' || direction == 'normal') {
				eventList = html + eventList;
				$("#calendarSearch #searchList_JRoll").html(eventList);
			}
			if (direction == 'up' || direction == 'again') {
				eventList = eventList + html;
				$("#calendarSearch #searchList_JRoll").html(eventList);
			}



			me.setHeight();
			if (direction == 'normal')
				me.Search_scroll.scrollTo(0, 0); // 搜索结果 使其日程回到顶部
			me.Search_scroll.refresh(); // 刷新scroll
			$('[data-click-title="标题"]').attr("data-click-title","日程搜索");
		},
		showBtnClear: function(e) {
			var target = e.target;
			var val = $(target).val();
			if (val != "") {
				$(target).next("span").show();
			} else {
				$(target).next("span").hide();
			};
		},
		hideBtnClear: function(e) {
			var target = e.target;
			$(target).next("span").hide();
		}
	});
	return model;
});

define('text!module_calendarBf/calendarSearch_pad.html',[],function () { return '<div data-view="calendarSearch_pad" id="calendarSearch_pad" class="views">\n\t<style>\n\t\n\t#calendarSearch_pad input[type=text]{\n\t   height:48px;\n\t   border-radius: 10px;\n\t}\n\n    #calendarSearch_pad .padding-right11{\n    \tpadding-right:11px;\n    }\n   \t#calendarSearch_pad .margin-right11{\n   \t\tmargin-right:-11px;\n   \t}\n   \t#calendarSearch_pad .table-view-cell{\n   \t\tcolor:#000;\n   \t\tpadding-top:15px;\n   \t\tpadding-bottom:15px;\n   \t}\n   \t#calendarSearch_pad .content-padded{\n   \t\tmargin:0;\n   \t\tpadding:11px 11px 11px 15px;\n   \t\tbackground-color: #fff;\n   \t}\n    #calendarSearch_pad #nav-list-repeat{\n      position: absolute;\n      width: 100%;\n      top: 100px;\n      \n      /*width: 100%;\n      float: left;*/\n    }\n    #calendarSearch_pad .creatDate_tag {\n      border-bottom: 1px solid #D1D1D1;\n    }\n    #calendarSearch_pad .creatDate_tag li{\n      color: #A7D0CC;\n      text-align: center;\n      text-decoration: underline;\n      text-decoration-color:#A7D0CC;\n\n    }\n    #calendarSearch_pad .up_content{\n      margin-bottom: 10px;\n    }\n    #calendarSearch_pad span{\n      font-family: "黑体";\n    }\n    #calendarSearch_pad .up_content span{\n      font-size: 1.2em;\n      \n    }\n    #calendarSearch_pad .bottom_content span{\n      color:#A4A4A4;\n    }\n    #calendarSearch_pad .bottom_content .fengefu{\n      color: #E1E1E1;\n    }\n    #calendarSearch_pad .titles{\n        overflow: hidden; /*自动隐藏文字*/\n        text-overflow: ellipsis;/*文字隐藏后添加省略号*/\n        white-space: nowrap;/*强制不换行*/\n        width: 18em;/*不允许出现半汉字截断*/\n    }\n    #calendarSearch_pad .item-content-repeat{height:400px;overflow:auto;}\n    #calendarSearch_pad #searchList_JRoll{padding:0;margin:0;min-height: 100%;}\n\n\n    /*loading*/\n#calendarSearch_pad .spinner {\n  width: 10px;\n  height: 10px;\n  background-color: #FF6906;\n \n  border-radius: 100%;\n  display: inline-block;\n  -webkit-animation: bouncedelay 1.4s infinite ease-in-out;\n  animation: bouncedelay 1.4s infinite ease-in-out;\n  /* Prevent first frame from flickering when animation starts */\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n}\n\n@-webkit-keyframes bouncedelay {\n  0%, 80%, 100% { -webkit-transform: scale(0.0) }\n  40% { -webkit-transform: scale(1.0) }\n}\n \n@keyframes bouncedelay {\n  0%, 80%, 100% {\n    transform: scale(0.0);\n    -webkit-transform: scale(0.0);\n  } 40% {\n    transform: scale(1.0);\n    -webkit-transform: scale(1.0);\n  }\n}\n\t</style>\n\t\n\t<div id="module-calendarBf-calendarSearch_pad">\n\n    <div class="content" style="background: #ffffff">\n    \t<section id="section_wrap">\n    \t\t<ul class="table-view">\n   \t\t\t\t<li class="table-view-cell" style="background-color:#f2f2f2; border-bottom:none">\n   \t\t\t\t\t<input id="searchText" class="canClear" type="text" placeholder="请输入关键词" style="margin-bottom:0; border:none;" data-focus-title="日程搜索" data-focus-label="搜索内容"><button id="searchBtn" class="btn btn-link" style="font-size:.36rem; font-style: normal; right:.1rem; color:#5baba2">搜索</button>\n   \t\t\t\t</li>\n   \t\t\t</ul>\n    \t</section>\n\t </div>\n   <!--<div class="creatDate_tag"style="line-height:40px;padding:0;top:85px;height:40px;position:absolute; text-align:center;width:100%;border-bottom:1px solid #eee;">\n                <li id="searchPre"class="table-view-cell padding-right11" style="list-style-type:none;line-height:40px;padding-top:0px;padding-bottom:0px;">\n                    <span id="preString"></span>\n                  </li>\n  </div>-->\n  <div id="nav-list-repeat" class="iscroll-list">   \n    <div class="item-content-repeat">\n        <div id="searchList_JRoll" data-click-title="日程搜索" data-click-label="事件详情" data-click-value=""></div>\n     </div>\n  </div>\n  <!--<div class="creatDate_tag" style="position:absolute;bottom:0px;border-top:1px solid #eee;border-bottom:none; text-align:center;width:100%;">\n                <li id="searchBehind"class="table-view-cell padding-right11" style="list-style-type:none;">\n                    <span id="nextString"></span>\n                  </li>\n  </div>-->\n\t</div>\n</div>\n';});

define('module_calendarBf/calendarSearch_pad',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/eventList-template.html',
	'../commonBf/js/EMCSUtil',
	'bsl',
	'../../butterfly/components/store',
	'./js/calendarFunc', './js/moment.min', './js/common'
], function($, View, calendarTpl, eventListTpl, EMCSUtil, bsl, Store, Func, moment, calendarCommon) {
	var me = null;
	var isPad = Store.loadObject("calendarBf_isPad");
	var currentDate = null;
	var Search_scroll;
	var upDate; //保存向上日期
	var downDate; //保存向下日期
	var isEmpty = false;
	var model = View.extend({
		events: {
			"tap #module-calendarBf-calendarSearch_pad #searchBtn,  #module-calendarBf-calendarSearch_pad #preString, #module-calendarBf-calendarSearch_pad #nextString": "search",
			"click #module-calendarBf-calendarSearch_pad .list": "details",
			"input input": "showBtnClear",
			"focus input": "showBtnClear",
			"blur input": "hideBtnClear"
		},
		render: function() {
			Store.saveObject("calendarBf_isFirstEnter", true); // isFirstEnter为真则　首页的　日历事件只会绑定一次。
			Store.saveObject("calendarBf_isFirstEnter_two", true);
			me = this;
		},
		onShow: function() {
			$(window).unbind().bind("PadReSearch", me.PadReSearch);
			Func._addDeleteBtn(25, 67);
			if (isPad) {
				$("#shadow-dialg").on("tap", function(e) {
					$("#calendarSearch_pad #searchText").blur();
					var target = e.target;
					var D = $(target).find("#calendarDetails")[0]; //点击遮罩层时，如果详情页面还在，就不能关闭搜索页面
					if ($(target).attr("id") == "shadow-dialg" && !D) {
						setTimeout(function() {

							me.animateSlideOutDown();
							me.parentView.searchPage = null;
							me.parentView.show();
							setTimeout(function() {
								$(me.el).remove();
								$("#shadow-dialg").css({
									"z-index": "-1"
								});
								$("#shadow-dialg").off();
							}, 200);
							$("#pad-dialog").css("border", "none");
							$(window).trigger("mainReOnshow");
						}, 200);
					}
				});
				Func._addDeleteBtn(25, 67);
				if ($("#calendarSearch_pad #searchText").val() !== '') {
					me.search();
				} else {
					$("#calendarSearch_pad #searchList_JRoll").html('<div class="lists" style="text-align:center;padding:10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
				}
			}
			/*bsl.infinitus.cat.analytics({
                "category": "日程搜索",
                "action": "浏览",
                "label": "",
                "value": ""
            });*/
		},

		detailPage: null,
        companyActivityDetail:null,
		details: function(e) {
			Store.saveObject("calendarBf_padSearchEnter", true);
			var theObj = {};
			var target = e.target;
			while ($(target).attr("class") != "list") target = target.parentNode;
			theObj = {
				date: $(target).data("date"),
				title: $(target).data("title"),
				address: $(target).data("address"),
				startTime: $(target).attr("data-startTime"),
				endTime: $(target).attr("data-endTime"),
				allDay: $(target).attr("data-allDay"),
				remind: $(target).attr("data-remind"),
				repeat: $(target).attr("data-repeat"),
				remarks: $(target).attr("data-remarks"),
				mark: $(target).attr("data-mark"),
				remindMark: $(target).attr("data-remindMark"),
				id: parseInt($(target).attr("data-itemId")),
				thingid: parseInt($(target).attr("data-thingid")),
				thingEndTime: $(target).attr("data-thingEndTime"),
				fromSearch: $(target).attr("data-from-search"),
				groupType:$(target).attr("data-group-type")
			}
			Store.saveObject("calendarBf_show_detail_obj", theObj);
			Store.saveObject("calendarBf_remind_type", $(target).data("remind"));
			Store.saveObject("calendarBf_repeat_type", $(target).data("repeat"));
			Store.saveObject("calendarBf_allDay_type", $(target).attr("data-allDay"));
            var detailPage = me.detailPage;
                url = 'calendarDetails';
            if(theObj.groupType != '99'){//如果不是个人事件
                url = "companyActivityDetail";
                detailPage = me.companyActivityDetail;
            }
			me.showPadDialog(detailPage, url);

		},

		renderTemplate: function() {

			var tpl = $(this.el).find("#nav-scroll").html();
			$(this.el).find(".item-content-repeat").append(tpl);
		},

		openDatabase: function(dbName) {
			var DEFAULT_SIZE = 5000000;
			// return bsl.sqlite.openDatabase(dbName, "1.0", "calendar", DEFAULT_SIZE);
			return bsl.sqlite.openDatabase({name:dbName, location: 'default'});
		},



		search: function() {
			var value_search = $("#searchText").val();
			//$("#calendarSearch #searchBtn").attr("data-click-value",value_search);
			if(value_search!=""){
				bsl.infinitus.cat.analytics({
		            "category": "日程搜索", 
		           	"action": "点击",
					"label":"搜索",
					"value":value_search
		        });
			}
			if ($("#calendarSearch #searchText").val() == '') return;
			var times = 1;
			var canSearch = false; //当执行过loading才可以search
			if (!me.shouDateThing_scroll) {
				//me.Search_scroll = null;
				me.shouDateThing_scroll = new JRoll("#calendarSearch_pad .item-content-repeat", {
					bounce: true
				});

				me.shouDateThing_scroll.on("scroll", function(e) {
					if (this.y >= 50 && isEmpty == false && times == 1) {
						$('#calendarSearch_pad .item-content-repeat').prepend('<div style="position:absolute;top:0px;width:100%" class="uploading"><div style="width:180px;margin:0px auto"><div class="spinner"></div> <span>下拉加载更多事件</span></div></div>');
						canSearch = true;
						times++;
					}
					if (this.y <= this.maxScrollY - 60 && isEmpty == false && times == 1) { //向上拉，往下搜索
						$('#calendarSearch_pad .item-content-repeat').prepend('<div style="position:absolute;bottom:10px;width:100%;z-index:0" class="downloading"><div style="width:180px;margin:0px auto"><div class="spinner"></div> <span>上拉加载更多事件</span></div></div>');
						canSearch = true;
						times++;
					}
				});
				me.shouDateThing_scroll.on("scrollEnd", function(e) {
					if (this.y >= 0 && canSearch) { //向下拉，往上搜索
						me.doSearch('up', upDate, false);
					}

					if (this.y <= this.maxScrollY && canSearch) { //向上拉，往下搜索
						me.doSearch('down', downDate, false);
					}
					times = 1;
					canSearch = false;
					$('#calendarSearch_pad .item-content-repeat .uploading').remove();
					$('#calendarSearch_pad .item-content-repeat .downloading').remove();

				});
			}
			$("#calendarSearch_pad #searchList_JRoll").html("")
			var now = Store.loadObject('calendarBf_currentDateTime') ? Store.loadObject('calendarBf_currentDateTime') : moment().startOf('day').unix();
			Store.saveObject('calendarBf_currentDateTime', '');
            me.shouDateThing_scroll.refresh();
            me.shouDateThing_scroll.scrollTo(0, 0);
			me.doSearch('normal', now, true);
		},

		doSearch: function(direction, dateTime, isFirst) {
			var array = [];
			var search_text = $("#calendarSearch_pad #searchText").val();
			if (!search_text) {
				$("#calendarSearch_pad #searchList_JRoll").html('<div class="lists" style="text-align:center;padding:10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
				return;
			}

			if (isEmpty) {
				$("#calendarSearch_pad #searchList_JRoll").html("");
			}

			var searchConf = {
				key: search_text,
				dateTime: dateTime,
				direction: direction,
				isFirst: isFirst
			};

			calendarCommon.init();
			calendarCommon.pageGetCalendarItemByKeyWord(searchConf, function(res, direction) {
				for (var i = 0; i < res.length; i++) {
					theObj = {
						date: res[i].date,
						title: res[i].title,
						allDay: res[i].allDay,
						address: res[i].address,
						startTime: res[i].startTime,
						endTime: res[i].endTime,
						remind: res[i].remind,
						repeat: res[i].repeat,
						remarks: res[i].remarks,
						// mark 同一条记录的 mark 一致
						mark: res[i].mark,
						remindMark: res[i].remindMark,
						id: res[i].id,
						startTimeHourMin: res[i].startTimeHourMin,
						endTimeHourMin: res[i].endTimeHourMin,
						thingid: res[i].thingid,
						dateTime: moment.unix(res[i].startTime).format('YYYY-MM-DD'),
						thingEndTime: res[i].thingEndTime,
						endDate: moment.unix(res[i].endTime).format('YYYY-MM-DD'),
						fromSearch: 'true',
						groupType: res[i].groupType
					};
					array.push(theObj);
				}
				if (array.length) {
					// 显示到页面中
					me.shouDateThing(array, direction);
					var arrayLastRecord = array[array.length - 1];
					var arrayFristRecord = array[0];
					$("#calendarSearch_pad .creatDate_tag").show();
					downDate = $('#calendarSearch_pad #searchList_JRoll .list').last().attr('data-starttime');
					upDate = $('#calendarSearch_pad #searchList_JRoll .list').first().attr('data-starttime');
					isEmpty = false;
				} else {
					if (direction != 'normal' && direction != 'again') {
						bsl.infinitus.tools.showToast("已加载全部", 2000);
						if (isEmpty) {
							$("#calendarSearch_pad #searchList_JRoll").html('<div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
						}
					} else {
						isEmpty = true;
						$("#calendarSearch_pad #searchList_JRoll").html('<div class="lists" style="text-align:center;padding:10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;color:#9C9C9C;" >无结果</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div><div class="lists" style="text-align:center;padding: 10% 16px;border-bottom:1px solid #eee;" >&nbsp;</div>');
						upDate = downDate = dateTime;
						me.shouDateThing_scroll.refresh();
					}
				}
			}, function(e) {});
		},

		// 查询显示 搜索结果
		shouDateThing: function(theArray, direction) {

			// var arr = [
			//    {title:'2月份员工会议工作讨论', allDay:true, address:'待定'},
			//    {title:'自助终端刷卡支付技术方案讨论会',startTime:'11:00',endTime:'12:00',address:'无限极中心 1906'},
			//    {title:'E帆网分享功能技术研讨会',startTime:'14:00',endTime:'16:00',address:'保利威座 2501A'}
			// ];

			if (direction == 'again' || direction == 'normal') { //防止连续点击搜索没有清空
				$("#calendarSearch_pad #searchList_JRoll").html("");
			}
			var eventList = '';
			_.each(theArray,
				function(elem, index) {
					elem.noDate = false;
					var eventListHtml = _.template(eventListTpl, elem);
					if (direction == 'down' || direction == 'normal')
						eventList = eventList + eventListHtml;
					if (direction == 'up' || direction == 'again')
						eventList = eventListHtml + eventList;
				});
			var html = $("#calendarSearch_pad #searchList_JRoll").html();
			if (direction == 'down' || direction == 'normal') {
				eventList = html + eventList;
				$("#calendarSearch_pad #searchList_JRoll").html(eventList);
			}
			if (direction == 'up' || direction == 'again') {
				eventList = eventList + html;
				$("#calendarSearch_pad #searchList_JRoll").html(eventList);
			}

			if (direction == 'normal')
				me.shouDateThing_scroll.scrollTo(0, 0); // 搜索结果 使其日程回到顶部
			me.shouDateThing_scroll.refresh(); // 刷新scroll
			$('[data-click-title="标题"]').attr("data-click-title","日程搜索");
		},

		// pad中 显示 dialog html为 页面名称，需要在本页面创建一个页面对象传进去。
		showPadDialog: function(pageName, html) {

			if (pageName) {
				pageName.show();
				pageName.$el.css({
					'display': 'block'
				});
				pageName.animateSlideInUp();
			} else {
				require(['view!module_calendarBf/' + html + '.html'], function(ViewClass) {
					pageName = new ViewClass();
					pageName.$el.css({
						'position': 'absolute',
						'top': '0px',
						'bottom': '0px',
						'width': '100%',
						'z-index': 1000
					});
					pageName.parentView = me;
					pageName.render();
					me.el.appendChild(pageName.el);
					pageName.show();
					pageName.animateSlideInRight();
				}, function(err) {
					Toast("操作失败，请重试");
				});
			};
		},
		showBtnClear: function(e) {
			var target = e.target;
			var val = $(target).val();
			if (val != "") {
				$(target).next("span").show();
			} else {
				$(target).next("span").hide();
			};
		},
		hideBtnClear: function(e) {
			var target = e.target;
			$(target).next("span").hide();
		},
		PadReSearch: function() {
			me.search();
		}
	});
	return model;
});

/**
 * 登录回调函数
 */

/*登录回调函数*/
function login(){
	//提示框判断操作
	Butterfly.Store.saveObject("calendarBf_loginState",2);
}
;
define("module_calendarBf/common", function(){});


define('text!module_calendarBf/companyActivityDetail.html',[],function () { return '<div data-view="companyActivityDetail" id="companyActivityDetail" class="views">\n\t<style>\n\t\t#companyActivityDetail .content{\n\t\t\ttop: 44px;\n\t\t}\n\t\t#companyActivityDetail .title_wrapper{\n\t\t\theight: 200px;\n\t\t\tbackground: red;\n\t\t}\n\t\t#companyActivityDetail .title_wrapper p{\n\t\t\tposition: absolute;\n\t\t\tbottom: 0px;\n\t\t\tmargin: 10px;\n\t\t\tcolor: white;\n\t\t\tfont-size: 20px;\n\t\t}\n\t\t#companyActivityDetail .activity_info{\n\t\t\twidth: 100%;\n\t\t\tpadding: 10px;\n\t\t}\n\t\t#companyActivityDetail .activity_info>div{\n\t\t\tborder-bottom: 1px solid RGB(204,204,204);\n\t\t\tpadding: 5px 0 5px 0;\n\t\t}\n\t\t#companyActivityDetail .activity_info .right{\n\t\t\tfloat: right;\n\t\t}\n\t</style>\n\t<div id=\'module-calendarBf-companyActivityDetail\'>\n\t\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t\t<div class="ui3-row-12">\n\t\t\t\t<div class="ui3-col-3 ui3-icon-back back" data-click-label="返回">返回</div>\n\t\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title">事件详情</div>\n\t\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right"></div>\n\t\t\t</div>\n\t\t</header>\n\t\t<div class="content">\n\t\t\t<!--<div class="title_wrapper">\n\t\t\t\t<p style="">业务总监会议</p>\n\t\t\t</div>\n\t\t\t<div class="activity_info">\n\t\t\t\t<div class="activity_address">\n\t\t\t\t\t<span>地点</span>\n\t\t\t\t\t<span class="right">无限极服务中心</span>\n\t\t\t\t</div>\n\t\t\t\t<div class="activity_time">\n\t\t\t\t\t<span>时间</span>\n\t\t\t\t\t<span class="right">9:00-10:00</span>\n\t\t\t\t</div>\n\t\t\t</div>-->\n\t\t</div>\n\n\t</div>\n\t\n</div>';});


define('text!module_calendarBf/template/companyActivityDetail-template.html',[],function () { return '<div class="title_wrapper">\n\t<p style="">\n\t\t<%= result.title %>\n\t</p>\n</div>\n<div class="activity_info">\n\t<div class="activity_address">\n\t\t<span>地点</span>\n\t\t<span class="right"><%= result.address %></span>\n\t</div>\n\t<div class="activity_time">\n\t\t<span>时间</span>\n\t\t<span class="right"><%= result.startTime%></span>\n\t</div>\n</div>';});

define('module_calendarBf/companyActivityDetail',['jquery', 'View',
	'text!./template/companyActivityDetail-template.html',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store',
	'bsl', './js/common', './js/moment.min','init','./api'
], function($, View, cADTpl , EMCSUtil, Store, bsl, CalendarCommon, moment, init,api) {
	
	var me = null;
	
	var model = View.extend({

		events: {
			"click .back":EMCSUtil.goBack
		},
		initialize: function() {
			me = this;
		},
		render: function() {
			// var data = {
			// 	title:'业务总监会议',
			// 	address:'无限极服务中心',
			// 	time:'9:00-10:00'
			// };
			// var mainHtml = cADTpl;
			// var mainFn = _.template(mainHtml);
			// var mainTpl = mainFn({result:data});
			// me.$el.find('.content').html(mainTpl);
		},
		
		onShow: function() {
			var show_obj = Store.loadObject("calendarBf_show_detail_obj");
            console.log(show_obj);
            var startTime = show_obj.startTime;
            if((startTime).indexOf('-') == -1) {
                show_obj.startTime = moment.unix(startTime).format('YYYY-MM-DD');
            }
			var mainFn = _.template(cADTpl);
			var mainTpl = mainFn({result:show_obj});
			me.$el.find('.content').html(mainTpl);
		}
	});
	return model;
});
define('module_calendarBf/config',['../commonBf/js/EMCSUtil'], function(Util) {
	Util.init();
    var host = const_getAppConfig.hostConfig.gateway;
    var url = host + '/activity/';

    var config = {
    	Api: {
        	"getCalendarsList": url + "activity/",
    	}
    };
    return config;
});

define('text!module_calendarBf/index.html',[],function () { return '<!DOCTYPE html>\n<html lang="zh-CN">\n\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width,initial-scale=1, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />\n    <meta name="apple-mobile-web-app-capable" content="yes">\n    <meta http-equiv="pragma" content="no-cache" />\n    <title>日程管理</title>\n    <script type="text/javascript" src="../../../cordova/cordova.js"></script>\n   \n    <!-- 预加载（比如“听云”），使用 cordova 时，需要在 cordova.js 后加载 -->\n    <script id="preload-js" type="text/javascript" src="../commonBf/js/preload.js"></script>\n\n    <link href="../../butterfly/vendor/ratchet/dist/css/ratchet.min.css" rel="stylesheet" />\n    <link href="../commonBf/css/ui3.css" rel="stylesheet"/>\n    <link href="../commonBf/css/common.css" rel="stylesheet" />\n    <link href="../../butterfly/css/main.css" rel="stylesheet" />\n    <link href="css/calendarCommon.css" rel="stylesheet" />\n    <link rel="stylesheet" type="text/css" media="(max-width:500px)" href="css/calendarIndexPhone.css" />\n    <link rel="stylesheet" type="text/css" media="(min-width:501px)" href="css/calendarIndexPad.css" />\n    <!-- <link href="../butterfly/css/component.css" rel="stylesheet" /> -->\n    <script src="../../butterfly/vendor/requirejs/require.js" data-main="../../butterfly/js/butterfly-amd"></script>\n\n    <style type="text/css">\n    /*日程管理不需要网络*/\n    #ui3_network_fail {\n        display: none!important;\n    }\n    \n          body{color: #313030;}\n         .rachicons{\n            font-family: "Ratchicons" !important;\n        }\n        .bar-tab {\n          bottom: 0px;\n          display: table;\n          width: 100%;\n          height: 50px;\n          padding: 0;\n          position: absolute;\n          border-top: 1px solid #ddd;\n          border-bottom: 0;\n        }\n    </style>\n    <style type="text/css">\n  .cube-loader {\n    width: 1100%;\n    height: 1100%;\n    left: -400%;\n    top: -400%;\n    background-color: rgba(0,0,0,.4);\n    position: fixed;\n    z-index: 9999999999999;\n    vertical-align: middle;\n    text-align: center\n}\n.cube-loader-block {\n    min-width: 85px;\n    border-radius: 15px;\n    background: rgba(0,0,0,.8);\n    margin-left: -42.5px;\n    margin-top: -35px;\n    padding: 20px 5px 5px 5px;\n    text-align: center;\n    font-weight: bolder;\n    color: #b9b9b9;\n    position: fixed;\n    left: 50%;\n    top: 40%\n}\n\n.cube-loader-icon {\n    width: 40px;\n    height: 40px;\n    margin: 0px auto 15px auto;\n    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABGCAYAAABxLuKEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAD/mlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjajZTPbxRlGMc/u/POrAk4B1MBi8GJP4CQQrZgkAZBd7vLtlDLZtti25iY7ezb3bHT2fGd2fIjPXHRG6h/gIocPJh4MsFfES7AQQMJQUNsSEw4lPgjRBIuhtTDTHcHaMX39Mzzfp/v9/s875OBzOdV33fTFsx6oaqU8tb4xKSVuUGaZ1hDN2uqduDnyuUhgKrvuzxy7v1MCuDa9pXv//OsqcnAhtQTQLMW2LOQOga6a/sqBOMWsOdo6IeQeRboUuMTk5DJAl31KC4AXVNRPA50qdFKP2RcwLQb1Rpk5oGeqUS+nogjDwB0laQnlWNblVLeKqvmtOPKhN3HXP/PM+u2lvU2AWuDmZFDwFZIHWuogUocf2JXiyPAi5C67If5CrAZUn+0ZsZywDZIPzWtDoxF+PSrJxqjbwLrIF1zwsHROH/Cmxo+HNWmz8w0D1VizGU76J8Enof0zYYcHIr8aNRkoQj0gLap0RqI+bWDwdxIcZnnRKN/OOLR1DvVg2WgG7T3VbNyOPKsnZFuqRLxaxf9sBx70BY9d3go4hSmDIojy/mwMToQ1YrdoRqNa8XktHNgMMbP+255KPImzqpWZSzGXK2qYiniEX9Lbyzm1DfUqoVDwA7Q93MkVUXSZAqJjcd9LCqUyGPho2gyjYNLCYmHROGknmQGZxVcGYmK4w6ijsRjEYWDvQomUrgdY5pivciKXSIr9oohsU/sEX1Y4jXxutgvCiIr+sTedm05oW9R53ab511aSCwqHCF/uru1taN3Ur3t2FdO3XmguvmIZ7nsJzkBAmbayO3J/i/Nf7ehw3FdnHvr2tpL8xx+3Hz1W/qifl2/pd/QFzoI/Vd9QV/Qb5DDxaWOZBaJg4ckSDhI9nABl5AqLr/h0UzgHlCc9k53d27sK6fuyPeG7w1zsqeTzf6S/TN7Pftp9mz294emvOKUtI+0r7Tvta+1b7QfsbTz2gXtB+2i9qX2beKtVt+P9tuTS3Qr8VactcQ18+ZG8wWzYD5nvmQOdfjM9WavOWBuMQvmxva7JfWSvThM4LanurJWhBvDw+EoEkVAFReP4w/tf1wtNoleMfjQ1u4Re0XbpVE0CkYOy9hm9Bm9xkEj1/FnbDEKRp+xxSg+sHX2Kh3IBCrZ53amkATMoHCYQ+ISIEN5LATob/rHlVNvhNbObPYVK+f7rrQGPXtHj1V1XUs59UYYWEoGUs3J2g7GJyat6Bd9t0IKSK270smFb8C+v0C72slNtuCLANa/3Mlt7YanP4Zzu+2Wmov/+anUTxBM79oZfa3Ng35zaenuZsh8CPc/WFr658zS0v3PQFuA8+6/WQBxeLnbzNAAAAAgY0hSTQAAbZgAAHOOAADyewAAhNoAAG6UAADlGgAAMycAABkXmUkcfwAAAx5JREFUeNrsXL1y2zAMBnAefdc+gle/getdjPeumZslW7pm8pwti3ev3WVxd/sGXvMI7Z1nooty5z85IgVClENsyYnK5y8APuLnjMwM2c6NMgWZGC8b9fnHrbXGOXeHiHMAmNa/3jHzlog2RVFUfWHDPnJMWZYTRHxExAcAGDc8tmfmFTO/LhaLt5snpizLCREtAeC+5ZG1c+5Zmxz1HIOIjx6kAADc12du12OstYaZf10JnybbI+J3zZyj6jHOubsAUgAAxvXZtFUpVE3q50NDcK6pbl6h1FVNqqr6CwBfArn5Z4z5qqVu5EMKES0R8emDcBgj4hMRLcuynMRWt1h4yMOVJdRk14GLnaa6UducUrurb154sNaa95+ZeRvKyuFZKTydiZFSEyLaAMA+4D37+qyaulFLpkXUpCiKiplXAd6yOlSWWOoWkmOmHXLD9ORDvgLA2uP8uj4TBU8yJcFisXhzzj0z88sHYbVn5pc+6iSfC94OAGYSavJODgD8tNZW1y5mxphKA08wMcy8RcQgINeUqM4bVcg7Y+DxDiUpNREr8BTwtCJGSk2kTAMPebxUQk3ELDYe1SIyRr0UC09Qoyq1JnbvbYfPZHmuFHKPSXnuEzvELobSEOY+sZPyGTFDmftcI0UCP10oywcx97nSVhDBf+QxQ5r7NOUUKfxHHjOkuc8lk8RPId2tBheeJxBGYvgppLvVYNMEUowY/nzBa3nzFZv79GRi+OmklBeZ+/RlkviPiEmtU+ft/oL4j4hJrVPna5L46cJDSXXqAj6kCP5cRLYtInPboQUx+R6T7cxG2i6aWsiIhFIenzSASKmzFxuP9g6eZIshKp5WHpNaZ08Dj+oOnpRp4Bm1dNukNro1Oo1t5Vq0s3eoJoh4+p+fIeKMmX9sNpsmNbm9HbzUNsy7EpPaRnf0TmMrYlLb6NboNKru4KW2Yd6ZmNQ2um9xBy+1DfPuxKS20R0bj+oOXlVVvyF8o/uPMeabVtshqB+T2kZ3KJ5kLnhDmlupEjOkuZV6STCUuVX+0ouUiImpJjdBTMqW50qZGD/7PwBwG8hOW44PKQAAAABJRU5ErkJggg==);\n    background-size: 100%;\n    -webkit-animation: animate-cloud 1.0s linear infinite;\n    -moz-animation: animate-cloud 1.0s linear infinite;\n    -ms-animation: animate-cloud 1.0s linear infinite;\n    -o-animation: animate-cloud 1.0s linear infinite;\n    animation: animate-cloud 1.0s linear infinite\n}\n\n@-webkit-keyframes animate-cloud {\n    from {\n        -webkit-transform: rotate(0deg) translateZ(0)\n    }\n    to {\n        -webkit-transform: rotate(360deg) translateZ(0)\n    }\n}\n\n@-moz-keyframes animate-cloud {\n    from {\n        -webkit-transform: rotate(0deg) translateZ(0)\n    }\n    to {\n        -webkit-transform: rotate(360deg) translateZ(0)\n    }\n}\n\n@-ms-keyframes animate-cloud {\n    from {\n        -webkit-transform: rotate(0deg) translateZ(0)\n    }\n    to {\n        -webkit-transform: rotate(360deg) translateZ(0)\n    }\n}\n\n@-o-keyframes animate-cloud {\n    from {\n        -webkit-transform: rotate(0deg) translateZ(0)\n    }\n    to {\n        -webkit-transform: rotate(360deg) translateZ(0)\n    }\n}\n\n  </style>\n    <script type="text/javascript">\n    var touchNotification = function(Param) {\n    \tif(typeof(Param) == "object"){\n    \t\tParam = Param\n    \t}else{\n    \t\tParam = JSON.parse(Param);\n    \t};\n    \tlocalStorage.setItem("calendarBf_noticeId", Param.ID);\n        window.location.reload();\n    }\n    // 设为 true 将调用原生 SQLite，设为 false 将调用 Web SQL Database\n    var isInApp = true;\n    </script>\n</head>\n\n<body>\n    <div id="index" data-view="$StackView" data-defaults="main" onselectstart="return false" unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">\n    </div>\n    <!-- pad 中的 dialog -->\n    <div id="shadow-dialg" style="position:absolute; top:0; bottom:0; width:100%;z-index:-1; background:rgba(0,0,0,0.6); display:none;">\n        <div id="pad-dialog" style="height:575px; width:380px; position:absolute;-moz-user-select:none;-webkit-user-select:none;overflow: hidden;" onselectstart="return false" unselectable="on">\n        </div>\n    </div>\n</body>\n</html>';});

define('module_calendarBf/index',['View', 'spin', 'commonObj'], function(View, Spin, CommonObj) {

    return View.extend({
        events: {},
        render: function() {
        },
        onShow: function() {
        }
    });
});

/**
 * Swiper 3.2.5
 * Most modern mobile touch slider and framework with hardware accelerated transitions
 * 
 * http://www.idangero.us/swiper/
 * 
 * Copyright 2015, Vladimir Kharlampidi
 * The iDangero.us
 * http://www.idangero.us/
 * 
 * Licensed under MIT
 * 
 * Released on: November 21, 2015
 */
!function(){"use strict";function e(e){e.fn.swiper=function(a){var r;return e(this).each(function(){var e=new t(this,a);r||(r=e)}),r}}var a,t=function(e,s){function i(){return"horizontal"===T.params.direction}function n(e){return Math.floor(e)}function o(){T.autoplayTimeoutId=setTimeout(function(){T.params.loop?(T.fixLoop(),T._slideNext()):T.isEnd?s.autoplayStopOnLast?T.stopAutoplay():T._slideTo(0):T._slideNext()},T.params.autoplay)}function l(e,t){var r=a(e.target);if(!r.is(t))if("string"==typeof t)r=r.parents(t);else if(t.nodeType){var s;return r.parents().each(function(e,a){a===t&&(s=t)}),s?t:void 0}if(0!==r.length)return r[0]}function d(e,a){a=a||{};var t=window.MutationObserver||window.WebkitMutationObserver,r=new t(function(e){e.forEach(function(e){T.onResize(!0),T.emit("onObserverUpdate",T,e)})});r.observe(e,{attributes:"undefined"==typeof a.attributes?!0:a.attributes,childList:"undefined"==typeof a.childList?!0:a.childList,characterData:"undefined"==typeof a.characterData?!0:a.characterData}),T.observers.push(r)}function p(e){e.originalEvent&&(e=e.originalEvent);var a=e.keyCode||e.charCode;if(!T.params.allowSwipeToNext&&(i()&&39===a||!i()&&40===a))return!1;if(!T.params.allowSwipeToPrev&&(i()&&37===a||!i()&&38===a))return!1;if(!(e.shiftKey||e.altKey||e.ctrlKey||e.metaKey||document.activeElement&&document.activeElement.nodeName&&("input"===document.activeElement.nodeName.toLowerCase()||"textarea"===document.activeElement.nodeName.toLowerCase()))){if(37===a||39===a||38===a||40===a){var t=!1;if(T.container.parents(".swiper-slide").length>0&&0===T.container.parents(".swiper-slide-active").length)return;var r={left:window.pageXOffset,top:window.pageYOffset},s=window.innerWidth,n=window.innerHeight,o=T.container.offset();T.rtl&&(o.left=o.left-T.container[0].scrollLeft);for(var l=[[o.left,o.top],[o.left+T.width,o.top],[o.left,o.top+T.height],[o.left+T.width,o.top+T.height]],d=0;d<l.length;d++){var p=l[d];p[0]>=r.left&&p[0]<=r.left+s&&p[1]>=r.top&&p[1]<=r.top+n&&(t=!0)}if(!t)return}i()?((37===a||39===a)&&(e.preventDefault?e.preventDefault():e.returnValue=!1),(39===a&&!T.rtl||37===a&&T.rtl)&&T.slideNext(),(37===a&&!T.rtl||39===a&&T.rtl)&&T.slidePrev()):((38===a||40===a)&&(e.preventDefault?e.preventDefault():e.returnValue=!1),40===a&&T.slideNext(),38===a&&T.slidePrev())}}function u(e){e.originalEvent&&(e=e.originalEvent);var a=T.mousewheel.event,t=0;if(e.detail)t=-e.detail;else if("mousewheel"===a)if(T.params.mousewheelForceToAxis)if(i()){if(!(Math.abs(e.wheelDeltaX)>Math.abs(e.wheelDeltaY)))return;t=e.wheelDeltaX}else{if(!(Math.abs(e.wheelDeltaY)>Math.abs(e.wheelDeltaX)))return;t=e.wheelDeltaY}else t=e.wheelDelta;else if("DOMMouseScroll"===a)t=-e.detail;else if("wheel"===a)if(T.params.mousewheelForceToAxis)if(i()){if(!(Math.abs(e.deltaX)>Math.abs(e.deltaY)))return;t=-e.deltaX}else{if(!(Math.abs(e.deltaY)>Math.abs(e.deltaX)))return;t=-e.deltaY}else t=Math.abs(e.deltaX)>Math.abs(e.deltaY)?-e.deltaX:-e.deltaY;if(0!==t){if(T.params.mousewheelInvert&&(t=-t),T.params.freeMode){var r=T.getWrapperTranslate()+t*T.params.mousewheelSensitivity,s=T.isBeginning,n=T.isEnd;if(r>=T.minTranslate()&&(r=T.minTranslate()),r<=T.maxTranslate()&&(r=T.maxTranslate()),T.setWrapperTransition(0),T.setWrapperTranslate(r),T.updateProgress(),T.updateActiveIndex(),(!s&&T.isBeginning||!n&&T.isEnd)&&T.updateClasses(),T.params.freeModeSticky&&(clearTimeout(T.mousewheel.timeout),T.mousewheel.timeout=setTimeout(function(){T.slideReset()},300)),0===r||r===T.maxTranslate())return}else{if((new window.Date).getTime()-T.mousewheel.lastScrollTime>60)if(0>t)if(T.isEnd&&!T.params.loop||T.animating){if(T.params.mousewheelReleaseOnEdges)return!0}else T.slideNext();else if(T.isBeginning&&!T.params.loop||T.animating){if(T.params.mousewheelReleaseOnEdges)return!0}else T.slidePrev();T.mousewheel.lastScrollTime=(new window.Date).getTime()}return T.params.autoplay&&T.stopAutoplay(),e.preventDefault?e.preventDefault():e.returnValue=!1,!1}}function c(e,t){e=a(e);var r,s,n;r=e.attr("data-swiper-parallax")||"0",s=e.attr("data-swiper-parallax-x"),n=e.attr("data-swiper-parallax-y"),s||n?(s=s||"0",n=n||"0"):i()?(s=r,n="0"):(n=r,s="0"),s=s.indexOf("%")>=0?parseInt(s,10)*t+"%":s*t+"px",n=n.indexOf("%")>=0?parseInt(n,10)*t+"%":n*t+"px",e.transform("translate3d("+s+", "+n+",0px)")}function m(e){return 0!==e.indexOf("on")&&(e=e[0]!==e[0].toUpperCase()?"on"+e[0].toUpperCase()+e.substring(1):"on"+e),e}if(!(this instanceof t))return new t(e,s);var f={direction:"horizontal",touchEventsTarget:"container",initialSlide:0,speed:300,autoplay:!1,autoplayDisableOnInteraction:!0,iOSEdgeSwipeDetection:!1,iOSEdgeSwipeThreshold:20,freeMode:!1,freeModeMomentum:!0,freeModeMomentumRatio:1,freeModeMomentumBounce:!0,freeModeMomentumBounceRatio:1,freeModeSticky:!1,freeModeMinimumVelocity:.02,autoHeight:!1,setWrapperSize:!1,virtualTranslate:!1,effect:"slide",coverflow:{rotate:50,stretch:0,depth:100,modifier:1,slideShadows:!0},cube:{slideShadows:!0,shadow:!0,shadowOffset:20,shadowScale:.94},fade:{crossFade:!1},parallax:!1,scrollbar:null,scrollbarHide:!0,scrollbarDraggable:!1,scrollbarSnapOnRelease:!1,keyboardControl:!1,mousewheelControl:!1,mousewheelReleaseOnEdges:!1,mousewheelInvert:!1,mousewheelForceToAxis:!1,mousewheelSensitivity:1,hashnav:!1,breakpoints:void 0,spaceBetween:0,slidesPerView:1,slidesPerColumn:1,slidesPerColumnFill:"column",slidesPerGroup:1,centeredSlides:!1,slidesOffsetBefore:0,slidesOffsetAfter:0,roundLengths:!1,touchRatio:1,touchAngle:45,simulateTouch:!0,shortSwipes:!0,longSwipes:!0,longSwipesRatio:.5,longSwipesMs:300,followFinger:!0,onlyExternal:!1,threshold:0,touchMoveStopPropagation:!0,pagination:null,paginationElement:"span",paginationClickable:!1,paginationHide:!1,paginationBulletRender:null,resistance:!0,resistanceRatio:.85,nextButton:null,prevButton:null,watchSlidesProgress:!1,watchSlidesVisibility:!1,grabCursor:!1,preventClicks:!0,preventClicksPropagation:!0,slideToClickedSlide:!1,lazyLoading:!1,lazyLoadingInPrevNext:!1,lazyLoadingOnTransitionStart:!1,preloadImages:!0,updateOnImagesReady:!0,loop:!1,loopAdditionalSlides:0,loopedSlides:null,control:void 0,controlInverse:!1,controlBy:"slide",allowSwipeToPrev:!0,allowSwipeToNext:!0,swipeHandler:null,noSwiping:!0,noSwipingClass:"swiper-no-swiping",slideClass:"swiper-slide",slideActiveClass:"swiper-slide-active",slideVisibleClass:"swiper-slide-visible",slideDuplicateClass:"swiper-slide-duplicate",slideNextClass:"swiper-slide-next",slidePrevClass:"swiper-slide-prev",wrapperClass:"swiper-wrapper",bulletClass:"swiper-pagination-bullet",bulletActiveClass:"swiper-pagination-bullet-active",buttonDisabledClass:"swiper-button-disabled",paginationHiddenClass:"swiper-pagination-hidden",observer:!1,observeParents:!1,a11y:!1,prevSlideMessage:"Previous slide",nextSlideMessage:"Next slide",firstSlideMessage:"This is the first slide",lastSlideMessage:"This is the last slide",paginationBulletMessage:"Go to slide {{index}}",runCallbacksOnInit:!0},h=s&&s.virtualTranslate;s=s||{};var g={};for(var v in s)if("object"==typeof s[v]){g[v]={};for(var w in s[v])g[v][w]=s[v][w]}else g[v]=s[v];for(var y in f)if("undefined"==typeof s[y])s[y]=f[y];else if("object"==typeof s[y])for(var b in f[y])"undefined"==typeof s[y][b]&&(s[y][b]=f[y][b]);var T=this;if(T.params=s,T.originalParams=g,T.classNames=[],"undefined"!=typeof a&&"undefined"!=typeof r&&(a=r),("undefined"!=typeof a||(a="undefined"==typeof r?window.Dom7||window.Zepto||window.jQuery:r))&&(T.$=a,T.currentBreakpoint=void 0,T.getActiveBreakpoint=function(){if(!T.params.breakpoints)return!1;var e,a=!1,t=[];for(e in T.params.breakpoints)T.params.breakpoints.hasOwnProperty(e)&&t.push(e);t.sort(function(e,a){return parseInt(e,10)>parseInt(a,10)});for(var r=0;r<t.length;r++)e=t[r],e>=window.innerWidth&&!a&&(a=e);return a||"max"},T.setBreakpoint=function(){var e=T.getActiveBreakpoint();if(e&&T.currentBreakpoint!==e){var a=e in T.params.breakpoints?T.params.breakpoints[e]:T.originalParams;for(var t in a)T.params[t]=a[t];T.currentBreakpoint=e}},T.params.breakpoints&&T.setBreakpoint(),T.container=a(e),0!==T.container.length)){if(T.container.length>1)return void T.container.each(function(){new t(this,s)});T.container[0].swiper=T,T.container.data("swiper",T),T.classNames.push("swiper-container-"+T.params.direction),T.params.freeMode&&T.classNames.push("swiper-container-free-mode"),T.support.flexbox||(T.classNames.push("swiper-container-no-flexbox"),T.params.slidesPerColumn=1),T.params.autoHeight&&T.classNames.push("swiper-container-autoheight"),(T.params.parallax||T.params.watchSlidesVisibility)&&(T.params.watchSlidesProgress=!0),["cube","coverflow"].indexOf(T.params.effect)>=0&&(T.support.transforms3d?(T.params.watchSlidesProgress=!0,T.classNames.push("swiper-container-3d")):T.params.effect="slide"),"slide"!==T.params.effect&&T.classNames.push("swiper-container-"+T.params.effect),"cube"===T.params.effect&&(T.params.resistanceRatio=0,T.params.slidesPerView=1,T.params.slidesPerColumn=1,T.params.slidesPerGroup=1,T.params.centeredSlides=!1,T.params.spaceBetween=0,T.params.virtualTranslate=!0,T.params.setWrapperSize=!1),"fade"===T.params.effect&&(T.params.slidesPerView=1,T.params.slidesPerColumn=1,T.params.slidesPerGroup=1,T.params.watchSlidesProgress=!0,T.params.spaceBetween=0,"undefined"==typeof h&&(T.params.virtualTranslate=!0)),T.params.grabCursor&&T.support.touch&&(T.params.grabCursor=!1),T.wrapper=T.container.children("."+T.params.wrapperClass),T.params.pagination&&(T.paginationContainer=a(T.params.pagination),T.params.paginationClickable&&T.paginationContainer.addClass("swiper-pagination-clickable")),T.rtl=i()&&("rtl"===T.container[0].dir.toLowerCase()||"rtl"===T.container.css("direction")),T.rtl&&T.classNames.push("swiper-container-rtl"),T.rtl&&(T.wrongRTL="-webkit-box"===T.wrapper.css("display")),T.params.slidesPerColumn>1&&T.classNames.push("swiper-container-multirow"),T.device.android&&T.classNames.push("swiper-container-android"),T.container.addClass(T.classNames.join(" ")),T.translate=0,T.progress=0,T.velocity=0,T.lockSwipeToNext=function(){T.params.allowSwipeToNext=!1},T.lockSwipeToPrev=function(){T.params.allowSwipeToPrev=!1},T.lockSwipes=function(){T.params.allowSwipeToNext=T.params.allowSwipeToPrev=!1},T.unlockSwipeToNext=function(){T.params.allowSwipeToNext=!0},T.unlockSwipeToPrev=function(){T.params.allowSwipeToPrev=!0},T.unlockSwipes=function(){T.params.allowSwipeToNext=T.params.allowSwipeToPrev=!0},T.params.grabCursor&&(T.container[0].style.cursor="move",T.container[0].style.cursor="-webkit-grab",T.container[0].style.cursor="-moz-grab",T.container[0].style.cursor="grab"),T.imagesToLoad=[],T.imagesLoaded=0,T.loadImage=function(e,a,t,r,s){function i(){s&&s()}var n;e.complete&&r?i():a?(n=new window.Image,n.onload=i,n.onerror=i,t&&(n.srcset=t),a&&(n.src=a)):i()},T.preloadImages=function(){function e(){"undefined"!=typeof T&&null!==T&&(void 0!==T.imagesLoaded&&T.imagesLoaded++,T.imagesLoaded===T.imagesToLoad.length&&(T.params.updateOnImagesReady&&T.update(),T.emit("onImagesReady",T)))}T.imagesToLoad=T.container.find("img");for(var a=0;a<T.imagesToLoad.length;a++)T.loadImage(T.imagesToLoad[a],T.imagesToLoad[a].currentSrc||T.imagesToLoad[a].getAttribute("src"),T.imagesToLoad[a].srcset||T.imagesToLoad[a].getAttribute("srcset"),!0,e)},T.autoplayTimeoutId=void 0,T.autoplaying=!1,T.autoplayPaused=!1,T.startAutoplay=function(){return"undefined"!=typeof T.autoplayTimeoutId?!1:T.params.autoplay?T.autoplaying?!1:(T.autoplaying=!0,T.emit("onAutoplayStart",T),void o()):!1},T.stopAutoplay=function(e){T.autoplayTimeoutId&&(T.autoplayTimeoutId&&clearTimeout(T.autoplayTimeoutId),T.autoplaying=!1,T.autoplayTimeoutId=void 0,T.emit("onAutoplayStop",T))},T.pauseAutoplay=function(e){T.autoplayPaused||(T.autoplayTimeoutId&&clearTimeout(T.autoplayTimeoutId),T.autoplayPaused=!0,0===e?(T.autoplayPaused=!1,o()):T.wrapper.transitionEnd(function(){T&&(T.autoplayPaused=!1,T.autoplaying?o():T.stopAutoplay())}))},T.minTranslate=function(){return-T.snapGrid[0]},T.maxTranslate=function(){return-T.snapGrid[T.snapGrid.length-1]},T.updateAutoHeight=function(){var e=T.slides.eq(T.activeIndex)[0].offsetHeight;e&&T.wrapper.css("height",T.slides.eq(T.activeIndex)[0].offsetHeight+"px")},T.updateContainerSize=function(){var e,a;e="undefined"!=typeof T.params.width?T.params.width:T.container[0].clientWidth,a="undefined"!=typeof T.params.height?T.params.height:T.container[0].clientHeight,0===e&&i()||0===a&&!i()||(e=e-parseInt(T.container.css("padding-left"),10)-parseInt(T.container.css("padding-right"),10),a=a-parseInt(T.container.css("padding-top"),10)-parseInt(T.container.css("padding-bottom"),10),T.width=e,T.height=a,T.size=i()?T.width:T.height)},T.updateSlidesSize=function(){T.slides=T.wrapper.children("."+T.params.slideClass),T.snapGrid=[],T.slidesGrid=[],T.slidesSizesGrid=[];var e,a=T.params.spaceBetween,t=-T.params.slidesOffsetBefore,r=0,s=0;"string"==typeof a&&a.indexOf("%")>=0&&(a=parseFloat(a.replace("%",""))/100*T.size),T.virtualSize=-a,T.rtl?T.slides.css({marginLeft:"",marginTop:""}):T.slides.css({marginRight:"",marginBottom:""});var o;T.params.slidesPerColumn>1&&(o=Math.floor(T.slides.length/T.params.slidesPerColumn)===T.slides.length/T.params.slidesPerColumn?T.slides.length:Math.ceil(T.slides.length/T.params.slidesPerColumn)*T.params.slidesPerColumn,"auto"!==T.params.slidesPerView&&"row"===T.params.slidesPerColumnFill&&(o=Math.max(o,T.params.slidesPerView*T.params.slidesPerColumn)));var l,d=T.params.slidesPerColumn,p=o/d,u=p-(T.params.slidesPerColumn*p-T.slides.length);for(e=0;e<T.slides.length;e++){l=0;var c=T.slides.eq(e);if(T.params.slidesPerColumn>1){var m,f,h;"column"===T.params.slidesPerColumnFill?(f=Math.floor(e/d),h=e-f*d,(f>u||f===u&&h===d-1)&&++h>=d&&(h=0,f++),m=f+h*o/d,c.css({"-webkit-box-ordinal-group":m,"-moz-box-ordinal-group":m,"-ms-flex-order":m,"-webkit-order":m,order:m})):(h=Math.floor(e/p),f=e-h*p),c.css({"margin-top":0!==h&&T.params.spaceBetween&&T.params.spaceBetween+"px"}).attr("data-swiper-column",f).attr("data-swiper-row",h)}"none"!==c.css("display")&&("auto"===T.params.slidesPerView?(l=i()?c.outerWidth(!0):c.outerHeight(!0),T.params.roundLengths&&(l=n(l))):(l=(T.size-(T.params.slidesPerView-1)*a)/T.params.slidesPerView,T.params.roundLengths&&(l=n(l)),i()?T.slides[e].style.width=l+"px":T.slides[e].style.height=l+"px"),T.slides[e].swiperSlideSize=l,T.slidesSizesGrid.push(l),T.params.centeredSlides?(t=t+l/2+r/2+a,0===e&&(t=t-T.size/2-a),Math.abs(t)<.001&&(t=0),s%T.params.slidesPerGroup===0&&T.snapGrid.push(t),T.slidesGrid.push(t)):(s%T.params.slidesPerGroup===0&&T.snapGrid.push(t),T.slidesGrid.push(t),t=t+l+a),T.virtualSize+=l+a,r=l,s++)}T.virtualSize=Math.max(T.virtualSize,T.size)+T.params.slidesOffsetAfter;var g;if(T.rtl&&T.wrongRTL&&("slide"===T.params.effect||"coverflow"===T.params.effect)&&T.wrapper.css({width:T.virtualSize+T.params.spaceBetween+"px"}),(!T.support.flexbox||T.params.setWrapperSize)&&(i()?T.wrapper.css({width:T.virtualSize+T.params.spaceBetween+"px"}):T.wrapper.css({height:T.virtualSize+T.params.spaceBetween+"px"})),T.params.slidesPerColumn>1&&(T.virtualSize=(l+T.params.spaceBetween)*o,T.virtualSize=Math.ceil(T.virtualSize/T.params.slidesPerColumn)-T.params.spaceBetween,T.wrapper.css({width:T.virtualSize+T.params.spaceBetween+"px"}),T.params.centeredSlides)){for(g=[],e=0;e<T.snapGrid.length;e++)T.snapGrid[e]<T.virtualSize+T.snapGrid[0]&&g.push(T.snapGrid[e]);T.snapGrid=g}if(!T.params.centeredSlides){for(g=[],e=0;e<T.snapGrid.length;e++)T.snapGrid[e]<=T.virtualSize-T.size&&g.push(T.snapGrid[e]);T.snapGrid=g,Math.floor(T.virtualSize-T.size)>Math.floor(T.snapGrid[T.snapGrid.length-1])&&T.snapGrid.push(T.virtualSize-T.size)}0===T.snapGrid.length&&(T.snapGrid=[0]),0!==T.params.spaceBetween&&(i()?T.rtl?T.slides.css({marginLeft:a+"px"}):T.slides.css({marginRight:a+"px"}):T.slides.css({marginBottom:a+"px"})),T.params.watchSlidesProgress&&T.updateSlidesOffset()},T.updateSlidesOffset=function(){for(var e=0;e<T.slides.length;e++)T.slides[e].swiperSlideOffset=i()?T.slides[e].offsetLeft:T.slides[e].offsetTop},T.updateSlidesProgress=function(e){if("undefined"==typeof e&&(e=T.translate||0),0!==T.slides.length){"undefined"==typeof T.slides[0].swiperSlideOffset&&T.updateSlidesOffset();var a=-e;T.rtl&&(a=e),T.slides.removeClass(T.params.slideVisibleClass);for(var t=0;t<T.slides.length;t++){var r=T.slides[t],s=(a-r.swiperSlideOffset)/(r.swiperSlideSize+T.params.spaceBetween);if(T.params.watchSlidesVisibility){var i=-(a-r.swiperSlideOffset),n=i+T.slidesSizesGrid[t],o=i>=0&&i<T.size||n>0&&n<=T.size||0>=i&&n>=T.size;o&&T.slides.eq(t).addClass(T.params.slideVisibleClass)}r.progress=T.rtl?-s:s}}},T.updateProgress=function(e){"undefined"==typeof e&&(e=T.translate||0);var a=T.maxTranslate()-T.minTranslate(),t=T.isBeginning,r=T.isEnd;0===a?(T.progress=0,T.isBeginning=T.isEnd=!0):(T.progress=(e-T.minTranslate())/a,T.isBeginning=T.progress<=0,T.isEnd=T.progress>=1),T.isBeginning&&!t&&T.emit("onReachBeginning",T),T.isEnd&&!r&&T.emit("onReachEnd",T),T.params.watchSlidesProgress&&T.updateSlidesProgress(e),T.emit("onProgress",T,T.progress)},T.updateActiveIndex=function(){var e,a,t,r=T.rtl?T.translate:-T.translate;for(a=0;a<T.slidesGrid.length;a++)"undefined"!=typeof T.slidesGrid[a+1]?r>=T.slidesGrid[a]&&r<T.slidesGrid[a+1]-(T.slidesGrid[a+1]-T.slidesGrid[a])/2?e=a:r>=T.slidesGrid[a]&&r<T.slidesGrid[a+1]&&(e=a+1):r>=T.slidesGrid[a]&&(e=a);(0>e||"undefined"==typeof e)&&(e=0),t=Math.floor(e/T.params.slidesPerGroup),t>=T.snapGrid.length&&(t=T.snapGrid.length-1),e!==T.activeIndex&&(T.snapIndex=t,T.previousIndex=T.activeIndex,T.activeIndex=e,T.updateClasses())},T.updateClasses=function(){T.slides.removeClass(T.params.slideActiveClass+" "+T.params.slideNextClass+" "+T.params.slidePrevClass);var e=T.slides.eq(T.activeIndex);if(e.addClass(T.params.slideActiveClass),e.next("."+T.params.slideClass).addClass(T.params.slideNextClass),e.prev("."+T.params.slideClass).addClass(T.params.slidePrevClass),T.bullets&&T.bullets.length>0){T.bullets.removeClass(T.params.bulletActiveClass);var t;T.params.loop?(t=Math.ceil(T.activeIndex-T.loopedSlides)/T.params.slidesPerGroup,t>T.slides.length-1-2*T.loopedSlides&&(t-=T.slides.length-2*T.loopedSlides),t>T.bullets.length-1&&(t-=T.bullets.length)):t="undefined"!=typeof T.snapIndex?T.snapIndex:T.activeIndex||0,T.paginationContainer.length>1?T.bullets.each(function(){a(this).index()===t&&a(this).addClass(T.params.bulletActiveClass)}):T.bullets.eq(t).addClass(T.params.bulletActiveClass)}T.params.loop||(T.params.prevButton&&(T.isBeginning?(a(T.params.prevButton).addClass(T.params.buttonDisabledClass),T.params.a11y&&T.a11y&&T.a11y.disable(a(T.params.prevButton))):(a(T.params.prevButton).removeClass(T.params.buttonDisabledClass),T.params.a11y&&T.a11y&&T.a11y.enable(a(T.params.prevButton)))),T.params.nextButton&&(T.isEnd?(a(T.params.nextButton).addClass(T.params.buttonDisabledClass),T.params.a11y&&T.a11y&&T.a11y.disable(a(T.params.nextButton))):(a(T.params.nextButton).removeClass(T.params.buttonDisabledClass),T.params.a11y&&T.a11y&&T.a11y.enable(a(T.params.nextButton)))))},T.updatePagination=function(){if(T.params.pagination&&T.paginationContainer&&T.paginationContainer.length>0){for(var e="",a=T.params.loop?Math.ceil((T.slides.length-2*T.loopedSlides)/T.params.slidesPerGroup):T.snapGrid.length,t=0;a>t;t++)e+=T.params.paginationBulletRender?T.params.paginationBulletRender(t,T.params.bulletClass):"<"+T.params.paginationElement+' class="'+T.params.bulletClass+'"></'+T.params.paginationElement+">";T.paginationContainer.html(e),T.bullets=T.paginationContainer.find("."+T.params.bulletClass),T.params.paginationClickable&&T.params.a11y&&T.a11y&&T.a11y.initPagination()}},T.update=function(e){function a(){r=Math.min(Math.max(T.translate,T.maxTranslate()),T.minTranslate()),T.setWrapperTranslate(r),T.updateActiveIndex(),T.updateClasses()}if(T.updateContainerSize(),T.updateSlidesSize(),T.updateProgress(),T.updatePagination(),T.updateClasses(),T.params.scrollbar&&T.scrollbar&&T.scrollbar.set(),e){var t,r;T.controller&&T.controller.spline&&(T.controller.spline=void 0),T.params.freeMode?(a(),T.params.autoHeight&&T.updateAutoHeight()):(t=("auto"===T.params.slidesPerView||T.params.slidesPerView>1)&&T.isEnd&&!T.params.centeredSlides?T.slideTo(T.slides.length-1,0,!1,!0):T.slideTo(T.activeIndex,0,!1,!0),t||a())}else T.params.autoHeight&&T.updateAutoHeight()},T.onResize=function(e){T.params.breakpoints&&T.setBreakpoint();var a=T.params.allowSwipeToPrev,t=T.params.allowSwipeToNext;if(T.params.allowSwipeToPrev=T.params.allowSwipeToNext=!0,T.updateContainerSize(),T.updateSlidesSize(),("auto"===T.params.slidesPerView||T.params.freeMode||e)&&T.updatePagination(),T.params.scrollbar&&T.scrollbar&&T.scrollbar.set(),T.controller&&T.controller.spline&&(T.controller.spline=void 0),T.params.freeMode){var r=Math.min(Math.max(T.translate,T.maxTranslate()),T.minTranslate());T.setWrapperTranslate(r),T.updateActiveIndex(),T.updateClasses(),T.params.autoHeight&&T.updateAutoHeight()}else T.updateClasses(),("auto"===T.params.slidesPerView||T.params.slidesPerView>1)&&T.isEnd&&!T.params.centeredSlides?T.slideTo(T.slides.length-1,0,!1,!0):T.slideTo(T.activeIndex,0,!1,!0);T.params.allowSwipeToPrev=a,T.params.allowSwipeToNext=t};var x=["mousedown","mousemove","mouseup"];window.navigator.pointerEnabled?x=["pointerdown","pointermove","pointerup"]:window.navigator.msPointerEnabled&&(x=["MSPointerDown","MSPointerMove","MSPointerUp"]),T.touchEvents={start:T.support.touch||!T.params.simulateTouch?"touchstart":x[0],move:T.support.touch||!T.params.simulateTouch?"touchmove":x[1],end:T.support.touch||!T.params.simulateTouch?"touchend":x[2]},(window.navigator.pointerEnabled||window.navigator.msPointerEnabled)&&("container"===T.params.touchEventsTarget?T.container:T.wrapper).addClass("swiper-wp8-"+T.params.direction),T.initEvents=function(e){var t=e?"off":"on",r=e?"removeEventListener":"addEventListener",i="container"===T.params.touchEventsTarget?T.container[0]:T.wrapper[0],n=T.support.touch?i:document,o=T.params.nested?!0:!1;T.browser.ie?(i[r](T.touchEvents.start,T.onTouchStart,!1),n[r](T.touchEvents.move,T.onTouchMove,o),n[r](T.touchEvents.end,T.onTouchEnd,!1)):(T.support.touch&&(i[r](T.touchEvents.start,T.onTouchStart,!1),i[r](T.touchEvents.move,T.onTouchMove,o),i[r](T.touchEvents.end,T.onTouchEnd,!1)),!s.simulateTouch||T.device.ios||T.device.android||(i[r]("mousedown",T.onTouchStart,!1),document[r]("mousemove",T.onTouchMove,o),document[r]("mouseup",T.onTouchEnd,!1))),window[r]("resize",T.onResize),T.params.nextButton&&(a(T.params.nextButton)[t]("click",T.onClickNext),T.params.a11y&&T.a11y&&a(T.params.nextButton)[t]("keydown",T.a11y.onEnterKey)),T.params.prevButton&&(a(T.params.prevButton)[t]("click",T.onClickPrev),T.params.a11y&&T.a11y&&a(T.params.prevButton)[t]("keydown",T.a11y.onEnterKey)),T.params.pagination&&T.params.paginationClickable&&(a(T.paginationContainer)[t]("click","."+T.params.bulletClass,T.onClickIndex),T.params.a11y&&T.a11y&&a(T.paginationContainer)[t]("keydown","."+T.params.bulletClass,T.a11y.onEnterKey)),(T.params.preventClicks||T.params.preventClicksPropagation)&&i[r]("click",T.preventClicks,!0)},T.attachEvents=function(e){T.initEvents()},T.detachEvents=function(){T.initEvents(!0)},T.allowClick=!0,T.preventClicks=function(e){T.allowClick||(T.params.preventClicks&&e.preventDefault(),T.params.preventClicksPropagation&&T.animating&&(e.stopPropagation(),e.stopImmediatePropagation()))},T.onClickNext=function(e){e.preventDefault(),(!T.isEnd||T.params.loop)&&T.slideNext()},T.onClickPrev=function(e){e.preventDefault(),(!T.isBeginning||T.params.loop)&&T.slidePrev()},T.onClickIndex=function(e){e.preventDefault();var t=a(this).index()*T.params.slidesPerGroup;T.params.loop&&(t+=T.loopedSlides),T.slideTo(t)},T.updateClickedSlide=function(e){var t=l(e,"."+T.params.slideClass),r=!1;if(t)for(var s=0;s<T.slides.length;s++)T.slides[s]===t&&(r=!0);if(!t||!r)return T.clickedSlide=void 0,void(T.clickedIndex=void 0);if(T.clickedSlide=t,T.clickedIndex=a(t).index(),T.params.slideToClickedSlide&&void 0!==T.clickedIndex&&T.clickedIndex!==T.activeIndex){var i,n=T.clickedIndex;if(T.params.loop){if(T.animating)return;i=a(T.clickedSlide).attr("data-swiper-slide-index"),T.params.centeredSlides?n<T.loopedSlides-T.params.slidesPerView/2||n>T.slides.length-T.loopedSlides+T.params.slidesPerView/2?(T.fixLoop(),n=T.wrapper.children("."+T.params.slideClass+'[data-swiper-slide-index="'+i+'"]:not(.swiper-slide-duplicate)').eq(0).index(),setTimeout(function(){T.slideTo(n)},0)):T.slideTo(n):n>T.slides.length-T.params.slidesPerView?(T.fixLoop(),n=T.wrapper.children("."+T.params.slideClass+'[data-swiper-slide-index="'+i+'"]:not(.swiper-slide-duplicate)').eq(0).index(),setTimeout(function(){T.slideTo(n)},0)):T.slideTo(n)}else T.slideTo(n)}};var S,C,M,E,P,k,z,I,L,D,B="input, select, textarea, button",G=Date.now(),A=[];T.animating=!1,T.touches={startX:0,startY:0,currentX:0,currentY:0,diff:0};var O,N;if(T.onTouchStart=function(e){if(e.originalEvent&&(e=e.originalEvent),O="touchstart"===e.type,O||!("which"in e)||3!==e.which){if(T.params.noSwiping&&l(e,"."+T.params.noSwipingClass))return void(T.allowClick=!0);if(!T.params.swipeHandler||l(e,T.params.swipeHandler)){var t=T.touches.currentX="touchstart"===e.type?e.targetTouches[0].pageX:e.pageX,r=T.touches.currentY="touchstart"===e.type?e.targetTouches[0].pageY:e.pageY;if(!(T.device.ios&&T.params.iOSEdgeSwipeDetection&&t<=T.params.iOSEdgeSwipeThreshold)){if(S=!0,C=!1,M=!0,P=void 0,N=void 0,T.touches.startX=t,T.touches.startY=r,E=Date.now(),T.allowClick=!0,T.updateContainerSize(),T.swipeDirection=void 0,T.params.threshold>0&&(I=!1),"touchstart"!==e.type){var s=!0;a(e.target).is(B)&&(s=!1),document.activeElement&&a(document.activeElement).is(B)&&document.activeElement.blur(),s&&e.preventDefault()}T.emit("onTouchStart",T,e)}}}},T.onTouchMove=function(e){if(e.originalEvent&&(e=e.originalEvent),!(O&&"mousemove"===e.type||e.preventedByNestedSwiper)){if(T.params.onlyExternal)return T.allowClick=!1,void(S&&(T.touches.startX=T.touches.currentX="touchmove"===e.type?e.targetTouches[0].pageX:e.pageX,T.touches.startY=T.touches.currentY="touchmove"===e.type?e.targetTouches[0].pageY:e.pageY,E=Date.now()));if(O&&document.activeElement&&e.target===document.activeElement&&a(e.target).is(B))return C=!0,void(T.allowClick=!1);if(M&&T.emit("onTouchMove",T,e),!(e.targetTouches&&e.targetTouches.length>1)){if(T.touches.currentX="touchmove"===e.type?e.targetTouches[0].pageX:e.pageX,T.touches.currentY="touchmove"===e.type?e.targetTouches[0].pageY:e.pageY,"undefined"==typeof P){var t=180*Math.atan2(Math.abs(T.touches.currentY-T.touches.startY),Math.abs(T.touches.currentX-T.touches.startX))/Math.PI;P=i()?t>T.params.touchAngle:90-t>T.params.touchAngle}if(P&&T.emit("onTouchMoveOpposite",T,e),"undefined"==typeof N&&T.browser.ieTouch&&(T.touches.currentX!==T.touches.startX||T.touches.currentY!==T.touches.startY)&&(N=!0),S){if(P)return void(S=!1);if(N||!T.browser.ieTouch){T.allowClick=!1,T.emit("onSliderMove",T,e),e.preventDefault(),T.params.touchMoveStopPropagation&&!T.params.nested&&e.stopPropagation(),C||(s.loop&&T.fixLoop(),z=T.getWrapperTranslate(),T.setWrapperTransition(0),T.animating&&T.wrapper.trigger("webkitTransitionEnd transitionend oTransitionEnd MSTransitionEnd msTransitionEnd"),T.params.autoplay&&T.autoplaying&&(T.params.autoplayDisableOnInteraction?T.stopAutoplay():T.pauseAutoplay()),D=!1,T.params.grabCursor&&(T.container[0].style.cursor="move",T.container[0].style.cursor="-webkit-grabbing",T.container[0].style.cursor="-moz-grabbin",T.container[0].style.cursor="grabbing")),C=!0;var r=T.touches.diff=i()?T.touches.currentX-T.touches.startX:T.touches.currentY-T.touches.startY;r*=T.params.touchRatio,T.rtl&&(r=-r),T.swipeDirection=r>0?"prev":"next",k=r+z;var n=!0;if(r>0&&k>T.minTranslate()?(n=!1,T.params.resistance&&(k=T.minTranslate()-1+Math.pow(-T.minTranslate()+z+r,T.params.resistanceRatio))):0>r&&k<T.maxTranslate()&&(n=!1,T.params.resistance&&(k=T.maxTranslate()+1-Math.pow(T.maxTranslate()-z-r,T.params.resistanceRatio))),n&&(e.preventedByNestedSwiper=!0),!T.params.allowSwipeToNext&&"next"===T.swipeDirection&&z>k&&(k=z),!T.params.allowSwipeToPrev&&"prev"===T.swipeDirection&&k>z&&(k=z),T.params.followFinger){if(T.params.threshold>0){if(!(Math.abs(r)>T.params.threshold||I))return void(k=z);if(!I)return I=!0,T.touches.startX=T.touches.currentX,T.touches.startY=T.touches.currentY,k=z,void(T.touches.diff=i()?T.touches.currentX-T.touches.startX:T.touches.currentY-T.touches.startY)}(T.params.freeMode||T.params.watchSlidesProgress)&&T.updateActiveIndex(),T.params.freeMode&&(0===A.length&&A.push({position:T.touches[i()?"startX":"startY"],time:E}),A.push({position:T.touches[i()?"currentX":"currentY"],time:(new window.Date).getTime()})),T.updateProgress(k),T.setWrapperTranslate(k)}}}}}},T.onTouchEnd=function(e){if(e.originalEvent&&(e=e.originalEvent),M&&T.emit("onTouchEnd",T,e),M=!1,S){T.params.grabCursor&&C&&S&&(T.container[0].style.cursor="move",T.container[0].style.cursor="-webkit-grab",T.container[0].style.cursor="-moz-grab",T.container[0].style.cursor="grab");var t=Date.now(),r=t-E;if(T.allowClick&&(T.updateClickedSlide(e),T.emit("onTap",T,e),300>r&&t-G>300&&(L&&clearTimeout(L),L=setTimeout(function(){T&&(T.params.paginationHide&&T.paginationContainer.length>0&&!a(e.target).hasClass(T.params.bulletClass)&&T.paginationContainer.toggleClass(T.params.paginationHiddenClass),T.emit("onClick",T,e))},300)),300>r&&300>t-G&&(L&&clearTimeout(L),T.emit("onDoubleTap",T,e))),G=Date.now(),setTimeout(function(){T&&(T.allowClick=!0)},0),!S||!C||!T.swipeDirection||0===T.touches.diff||k===z)return void(S=C=!1);S=C=!1;var s;if(s=T.params.followFinger?T.rtl?T.translate:-T.translate:-k,T.params.freeMode){if(s<-T.minTranslate())return void T.slideTo(T.activeIndex);if(s>-T.maxTranslate())return void(T.slides.length<T.snapGrid.length?T.slideTo(T.snapGrid.length-1):T.slideTo(T.slides.length-1));if(T.params.freeModeMomentum){if(A.length>1){var i=A.pop(),n=A.pop(),o=i.position-n.position,l=i.time-n.time;T.velocity=o/l,T.velocity=T.velocity/2,Math.abs(T.velocity)<T.params.freeModeMinimumVelocity&&(T.velocity=0),(l>150||(new window.Date).getTime()-i.time>300)&&(T.velocity=0)}else T.velocity=0;A.length=0;var d=1e3*T.params.freeModeMomentumRatio,p=T.velocity*d,u=T.translate+p;T.rtl&&(u=-u);var c,m=!1,f=20*Math.abs(T.velocity)*T.params.freeModeMomentumBounceRatio;if(u<T.maxTranslate())T.params.freeModeMomentumBounce?(u+T.maxTranslate()<-f&&(u=T.maxTranslate()-f),c=T.maxTranslate(),m=!0,D=!0):u=T.maxTranslate();else if(u>T.minTranslate())T.params.freeModeMomentumBounce?(u-T.minTranslate()>f&&(u=T.minTranslate()+f),c=T.minTranslate(),m=!0,D=!0):u=T.minTranslate();else if(T.params.freeModeSticky){var h,g=0;for(g=0;g<T.snapGrid.length;g+=1)if(T.snapGrid[g]>-u){h=g;break}u=Math.abs(T.snapGrid[h]-u)<Math.abs(T.snapGrid[h-1]-u)||"next"===T.swipeDirection?T.snapGrid[h]:T.snapGrid[h-1],T.rtl||(u=-u)}if(0!==T.velocity)d=T.rtl?Math.abs((-u-T.translate)/T.velocity):Math.abs((u-T.translate)/T.velocity);else if(T.params.freeModeSticky)return void T.slideReset();T.params.freeModeMomentumBounce&&m?(T.updateProgress(c),T.setWrapperTransition(d),T.setWrapperTranslate(u),T.onTransitionStart(),T.animating=!0,T.wrapper.transitionEnd(function(){T&&D&&(T.emit("onMomentumBounce",T),T.setWrapperTransition(T.params.speed),T.setWrapperTranslate(c),T.wrapper.transitionEnd(function(){T&&T.onTransitionEnd()}))})):T.velocity?(T.updateProgress(u),T.setWrapperTransition(d),T.setWrapperTranslate(u),T.onTransitionStart(),T.animating||(T.animating=!0,T.wrapper.transitionEnd(function(){T&&T.onTransitionEnd()}))):T.updateProgress(u),T.updateActiveIndex()}return void((!T.params.freeModeMomentum||r>=T.params.longSwipesMs)&&(T.updateProgress(),T.updateActiveIndex()))}var v,w=0,y=T.slidesSizesGrid[0];for(v=0;v<T.slidesGrid.length;v+=T.params.slidesPerGroup)"undefined"!=typeof T.slidesGrid[v+T.params.slidesPerGroup]?s>=T.slidesGrid[v]&&s<T.slidesGrid[v+T.params.slidesPerGroup]&&(w=v,y=T.slidesGrid[v+T.params.slidesPerGroup]-T.slidesGrid[v]):s>=T.slidesGrid[v]&&(w=v,
y=T.slidesGrid[T.slidesGrid.length-1]-T.slidesGrid[T.slidesGrid.length-2]);var b=(s-T.slidesGrid[w])/y;if(r>T.params.longSwipesMs){if(!T.params.longSwipes)return void T.slideTo(T.activeIndex);"next"===T.swipeDirection&&(b>=T.params.longSwipesRatio?T.slideTo(w+T.params.slidesPerGroup):T.slideTo(w)),"prev"===T.swipeDirection&&(b>1-T.params.longSwipesRatio?T.slideTo(w+T.params.slidesPerGroup):T.slideTo(w))}else{if(!T.params.shortSwipes)return void T.slideTo(T.activeIndex);"next"===T.swipeDirection&&T.slideTo(w+T.params.slidesPerGroup),"prev"===T.swipeDirection&&T.slideTo(w)}}},T._slideTo=function(e,a){return T.slideTo(e,a,!0,!0)},T.slideTo=function(e,a,t,r){"undefined"==typeof t&&(t=!0),"undefined"==typeof e&&(e=0),0>e&&(e=0),T.snapIndex=Math.floor(e/T.params.slidesPerGroup),T.snapIndex>=T.snapGrid.length&&(T.snapIndex=T.snapGrid.length-1);var s=-T.snapGrid[T.snapIndex];T.params.autoplay&&T.autoplaying&&(r||!T.params.autoplayDisableOnInteraction?T.pauseAutoplay(a):T.stopAutoplay()),T.updateProgress(s);for(var i=0;i<T.slidesGrid.length;i++)-Math.floor(100*s)>=Math.floor(100*T.slidesGrid[i])&&(e=i);return!T.params.allowSwipeToNext&&s<T.translate&&s<T.minTranslate()?!1:!T.params.allowSwipeToPrev&&s>T.translate&&s>T.maxTranslate()&&(T.activeIndex||0)!==e?!1:("undefined"==typeof a&&(a=T.params.speed),T.previousIndex=T.activeIndex||0,T.activeIndex=e,T.params.autoHeight&&T.updateAutoHeight(),s===T.translate?(T.updateClasses(),"slide"!==T.params.effect&&T.setWrapperTranslate(s),!1):(T.updateClasses(),T.onTransitionStart(t),0===a?(T.setWrapperTransition(0),T.setWrapperTranslate(s),T.onTransitionEnd(t)):(T.setWrapperTransition(a),T.setWrapperTranslate(s),T.animating||(T.animating=!0,T.wrapper.transitionEnd(function(){T&&T.onTransitionEnd(t)}))),!0))},T.onTransitionStart=function(e){"undefined"==typeof e&&(e=!0),T.lazy&&T.lazy.onTransitionStart(),e&&(T.emit("onTransitionStart",T),T.activeIndex!==T.previousIndex&&(T.emit("onSlideChangeStart",T),T.activeIndex>T.previousIndex?T.emit("onSlideNextStart",T):T.emit("onSlidePrevStart",T)))},T.onTransitionEnd=function(e){T.animating=!1,T.setWrapperTransition(0),"undefined"==typeof e&&(e=!0),T.lazy&&T.lazy.onTransitionEnd(),e&&(T.emit("onTransitionEnd",T),T.activeIndex!==T.previousIndex&&(T.emit("onSlideChangeEnd",T),T.activeIndex>T.previousIndex?T.emit("onSlideNextEnd",T):T.emit("onSlidePrevEnd",T))),T.params.hashnav&&T.hashnav&&T.hashnav.setHash()},T.slideNext=function(e,a,t){if(T.params.loop){if(T.animating)return!1;T.fixLoop();T.container[0].clientLeft;return T.slideTo(T.activeIndex+T.params.slidesPerGroup,a,e,t)}return T.slideTo(T.activeIndex+T.params.slidesPerGroup,a,e,t)},T._slideNext=function(e){return T.slideNext(!0,e,!0)},T.slidePrev=function(e,a,t){if(T.params.loop){if(T.animating)return!1;T.fixLoop();T.container[0].clientLeft;return T.slideTo(T.activeIndex-1,a,e,t)}return T.slideTo(T.activeIndex-1,a,e,t)},T._slidePrev=function(e){return T.slidePrev(!0,e,!0)},T.slideReset=function(e,a,t){return T.slideTo(T.activeIndex,a,e)},T.setWrapperTransition=function(e,a){T.wrapper.transition(e),"slide"!==T.params.effect&&T.effects[T.params.effect]&&T.effects[T.params.effect].setTransition(e),T.params.parallax&&T.parallax&&T.parallax.setTransition(e),T.params.scrollbar&&T.scrollbar&&T.scrollbar.setTransition(e),T.params.control&&T.controller&&T.controller.setTransition(e,a),T.emit("onSetTransition",T,e)},T.setWrapperTranslate=function(e,a,t){var r=0,s=0,o=0;i()?r=T.rtl?-e:e:s=e,T.params.roundLengths&&(r=n(r),s=n(s)),T.params.virtualTranslate||(T.support.transforms3d?T.wrapper.transform("translate3d("+r+"px, "+s+"px, "+o+"px)"):T.wrapper.transform("translate("+r+"px, "+s+"px)")),T.translate=i()?r:s;var l,d=T.maxTranslate()-T.minTranslate();l=0===d?0:(e-T.minTranslate())/d,l!==T.progress&&T.updateProgress(e),a&&T.updateActiveIndex(),"slide"!==T.params.effect&&T.effects[T.params.effect]&&T.effects[T.params.effect].setTranslate(T.translate),T.params.parallax&&T.parallax&&T.parallax.setTranslate(T.translate),T.params.scrollbar&&T.scrollbar&&T.scrollbar.setTranslate(T.translate),T.params.control&&T.controller&&T.controller.setTranslate(T.translate,t),T.emit("onSetTranslate",T,T.translate)},T.getTranslate=function(e,a){var t,r,s,i;return"undefined"==typeof a&&(a="x"),T.params.virtualTranslate?T.rtl?-T.translate:T.translate:(s=window.getComputedStyle(e,null),window.WebKitCSSMatrix?(r=s.transform||s.webkitTransform,r.split(",").length>6&&(r=r.split(", ").map(function(e){return e.replace(",",".")}).join(", ")),i=new window.WebKitCSSMatrix("none"===r?"":r)):(i=s.MozTransform||s.OTransform||s.MsTransform||s.msTransform||s.transform||s.getPropertyValue("transform").replace("translate(","matrix(1, 0, 0, 1,"),t=i.toString().split(",")),"x"===a&&(r=window.WebKitCSSMatrix?i.m41:16===t.length?parseFloat(t[12]):parseFloat(t[4])),"y"===a&&(r=window.WebKitCSSMatrix?i.m42:16===t.length?parseFloat(t[13]):parseFloat(t[5])),T.rtl&&r&&(r=-r),r||0)},T.getWrapperTranslate=function(e){return"undefined"==typeof e&&(e=i()?"x":"y"),T.getTranslate(T.wrapper[0],e)},T.observers=[],T.initObservers=function(){if(T.params.observeParents)for(var e=T.container.parents(),a=0;a<e.length;a++)d(e[a]);d(T.container[0],{childList:!1}),d(T.wrapper[0],{attributes:!1})},T.disconnectObservers=function(){for(var e=0;e<T.observers.length;e++)T.observers[e].disconnect();T.observers=[]},T.createLoop=function(){T.wrapper.children("."+T.params.slideClass+"."+T.params.slideDuplicateClass).remove();var e=T.wrapper.children("."+T.params.slideClass);"auto"!==T.params.slidesPerView||T.params.loopedSlides||(T.params.loopedSlides=e.length),T.loopedSlides=parseInt(T.params.loopedSlides||T.params.slidesPerView,10),T.loopedSlides=T.loopedSlides+T.params.loopAdditionalSlides,T.loopedSlides>e.length&&(T.loopedSlides=e.length);var t,r=[],s=[];for(e.each(function(t,i){var n=a(this);t<T.loopedSlides&&s.push(i),t<e.length&&t>=e.length-T.loopedSlides&&r.push(i),n.attr("data-swiper-slide-index",t)}),t=0;t<s.length;t++)T.wrapper.append(a(s[t].cloneNode(!0)).addClass(T.params.slideDuplicateClass));for(t=r.length-1;t>=0;t--)T.wrapper.prepend(a(r[t].cloneNode(!0)).addClass(T.params.slideDuplicateClass))},T.destroyLoop=function(){T.wrapper.children("."+T.params.slideClass+"."+T.params.slideDuplicateClass).remove(),T.slides.removeAttr("data-swiper-slide-index")},T.fixLoop=function(){var e;T.activeIndex<T.loopedSlides?(e=T.slides.length-3*T.loopedSlides+T.activeIndex,e+=T.loopedSlides,T.slideTo(e,0,!1,!0)):("auto"===T.params.slidesPerView&&T.activeIndex>=2*T.loopedSlides||T.activeIndex>T.slides.length-2*T.params.slidesPerView)&&(e=-T.slides.length+T.activeIndex+T.loopedSlides,e+=T.loopedSlides,T.slideTo(e,0,!1,!0))},T.appendSlide=function(e){if(T.params.loop&&T.destroyLoop(),"object"==typeof e&&e.length)for(var a=0;a<e.length;a++)e[a]&&T.wrapper.append(e[a]);else T.wrapper.append(e);T.params.loop&&T.createLoop(),T.params.observer&&T.support.observer||T.update(!0)},T.prependSlide=function(e){T.params.loop&&T.destroyLoop();var a=T.activeIndex+1;if("object"==typeof e&&e.length){for(var t=0;t<e.length;t++)e[t]&&T.wrapper.prepend(e[t]);a=T.activeIndex+e.length}else T.wrapper.prepend(e);T.params.loop&&T.createLoop(),T.params.observer&&T.support.observer||T.update(!0),T.slideTo(a,0,!1)},T.removeSlide=function(e){T.params.loop&&(T.destroyLoop(),T.slides=T.wrapper.children("."+T.params.slideClass));var a,t=T.activeIndex;if("object"==typeof e&&e.length){for(var r=0;r<e.length;r++)a=e[r],T.slides[a]&&T.slides.eq(a).remove(),t>a&&t--;t=Math.max(t,0)}else a=e,T.slides[a]&&T.slides.eq(a).remove(),t>a&&t--,t=Math.max(t,0);T.params.loop&&T.createLoop(),T.params.observer&&T.support.observer||T.update(!0),T.params.loop?T.slideTo(t+T.loopedSlides,0,!1):T.slideTo(t,0,!1)},T.removeAllSlides=function(){for(var e=[],a=0;a<T.slides.length;a++)e.push(a);T.removeSlide(e)},T.effects={fade:{setTranslate:function(){for(var e=0;e<T.slides.length;e++){var a=T.slides.eq(e),t=a[0].swiperSlideOffset,r=-t;T.params.virtualTranslate||(r-=T.translate);var s=0;i()||(s=r,r=0);var n=T.params.fade.crossFade?Math.max(1-Math.abs(a[0].progress),0):1+Math.min(Math.max(a[0].progress,-1),0);a.css({opacity:n}).transform("translate3d("+r+"px, "+s+"px, 0px)")}},setTransition:function(e){if(T.slides.transition(e),T.params.virtualTranslate&&0!==e){var a=!1;T.slides.transitionEnd(function(){if(!a&&T){a=!0,T.animating=!1;for(var e=["webkitTransitionEnd","transitionend","oTransitionEnd","MSTransitionEnd","msTransitionEnd"],t=0;t<e.length;t++)T.wrapper.trigger(e[t])}})}}},cube:{setTranslate:function(){var e,t=0;T.params.cube.shadow&&(i()?(e=T.wrapper.find(".swiper-cube-shadow"),0===e.length&&(e=a('<div class="swiper-cube-shadow"></div>'),T.wrapper.append(e)),e.css({height:T.width+"px"})):(e=T.container.find(".swiper-cube-shadow"),0===e.length&&(e=a('<div class="swiper-cube-shadow"></div>'),T.container.append(e))));for(var r=0;r<T.slides.length;r++){var s=T.slides.eq(r),n=90*r,o=Math.floor(n/360);T.rtl&&(n=-n,o=Math.floor(-n/360));var l=Math.max(Math.min(s[0].progress,1),-1),d=0,p=0,u=0;r%4===0?(d=4*-o*T.size,u=0):(r-1)%4===0?(d=0,u=4*-o*T.size):(r-2)%4===0?(d=T.size+4*o*T.size,u=T.size):(r-3)%4===0&&(d=-T.size,u=3*T.size+4*T.size*o),T.rtl&&(d=-d),i()||(p=d,d=0);var c="rotateX("+(i()?0:-n)+"deg) rotateY("+(i()?n:0)+"deg) translate3d("+d+"px, "+p+"px, "+u+"px)";if(1>=l&&l>-1&&(t=90*r+90*l,T.rtl&&(t=90*-r-90*l)),s.transform(c),T.params.cube.slideShadows){var m=i()?s.find(".swiper-slide-shadow-left"):s.find(".swiper-slide-shadow-top"),f=i()?s.find(".swiper-slide-shadow-right"):s.find(".swiper-slide-shadow-bottom");0===m.length&&(m=a('<div class="swiper-slide-shadow-'+(i()?"left":"top")+'"></div>'),s.append(m)),0===f.length&&(f=a('<div class="swiper-slide-shadow-'+(i()?"right":"bottom")+'"></div>'),s.append(f));s[0].progress;m.length&&(m[0].style.opacity=-s[0].progress),f.length&&(f[0].style.opacity=s[0].progress)}}if(T.wrapper.css({"-webkit-transform-origin":"50% 50% -"+T.size/2+"px","-moz-transform-origin":"50% 50% -"+T.size/2+"px","-ms-transform-origin":"50% 50% -"+T.size/2+"px","transform-origin":"50% 50% -"+T.size/2+"px"}),T.params.cube.shadow)if(i())e.transform("translate3d(0px, "+(T.width/2+T.params.cube.shadowOffset)+"px, "+-T.width/2+"px) rotateX(90deg) rotateZ(0deg) scale("+T.params.cube.shadowScale+")");else{var h=Math.abs(t)-90*Math.floor(Math.abs(t)/90),g=1.5-(Math.sin(2*h*Math.PI/360)/2+Math.cos(2*h*Math.PI/360)/2),v=T.params.cube.shadowScale,w=T.params.cube.shadowScale/g,y=T.params.cube.shadowOffset;e.transform("scale3d("+v+", 1, "+w+") translate3d(0px, "+(T.height/2+y)+"px, "+-T.height/2/w+"px) rotateX(-90deg)")}var b=T.isSafari||T.isUiWebView?-T.size/2:0;T.wrapper.transform("translate3d(0px,0,"+b+"px) rotateX("+(i()?0:t)+"deg) rotateY("+(i()?-t:0)+"deg)")},setTransition:function(e){T.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e),T.params.cube.shadow&&!i()&&T.container.find(".swiper-cube-shadow").transition(e)}},coverflow:{setTranslate:function(){for(var e=T.translate,t=i()?-e+T.width/2:-e+T.height/2,r=i()?T.params.coverflow.rotate:-T.params.coverflow.rotate,s=T.params.coverflow.depth,n=0,o=T.slides.length;o>n;n++){var l=T.slides.eq(n),d=T.slidesSizesGrid[n],p=l[0].swiperSlideOffset,u=(t-p-d/2)/d*T.params.coverflow.modifier,c=i()?r*u:0,m=i()?0:r*u,f=-s*Math.abs(u),h=i()?0:T.params.coverflow.stretch*u,g=i()?T.params.coverflow.stretch*u:0;Math.abs(g)<.001&&(g=0),Math.abs(h)<.001&&(h=0),Math.abs(f)<.001&&(f=0),Math.abs(c)<.001&&(c=0),Math.abs(m)<.001&&(m=0);var v="translate3d("+g+"px,"+h+"px,"+f+"px)  rotateX("+m+"deg) rotateY("+c+"deg)";if(l.transform(v),l[0].style.zIndex=-Math.abs(Math.round(u))+1,T.params.coverflow.slideShadows){var w=i()?l.find(".swiper-slide-shadow-left"):l.find(".swiper-slide-shadow-top"),y=i()?l.find(".swiper-slide-shadow-right"):l.find(".swiper-slide-shadow-bottom");0===w.length&&(w=a('<div class="swiper-slide-shadow-'+(i()?"left":"top")+'"></div>'),l.append(w)),0===y.length&&(y=a('<div class="swiper-slide-shadow-'+(i()?"right":"bottom")+'"></div>'),l.append(y)),w.length&&(w[0].style.opacity=u>0?u:0),y.length&&(y[0].style.opacity=-u>0?-u:0)}}if(T.browser.ie){var b=T.wrapper[0].style;b.perspectiveOrigin=t+"px 50%"}},setTransition:function(e){T.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e)}}},T.lazy={initialImageLoaded:!1,loadImageInSlide:function(e,t){if("undefined"!=typeof e&&("undefined"==typeof t&&(t=!0),0!==T.slides.length)){var r=T.slides.eq(e),s=r.find(".swiper-lazy:not(.swiper-lazy-loaded):not(.swiper-lazy-loading)");!r.hasClass("swiper-lazy")||r.hasClass("swiper-lazy-loaded")||r.hasClass("swiper-lazy-loading")||(s=s.add(r[0])),0!==s.length&&s.each(function(){var e=a(this);e.addClass("swiper-lazy-loading");var s=e.attr("data-background"),i=e.attr("data-src"),n=e.attr("data-srcset");T.loadImage(e[0],i||s,n,!1,function(){if(s?(e.css("background-image","url("+s+")"),e.removeAttr("data-background")):(n&&(e.attr("srcset",n),e.removeAttr("data-srcset")),i&&(e.attr("src",i),e.removeAttr("data-src"))),e.addClass("swiper-lazy-loaded").removeClass("swiper-lazy-loading"),r.find(".swiper-lazy-preloader, .preloader").remove(),T.params.loop&&t){var a=r.attr("data-swiper-slide-index");if(r.hasClass(T.params.slideDuplicateClass)){var o=T.wrapper.children('[data-swiper-slide-index="'+a+'"]:not(.'+T.params.slideDuplicateClass+")");T.lazy.loadImageInSlide(o.index(),!1)}else{var l=T.wrapper.children("."+T.params.slideDuplicateClass+'[data-swiper-slide-index="'+a+'"]');T.lazy.loadImageInSlide(l.index(),!1)}}T.emit("onLazyImageReady",T,r[0],e[0])}),T.emit("onLazyImageLoad",T,r[0],e[0])})}},load:function(){var e;if(T.params.watchSlidesVisibility)T.wrapper.children("."+T.params.slideVisibleClass).each(function(){T.lazy.loadImageInSlide(a(this).index())});else if(T.params.slidesPerView>1)for(e=T.activeIndex;e<T.activeIndex+T.params.slidesPerView;e++)T.slides[e]&&T.lazy.loadImageInSlide(e);else T.lazy.loadImageInSlide(T.activeIndex);if(T.params.lazyLoadingInPrevNext)if(T.params.slidesPerView>1){for(e=T.activeIndex+T.params.slidesPerView;e<T.activeIndex+T.params.slidesPerView+T.params.slidesPerView;e++)T.slides[e]&&T.lazy.loadImageInSlide(e);for(e=T.activeIndex-T.params.slidesPerView;e<T.activeIndex;e++)T.slides[e]&&T.lazy.loadImageInSlide(e)}else{var t=T.wrapper.children("."+T.params.slideNextClass);t.length>0&&T.lazy.loadImageInSlide(t.index());var r=T.wrapper.children("."+T.params.slidePrevClass);r.length>0&&T.lazy.loadImageInSlide(r.index())}},onTransitionStart:function(){T.params.lazyLoading&&(T.params.lazyLoadingOnTransitionStart||!T.params.lazyLoadingOnTransitionStart&&!T.lazy.initialImageLoaded)&&T.lazy.load()},onTransitionEnd:function(){T.params.lazyLoading&&!T.params.lazyLoadingOnTransitionStart&&T.lazy.load()}},T.scrollbar={isTouched:!1,setDragPosition:function(e){var a=T.scrollbar,t=i()?"touchstart"===e.type||"touchmove"===e.type?e.targetTouches[0].pageX:e.pageX||e.clientX:"touchstart"===e.type||"touchmove"===e.type?e.targetTouches[0].pageY:e.pageY||e.clientY,r=t-a.track.offset()[i()?"left":"top"]-a.dragSize/2,s=-T.minTranslate()*a.moveDivider,n=-T.maxTranslate()*a.moveDivider;s>r?r=s:r>n&&(r=n),r=-r/a.moveDivider,T.updateProgress(r),T.setWrapperTranslate(r,!0)},dragStart:function(e){var a=T.scrollbar;a.isTouched=!0,e.preventDefault(),e.stopPropagation(),a.setDragPosition(e),clearTimeout(a.dragTimeout),a.track.transition(0),T.params.scrollbarHide&&a.track.css("opacity",1),T.wrapper.transition(100),a.drag.transition(100),T.emit("onScrollbarDragStart",T)},dragMove:function(e){var a=T.scrollbar;a.isTouched&&(e.preventDefault?e.preventDefault():e.returnValue=!1,a.setDragPosition(e),T.wrapper.transition(0),a.track.transition(0),a.drag.transition(0),T.emit("onScrollbarDragMove",T))},dragEnd:function(e){var a=T.scrollbar;a.isTouched&&(a.isTouched=!1,T.params.scrollbarHide&&(clearTimeout(a.dragTimeout),a.dragTimeout=setTimeout(function(){a.track.css("opacity",0),a.track.transition(400)},1e3)),T.emit("onScrollbarDragEnd",T),T.params.scrollbarSnapOnRelease&&T.slideReset())},enableDraggable:function(){var e=T.scrollbar,t=T.support.touch?e.track:document;a(e.track).on(T.touchEvents.start,e.dragStart),a(t).on(T.touchEvents.move,e.dragMove),a(t).on(T.touchEvents.end,e.dragEnd)},disableDraggable:function(){var e=T.scrollbar,t=T.support.touch?e.track:document;a(e.track).off(T.touchEvents.start,e.dragStart),a(t).off(T.touchEvents.move,e.dragMove),a(t).off(T.touchEvents.end,e.dragEnd)},set:function(){if(T.params.scrollbar){var e=T.scrollbar;e.track=a(T.params.scrollbar),e.drag=e.track.find(".swiper-scrollbar-drag"),0===e.drag.length&&(e.drag=a('<div class="swiper-scrollbar-drag"></div>'),e.track.append(e.drag)),e.drag[0].style.width="",e.drag[0].style.height="",e.trackSize=i()?e.track[0].offsetWidth:e.track[0].offsetHeight,e.divider=T.size/T.virtualSize,e.moveDivider=e.divider*(e.trackSize/T.size),e.dragSize=e.trackSize*e.divider,i()?e.drag[0].style.width=e.dragSize+"px":e.drag[0].style.height=e.dragSize+"px",e.divider>=1?e.track[0].style.display="none":e.track[0].style.display="",T.params.scrollbarHide&&(e.track[0].style.opacity=0)}},setTranslate:function(){if(T.params.scrollbar){var e,a=T.scrollbar,t=(T.translate||0,a.dragSize);e=(a.trackSize-a.dragSize)*T.progress,T.rtl&&i()?(e=-e,e>0?(t=a.dragSize-e,e=0):-e+a.dragSize>a.trackSize&&(t=a.trackSize+e)):0>e?(t=a.dragSize+e,e=0):e+a.dragSize>a.trackSize&&(t=a.trackSize-e),i()?(T.support.transforms3d?a.drag.transform("translate3d("+e+"px, 0, 0)"):a.drag.transform("translateX("+e+"px)"),a.drag[0].style.width=t+"px"):(T.support.transforms3d?a.drag.transform("translate3d(0px, "+e+"px, 0)"):a.drag.transform("translateY("+e+"px)"),a.drag[0].style.height=t+"px"),T.params.scrollbarHide&&(clearTimeout(a.timeout),a.track[0].style.opacity=1,a.timeout=setTimeout(function(){a.track[0].style.opacity=0,a.track.transition(400)},1e3))}},setTransition:function(e){T.params.scrollbar&&T.scrollbar.drag.transition(e)}},T.controller={LinearSpline:function(e,a){this.x=e,this.y=a,this.lastIndex=e.length-1;var t,r;this.x.length;this.interpolate=function(e){return e?(r=s(this.x,e),t=r-1,(e-this.x[t])*(this.y[r]-this.y[t])/(this.x[r]-this.x[t])+this.y[t]):0};var s=function(){var e,a,t;return function(r,s){for(a=-1,e=r.length;e-a>1;)r[t=e+a>>1]<=s?a=t:e=t;return e}}()},getInterpolateFunction:function(e){T.controller.spline||(T.controller.spline=T.params.loop?new T.controller.LinearSpline(T.slidesGrid,e.slidesGrid):new T.controller.LinearSpline(T.snapGrid,e.snapGrid))},setTranslate:function(e,a){function r(a){e=a.rtl&&"horizontal"===a.params.direction?-T.translate:T.translate,"slide"===T.params.controlBy&&(T.controller.getInterpolateFunction(a),i=-T.controller.spline.interpolate(-e)),i&&"container"!==T.params.controlBy||(s=(a.maxTranslate()-a.minTranslate())/(T.maxTranslate()-T.minTranslate()),i=(e-T.minTranslate())*s+a.minTranslate()),T.params.controlInverse&&(i=a.maxTranslate()-i),a.updateProgress(i),a.setWrapperTranslate(i,!1,T),a.updateActiveIndex()}var s,i,n=T.params.control;if(T.isArray(n))for(var o=0;o<n.length;o++)n[o]!==a&&n[o]instanceof t&&r(n[o]);else n instanceof t&&a!==n&&r(n)},setTransition:function(e,a){function r(a){a.setWrapperTransition(e,T),0!==e&&(a.onTransitionStart(),a.wrapper.transitionEnd(function(){i&&(a.params.loop&&"slide"===T.params.controlBy&&a.fixLoop(),a.onTransitionEnd())}))}var s,i=T.params.control;if(T.isArray(i))for(s=0;s<i.length;s++)i[s]!==a&&i[s]instanceof t&&r(i[s]);else i instanceof t&&a!==i&&r(i)}},T.hashnav={init:function(){if(T.params.hashnav){T.hashnav.initialized=!0;var e=document.location.hash.replace("#","");if(e)for(var a=0,t=0,r=T.slides.length;r>t;t++){var s=T.slides.eq(t),i=s.attr("data-hash");if(i===e&&!s.hasClass(T.params.slideDuplicateClass)){var n=s.index();T.slideTo(n,a,T.params.runCallbacksOnInit,!0)}}}},setHash:function(){T.hashnav.initialized&&T.params.hashnav&&(document.location.hash=T.slides.eq(T.activeIndex).attr("data-hash")||"")}},T.disableKeyboardControl=function(){a(document).off("keydown",p)},T.enableKeyboardControl=function(){a(document).on("keydown",p)},T.mousewheel={event:!1,lastScrollTime:(new window.Date).getTime()},T.params.mousewheelControl){try{new window.WheelEvent("wheel"),T.mousewheel.event="wheel"}catch(R){}T.mousewheel.event||void 0===document.onmousewheel||(T.mousewheel.event="mousewheel"),T.mousewheel.event||(T.mousewheel.event="DOMMouseScroll")}T.disableMousewheelControl=function(){return T.mousewheel.event?(T.container.off(T.mousewheel.event,u),!0):!1},T.enableMousewheelControl=function(){return T.mousewheel.event?(T.container.on(T.mousewheel.event,u),!0):!1},T.parallax={setTranslate:function(){T.container.children("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y]").each(function(){c(this,T.progress)}),T.slides.each(function(){var e=a(this);e.find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y]").each(function(){var a=Math.min(Math.max(e[0].progress,-1),1);c(this,a)})})},setTransition:function(e){"undefined"==typeof e&&(e=T.params.speed),T.container.find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y]").each(function(){var t=a(this),r=parseInt(t.attr("data-swiper-parallax-duration"),10)||e;0===e&&(r=0),t.transition(r)})}},T._plugins=[];for(var W in T.plugins){var V=T.plugins[W](T,T.params[W]);V&&T._plugins.push(V)}return T.callPlugins=function(e){for(var a=0;a<T._plugins.length;a++)e in T._plugins[a]&&T._plugins[a][e](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5])},T.emitterEventListeners={},T.emit=function(e){T.params[e]&&T.params[e](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);var a;if(T.emitterEventListeners[e])for(a=0;a<T.emitterEventListeners[e].length;a++)T.emitterEventListeners[e][a](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);T.callPlugins&&T.callPlugins(e,arguments[1],arguments[2],arguments[3],arguments[4],arguments[5])},T.on=function(e,a){return e=m(e),T.emitterEventListeners[e]||(T.emitterEventListeners[e]=[]),T.emitterEventListeners[e].push(a),T},T.off=function(e,a){var t;if(e=m(e),"undefined"==typeof a)return T.emitterEventListeners[e]=[],T;if(T.emitterEventListeners[e]&&0!==T.emitterEventListeners[e].length){for(t=0;t<T.emitterEventListeners[e].length;t++)T.emitterEventListeners[e][t]===a&&T.emitterEventListeners[e].splice(t,1);return T}},T.once=function(e,a){e=m(e);var t=function(){a(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]),T.off(e,t)};return T.on(e,t),T},T.a11y={makeFocusable:function(e){return e.attr("tabIndex","0"),e},addRole:function(e,a){return e.attr("role",a),e},addLabel:function(e,a){return e.attr("aria-label",a),e},disable:function(e){return e.attr("aria-disabled",!0),e},enable:function(e){return e.attr("aria-disabled",!1),e},onEnterKey:function(e){13===e.keyCode&&(a(e.target).is(T.params.nextButton)?(T.onClickNext(e),T.isEnd?T.a11y.notify(T.params.lastSlideMessage):T.a11y.notify(T.params.nextSlideMessage)):a(e.target).is(T.params.prevButton)&&(T.onClickPrev(e),T.isBeginning?T.a11y.notify(T.params.firstSlideMessage):T.a11y.notify(T.params.prevSlideMessage)),a(e.target).is("."+T.params.bulletClass)&&a(e.target)[0].click())},liveRegion:a('<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>'),notify:function(e){var a=T.a11y.liveRegion;0!==a.length&&(a.html(""),a.html(e))},init:function(){if(T.params.nextButton){var e=a(T.params.nextButton);T.a11y.makeFocusable(e),T.a11y.addRole(e,"button"),T.a11y.addLabel(e,T.params.nextSlideMessage)}if(T.params.prevButton){var t=a(T.params.prevButton);T.a11y.makeFocusable(t),T.a11y.addRole(t,"button"),T.a11y.addLabel(t,T.params.prevSlideMessage)}a(T.container).append(T.a11y.liveRegion)},initPagination:function(){T.params.pagination&&T.params.paginationClickable&&T.bullets&&T.bullets.length&&T.bullets.each(function(){var e=a(this);T.a11y.makeFocusable(e),T.a11y.addRole(e,"button"),T.a11y.addLabel(e,T.params.paginationBulletMessage.replace(/{{index}}/,e.index()+1))})},destroy:function(){T.a11y.liveRegion&&T.a11y.liveRegion.length>0&&T.a11y.liveRegion.remove()}},T.init=function(){T.params.loop&&T.createLoop(),T.updateContainerSize(),T.updateSlidesSize(),T.updatePagination(),T.params.scrollbar&&T.scrollbar&&(T.scrollbar.set(),T.params.scrollbarDraggable&&T.scrollbar.enableDraggable()),"slide"!==T.params.effect&&T.effects[T.params.effect]&&(T.params.loop||T.updateProgress(),T.effects[T.params.effect].setTranslate()),T.params.loop?T.slideTo(T.params.initialSlide+T.loopedSlides,0,T.params.runCallbacksOnInit):(T.slideTo(T.params.initialSlide,0,T.params.runCallbacksOnInit),0===T.params.initialSlide&&(T.parallax&&T.params.parallax&&T.parallax.setTranslate(),T.lazy&&T.params.lazyLoading&&(T.lazy.load(),T.lazy.initialImageLoaded=!0))),T.attachEvents(),T.params.observer&&T.support.observer&&T.initObservers(),T.params.preloadImages&&!T.params.lazyLoading&&T.preloadImages(),T.params.autoplay&&T.startAutoplay(),T.params.keyboardControl&&T.enableKeyboardControl&&T.enableKeyboardControl(),T.params.mousewheelControl&&T.enableMousewheelControl&&T.enableMousewheelControl(),T.params.hashnav&&T.hashnav&&T.hashnav.init(),T.params.a11y&&T.a11y&&T.a11y.init(),T.emit("onInit",T)},T.cleanupStyles=function(){T.container.removeClass(T.classNames.join(" ")).removeAttr("style"),T.wrapper.removeAttr("style"),T.slides&&T.slides.length&&T.slides.removeClass([T.params.slideVisibleClass,T.params.slideActiveClass,T.params.slideNextClass,T.params.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-column").removeAttr("data-swiper-row"),T.paginationContainer&&T.paginationContainer.length&&T.paginationContainer.removeClass(T.params.paginationHiddenClass),T.bullets&&T.bullets.length&&T.bullets.removeClass(T.params.bulletActiveClass),T.params.prevButton&&a(T.params.prevButton).removeClass(T.params.buttonDisabledClass),T.params.nextButton&&a(T.params.nextButton).removeClass(T.params.buttonDisabledClass),T.params.scrollbar&&T.scrollbar&&(T.scrollbar.track&&T.scrollbar.track.length&&T.scrollbar.track.removeAttr("style"),T.scrollbar.drag&&T.scrollbar.drag.length&&T.scrollbar.drag.removeAttr("style"))},T.destroy=function(e,a){T.detachEvents(),T.stopAutoplay(),T.params.scrollbar&&T.scrollbar&&T.params.scrollbarDraggable&&T.scrollbar.disableDraggable(),T.params.loop&&T.destroyLoop(),a&&T.cleanupStyles(),T.disconnectObservers(),T.params.keyboardControl&&T.disableKeyboardControl&&T.disableKeyboardControl(),T.params.mousewheelControl&&T.disableMousewheelControl&&T.disableMousewheelControl(),T.params.a11y&&T.a11y&&T.a11y.destroy(),T.emit("onDestroy"),e!==!1&&(T=null)},T.init(),T}};t.prototype={isSafari:function(){var e=navigator.userAgent.toLowerCase();return e.indexOf("safari")>=0&&e.indexOf("chrome")<0&&e.indexOf("android")<0}(),isUiWebView:/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent),isArray:function(e){return"[object Array]"===Object.prototype.toString.apply(e)},browser:{ie:window.navigator.pointerEnabled||window.navigator.msPointerEnabled,ieTouch:window.navigator.msPointerEnabled&&window.navigator.msMaxTouchPoints>1||window.navigator.pointerEnabled&&window.navigator.maxTouchPoints>1},device:function(){var e=navigator.userAgent,a=e.match(/(Android);?[\s\/]+([\d.]+)?/),t=e.match(/(iPad).*OS\s([\d_]+)/),r=e.match(/(iPod)(.*OS\s([\d_]+))?/),s=!t&&e.match(/(iPhone\sOS)\s([\d_]+)/);return{ios:t||s||r,android:a}}(),support:{touch:window.Modernizr&&Modernizr.touch===!0||function(){return!!("ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch)}(),transforms3d:window.Modernizr&&Modernizr.csstransforms3d===!0||function(){var e=document.createElement("div").style;return"webkitPerspective"in e||"MozPerspective"in e||"OPerspective"in e||"MsPerspective"in e||"perspective"in e}(),flexbox:function(){for(var e=document.createElement("div").style,a="alignItems webkitAlignItems webkitBoxAlign msFlexAlign mozBoxAlign webkitFlexDirection msFlexDirection mozBoxDirection mozBoxOrient webkitBoxDirection webkitBoxOrient".split(" "),t=0;t<a.length;t++)if(a[t]in e)return!0}(),observer:function(){return"MutationObserver"in window||"WebkitMutationObserver"in window}()},plugins:{}};for(var r=(function(){var e=function(e){var a=this,t=0;for(t=0;t<e.length;t++)a[t]=e[t];return a.length=e.length,this},a=function(a,t){var r=[],s=0;if(a&&!t&&a instanceof e)return a;if(a)if("string"==typeof a){var i,n,o=a.trim();if(o.indexOf("<")>=0&&o.indexOf(">")>=0){var l="div";for(0===o.indexOf("<li")&&(l="ul"),0===o.indexOf("<tr")&&(l="tbody"),(0===o.indexOf("<td")||0===o.indexOf("<th"))&&(l="tr"),0===o.indexOf("<tbody")&&(l="table"),0===o.indexOf("<option")&&(l="select"),n=document.createElement(l),n.innerHTML=a,s=0;s<n.childNodes.length;s++)r.push(n.childNodes[s])}else for(i=t||"#"!==a[0]||a.match(/[ .<>:~]/)?(t||document).querySelectorAll(a):[document.getElementById(a.split("#")[1])],s=0;s<i.length;s++)i[s]&&r.push(i[s])}else if(a.nodeType||a===window||a===document)r.push(a);else if(a.length>0&&a[0].nodeType)for(s=0;s<a.length;s++)r.push(a[s]);return new e(r)};return e.prototype={addClass:function(e){if("undefined"==typeof e)return this;for(var a=e.split(" "),t=0;t<a.length;t++)for(var r=0;r<this.length;r++)this[r].classList.add(a[t]);return this},removeClass:function(e){for(var a=e.split(" "),t=0;t<a.length;t++)for(var r=0;r<this.length;r++)this[r].classList.remove(a[t]);return this},hasClass:function(e){return this[0]?this[0].classList.contains(e):!1},toggleClass:function(e){for(var a=e.split(" "),t=0;t<a.length;t++)for(var r=0;r<this.length;r++)this[r].classList.toggle(a[t]);return this},attr:function(e,a){if(1===arguments.length&&"string"==typeof e)return this[0]?this[0].getAttribute(e):void 0;for(var t=0;t<this.length;t++)if(2===arguments.length)this[t].setAttribute(e,a);else for(var r in e)this[t][r]=e[r],this[t].setAttribute(r,e[r]);return this},removeAttr:function(e){for(var a=0;a<this.length;a++)this[a].removeAttribute(e);return this},data:function(e,a){if("undefined"!=typeof a){for(var t=0;t<this.length;t++){var r=this[t];r.dom7ElementDataStorage||(r.dom7ElementDataStorage={}),r.dom7ElementDataStorage[e]=a}return this}if(this[0]){var s=this[0].getAttribute("data-"+e);return s?s:this[0].dom7ElementDataStorage&&e in this[0].dom7ElementDataStorage?this[0].dom7ElementDataStorage[e]:void 0}},transform:function(e){for(var a=0;a<this.length;a++){var t=this[a].style;t.webkitTransform=t.MsTransform=t.msTransform=t.MozTransform=t.OTransform=t.transform=e}return this},transition:function(e){"string"!=typeof e&&(e+="ms");for(var a=0;a<this.length;a++){var t=this[a].style;t.webkitTransitionDuration=t.MsTransitionDuration=t.msTransitionDuration=t.MozTransitionDuration=t.OTransitionDuration=t.transitionDuration=e}return this},on:function(e,t,r,s){function i(e){var s=e.target;if(a(s).is(t))r.call(s,e);else for(var i=a(s).parents(),n=0;n<i.length;n++)a(i[n]).is(t)&&r.call(i[n],e)}var n,o,l=e.split(" ");for(n=0;n<this.length;n++)if("function"==typeof t||t===!1)for("function"==typeof t&&(r=arguments[1],s=arguments[2]||!1),o=0;o<l.length;o++)this[n].addEventListener(l[o],r,s);else for(o=0;o<l.length;o++)this[n].dom7LiveListeners||(this[n].dom7LiveListeners=[]),this[n].dom7LiveListeners.push({listener:r,liveListener:i}),this[n].addEventListener(l[o],i,s);return this},off:function(e,a,t,r){for(var s=e.split(" "),i=0;i<s.length;i++)for(var n=0;n<this.length;n++)if("function"==typeof a||a===!1)"function"==typeof a&&(t=arguments[1],r=arguments[2]||!1),this[n].removeEventListener(s[i],t,r);else if(this[n].dom7LiveListeners)for(var o=0;o<this[n].dom7LiveListeners.length;o++)this[n].dom7LiveListeners[o].listener===t&&this[n].removeEventListener(s[i],this[n].dom7LiveListeners[o].liveListener,r);return this},once:function(e,a,t,r){function s(n){t(n),i.off(e,a,s,r);
}var i=this;"function"==typeof a&&(a=!1,t=arguments[1],r=arguments[2]),i.on(e,a,s,r)},trigger:function(e,a){for(var t=0;t<this.length;t++){var r;try{r=new window.CustomEvent(e,{detail:a,bubbles:!0,cancelable:!0})}catch(s){r=document.createEvent("Event"),r.initEvent(e,!0,!0),r.detail=a}this[t].dispatchEvent(r)}return this},transitionEnd:function(e){function a(i){if(i.target===this)for(e.call(this,i),t=0;t<r.length;t++)s.off(r[t],a)}var t,r=["webkitTransitionEnd","transitionend","oTransitionEnd","MSTransitionEnd","msTransitionEnd"],s=this;if(e)for(t=0;t<r.length;t++)s.on(r[t],a);return this},width:function(){return this[0]===window?window.innerWidth:this.length>0?parseFloat(this.css("width")):null},outerWidth:function(e){return this.length>0?e?this[0].offsetWidth+parseFloat(this.css("margin-right"))+parseFloat(this.css("margin-left")):this[0].offsetWidth:null},height:function(){return this[0]===window?window.innerHeight:this.length>0?parseFloat(this.css("height")):null},outerHeight:function(e){return this.length>0?e?this[0].offsetHeight+parseFloat(this.css("margin-top"))+parseFloat(this.css("margin-bottom")):this[0].offsetHeight:null},offset:function(){if(this.length>0){var e=this[0],a=e.getBoundingClientRect(),t=document.body,r=e.clientTop||t.clientTop||0,s=e.clientLeft||t.clientLeft||0,i=window.pageYOffset||e.scrollTop,n=window.pageXOffset||e.scrollLeft;return{top:a.top+i-r,left:a.left+n-s}}return null},css:function(e,a){var t;if(1===arguments.length){if("string"!=typeof e){for(t=0;t<this.length;t++)for(var r in e)this[t].style[r]=e[r];return this}if(this[0])return window.getComputedStyle(this[0],null).getPropertyValue(e)}if(2===arguments.length&&"string"==typeof e){for(t=0;t<this.length;t++)this[t].style[e]=a;return this}return this},each:function(e){for(var a=0;a<this.length;a++)e.call(this[a],a,this[a]);return this},html:function(e){if("undefined"==typeof e)return this[0]?this[0].innerHTML:void 0;for(var a=0;a<this.length;a++)this[a].innerHTML=e;return this},is:function(t){if(!this[0])return!1;var r,s;if("string"==typeof t){var i=this[0];if(i===document)return t===document;if(i===window)return t===window;if(i.matches)return i.matches(t);if(i.webkitMatchesSelector)return i.webkitMatchesSelector(t);if(i.mozMatchesSelector)return i.mozMatchesSelector(t);if(i.msMatchesSelector)return i.msMatchesSelector(t);for(r=a(t),s=0;s<r.length;s++)if(r[s]===this[0])return!0;return!1}if(t===document)return this[0]===document;if(t===window)return this[0]===window;if(t.nodeType||t instanceof e){for(r=t.nodeType?[t]:t,s=0;s<r.length;s++)if(r[s]===this[0])return!0;return!1}return!1},index:function(){if(this[0]){for(var e=this[0],a=0;null!==(e=e.previousSibling);)1===e.nodeType&&a++;return a}},eq:function(a){if("undefined"==typeof a)return this;var t,r=this.length;return a>r-1?new e([]):0>a?(t=r+a,new e(0>t?[]:[this[t]])):new e([this[a]])},append:function(a){var t,r;for(t=0;t<this.length;t++)if("string"==typeof a){var s=document.createElement("div");for(s.innerHTML=a;s.firstChild;)this[t].appendChild(s.firstChild)}else if(a instanceof e)for(r=0;r<a.length;r++)this[t].appendChild(a[r]);else this[t].appendChild(a);return this},prepend:function(a){var t,r;for(t=0;t<this.length;t++)if("string"==typeof a){var s=document.createElement("div");for(s.innerHTML=a,r=s.childNodes.length-1;r>=0;r--)this[t].insertBefore(s.childNodes[r],this[t].childNodes[0])}else if(a instanceof e)for(r=0;r<a.length;r++)this[t].insertBefore(a[r],this[t].childNodes[0]);else this[t].insertBefore(a,this[t].childNodes[0]);return this},insertBefore:function(e){for(var t=a(e),r=0;r<this.length;r++)if(1===t.length)t[0].parentNode.insertBefore(this[r],t[0]);else if(t.length>1)for(var s=0;s<t.length;s++)t[s].parentNode.insertBefore(this[r].cloneNode(!0),t[s])},insertAfter:function(e){for(var t=a(e),r=0;r<this.length;r++)if(1===t.length)t[0].parentNode.insertBefore(this[r],t[0].nextSibling);else if(t.length>1)for(var s=0;s<t.length;s++)t[s].parentNode.insertBefore(this[r].cloneNode(!0),t[s].nextSibling)},next:function(t){return new e(this.length>0?t?this[0].nextElementSibling&&a(this[0].nextElementSibling).is(t)?[this[0].nextElementSibling]:[]:this[0].nextElementSibling?[this[0].nextElementSibling]:[]:[])},nextAll:function(t){var r=[],s=this[0];if(!s)return new e([]);for(;s.nextElementSibling;){var i=s.nextElementSibling;t?a(i).is(t)&&r.push(i):r.push(i),s=i}return new e(r)},prev:function(t){return new e(this.length>0?t?this[0].previousElementSibling&&a(this[0].previousElementSibling).is(t)?[this[0].previousElementSibling]:[]:this[0].previousElementSibling?[this[0].previousElementSibling]:[]:[])},prevAll:function(t){var r=[],s=this[0];if(!s)return new e([]);for(;s.previousElementSibling;){var i=s.previousElementSibling;t?a(i).is(t)&&r.push(i):r.push(i),s=i}return new e(r)},parent:function(e){for(var t=[],r=0;r<this.length;r++)e?a(this[r].parentNode).is(e)&&t.push(this[r].parentNode):t.push(this[r].parentNode);return a(a.unique(t))},parents:function(e){for(var t=[],r=0;r<this.length;r++)for(var s=this[r].parentNode;s;)e?a(s).is(e)&&t.push(s):t.push(s),s=s.parentNode;return a(a.unique(t))},find:function(a){for(var t=[],r=0;r<this.length;r++)for(var s=this[r].querySelectorAll(a),i=0;i<s.length;i++)t.push(s[i]);return new e(t)},children:function(t){for(var r=[],s=0;s<this.length;s++)for(var i=this[s].childNodes,n=0;n<i.length;n++)t?1===i[n].nodeType&&a(i[n]).is(t)&&r.push(i[n]):1===i[n].nodeType&&r.push(i[n]);return new e(a.unique(r))},remove:function(){for(var e=0;e<this.length;e++)this[e].parentNode&&this[e].parentNode.removeChild(this[e]);return this},add:function(){var e,t,r=this;for(e=0;e<arguments.length;e++){var s=a(arguments[e]);for(t=0;t<s.length;t++)r[r.length]=s[t],r.length++}return r}},a.fn=e.prototype,a.unique=function(e){for(var a=[],t=0;t<e.length;t++)-1===a.indexOf(e[t])&&a.push(e[t]);return a},a}()),s=["jQuery","Zepto","Dom7"],i=0;i<s.length;i++)window[s[i]]&&e(window[s[i]]);var n;n="undefined"==typeof r?window.Dom7||window.Zepto||window.jQuery:r,n&&("transitionEnd"in n.fn||(n.fn.transitionEnd=function(e){function a(i){if(i.target===this)for(e.call(this,i),t=0;t<r.length;t++)s.off(r[t],a)}var t,r=["webkitTransitionEnd","transitionend","oTransitionEnd","MSTransitionEnd","msTransitionEnd"],s=this;if(e)for(t=0;t<r.length;t++)s.on(r[t],a);return this}),"transform"in n.fn||(n.fn.transform=function(e){for(var a=0;a<this.length;a++){var t=this[a].style;t.webkitTransform=t.MsTransform=t.msTransform=t.MozTransform=t.OTransform=t.transform=e}return this}),"transition"in n.fn||(n.fn.transition=function(e){"string"!=typeof e&&(e+="ms");for(var a=0;a<this.length;a++){var t=this[a].style;t.webkitTransitionDuration=t.MsTransitionDuration=t.msTransitionDuration=t.MozTransitionDuration=t.OTransitionDuration=t.transitionDuration=e}return this})),window.Swiper=t}(),"undefined"!=typeof module?module.exports=window.Swiper:"function"==typeof define&&define.amd&&define('module_calendarBf/js/swiper.min',[],function(){"use strict";return window.Swiper});


define('text!module_calendarBf/main.html',[],function () { return '<div data-view="main" id="main" class="views">\n\t<link rel="stylesheet" href="css/swiper.min.css">\n\t<style>\n\t\t#main .month-switch {\n\t\t\tpadding: 0;\n\t\t\tposition: absolute;\n\t\t\ttop: 3px;\n\t\t\tright: 5px;\n\t\t\toverflow: hidden;\n\t\t\tz-index: 1000;\n\t\t\tbackground: #fff;\n\t\t\tborder-radius: 5px;\n\t\t\tborder:1px solid #fff;\n\t\t}\n\t\t\n\t\t#main .month-switch li {\n\t\t\tlist-style: none;\n\t\t\tdisplay: block;\n\t\t\tfloat: left;\n\t\t\tfont-family: YouYuan;\n\t\t\tcolor: #fff;\n\t\t\twidth: 39px;\n\t\t\t/*height: 24px;*/\n\t\t\tline-height: 21px;\n\t\t\ttext-align: center;\n\t\t}\n\n\t\t#main .month-switch li .active {\n\t\t\tbackground-color: #fff;\n\t\t}\n\t\t\n\t\t#main .bar-tab .tab-item span {\n\t\t\tfont-size: 20px;\n\t\t\tcolor: #5baba2;\n\t\t}\n\t\t\n\t\t#main .bar-tab .tab-item .icon {\n\t\t\ttop: 0;\n\t\t}\n\t\t\n\t\t#main .bar-tab .tab-item .icon,\n\t\t.bar-tab .tab-item span {\n\t\t\tdisplay: inline-block;\n\t\t\tborder-radius: 50%;\n\t\t\tborder: 1px solid #5baba2;\n\t\t\theight: 36px;\n\t\t\twidth: 36px;\n\t\t\tline-height: 34px;\n\t\t}\n\t\t\n\t\t#main .bar-bottom {\n\t\t\tposition: absolute;\n\t\t\tbottom: 0;\n\t\t}\n\t\t\n\t\t#main #weekEventList td {\n\t\t\theight: 24px;\n\t\t\tbackground: #fff;\n\t\t\tbox-sizing: border-box;\n\t\t\t-moz-box-sizing: border-box;\n\t\t\t/* Firefox */\n\t\t\t-webkit-box-sizing: border-box;\n\t\t\t/* Safari */\n\t\t\twidth: 10%;\n\t\t}\n\t\t\n\t\t#main .titles {\n\t\t\toverflow: hidden;\n\t\t\ttext-overflow: ellipsis;\n\t\t\twhite-space: nowrap;\n\t\t\twidth: 100%;\n\t\t}\n\t\t\n\t\t#main .now-day {\n\t\t\t/*width: 30px;*/\n\t\t\theight: 30px;\n\t\t\tline-height: 30px;\n\t\t\tcolor: rgba(34, 24, 22, 0.77);\n\t\t\tdisplay: block;\n\t\t\tfont-family: arial;\n\t\t\ttext-align: center;\n\t\t\tborder-radius: 8px;\n\t\t}\n\t\t\n\t\t#main .now-day-bg {\n\t\t\t/*border:1px solid transparent;*/\n\t\t\tcolor: #fff!important;\n\t\t\tbackground: RGB(225, 178, 177);\n\t\t\t/*border-radius: 50%;*/\n\t\t}\n\t\t\n\t\t#main .now-day-color {\n\t\t\tcolor: #5BABA2;\n\t\t}\n\t\t\n\t\t#main .tap-day-bg {\n\t\t\tbackground: rgba(0, 0, 0, 0.2);\n\t\t\t/*        border-radius: 50%;*/\n\t\t\tcolor: #fff;\n\t\t}\n\t\t\n\t\t#main .circle {\n\t\t\twidth: 6px;\n\t\t\theight: 6px;\n\t\t\tbackground-color: RGB(103, 97, 97);\n\t\t\tborder-radius: 50%;\n\t\t\tposition: absolute;\n\t\t\tleft: 50%;\n\t\t\tbottom: 5px;\n\t\t\tmargin-left: -3px;\n\t\t}\n\t\t\n\t\t.swiper-slide {\n\t\t\ttext-align: center;\n\t\t\tfont-size: 18px;\n\t\t\t-webkit-box-pack: center;\n\t\t\t-ms-flex-pack: center;\n\t\t\t-webkit-justify-content: center;\n\t\t\tjustify-content: center;\n\t\t\t-webkit-box-align: center;\n\t\t\t-ms-flex-align: center;\n\t\t\t-webkit-align-items: center;\n\t\t\talign-items: center;\n\t\t}\n\t\t\n\t\t#weekList {\n\t\t\tdisplay: none;\n\t\t}\n\t\t\n\t\t.slim {\n\t\t\tfont-weight: normal;\n\t\t}\n\t\t\n\t\t.giveLayout {\n\t\t\tdisplay: inline-block;\n\t\t}\n\t\t\n\t\t#main .lists {\n\t\t\tborder-bottom: 1px solid #eee;\n\t\t\ttext-align: center;\n\t\t\tline-height: 48px;\n\t\t\theight: 48px;\n\t\t}\n\t\t\n\t\t.newUserTips {\n\t\t\twidth: 100%;\n\t\t\theight: 100%;\n\t\t\tposition: fixed;\n\t\t\tz-index: 999;\n\t\t\ttop: 0;\n\t\t\tleft: 0;\n\t\t\tbottom: 0;\n\t\t\tright: 0;\n\t\t\tdisplay: none;\n\t\t}\n\t\t\n\t\t.tap-day-bg .circle {\n\t\t\tvisibility: hidden;\n\t\t}\n\t\t\n\t\t.list {\n\t\t\tfont-family: arial, YouYuan;\n\t\t}\n\t\t\n\t\t.youyuan {\n\t\t\tfont-family: YouYuan;\n\t\t}\n\t\t\n\t\t.boldTxt {\n\t\t\tfont-weight: bold;\n\t\t}\n\t\t\n\t\tbutton,\n\t\tinput,\n\t\tselect,\n\t\ttextarea {\n\t\t\tfont-family: arial, YouYuan;\n\t\t\tfont-weight: normal;\n\t\t}\n\t\t/*新手指引*/\n\t\t\n\t\t.ui-newerGuide {\n\t\t\tposition: absolute;\n\t\t\ttop: 0;\n\t\t\tleft: 0;\n\t\t\tz-index: 1000;\n\t\t\twidth: 100%;\n\t\t\theight: 100%;\n\t\t\tbackground-color: rgba(0, 0, 0, 0.69);\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-1 {\n\t\t\twidth: 80px;\n\t\t\theight: 29px;\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-2 {\n\t\t\tposition: absolute;\n\t\t\tright: 70px;\n\t\t\ttop: 50px;\n\t\t\theight: 1.2rem;\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-3 {\n\t\t\tposition: absolute;\n\t\t\ttop: 210px;\n\t\t\tleft: 50%;\n\t\t\ttransform: translateX(-50%);\n\t\t\t-webkit-transform: translateX(-50%);\n\t\t\t-moz-transform: translateX(-50%);\n\t\t\theight: 1.6rem;\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-4 {\n\t\t\tposition: absolute;\n\t\t\tbottom: 50px;\n\t\t\tleft: 0;\n\t\t\twidth: 83%;\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-4 img {\n\t\t\tfloat: right;\n\t\t\theight: 1.2rem;\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-5 {\n\t\t\tborder: none;\n\t\t}\n\t\t\n\t\t.ui-newGuide-phone-5 img {\n\t\t\twidth: 38px;\n\t\t\theight: 38px;\n\t\t\tmargin-top: 5px;\n\t\t}\n\t\t/* write by ygy*/\n\t\t\n\t\t.content-item {\n\t\t\twidth: 100%;\n\t\t\tborder-bottom: 4px solid RGB(228, 228, 228);\n\t\t}\n\t\t\n\t\t.content-item ul {\n\t\t\twidth: 100%;\n\t\t\toverflow: auto;\n\t\t}\n\t\t\n\t\t.content-item ul li {\n\t\t\twidth: 33%;\n\t\t\tfloat: left;\n\t\t\tlist-style: none;\n\t\t\ttext-align: center;\n\t\t\tposition: relative;\n\t\t\tpadding: 10px;\n\t\t\tfont-size: 12px;\n\t\t}\n\t\t\n\t\t.content-item ul li img {\n\t\t\twidth: 26px;\n\t\t\tvertical-align: middle;\n\t\t\tpadding-right: 5px;\n\t\t}\n\t\t\n\t\t.content-item ul li:first-child:after {\n\t\t\tcontent: \'|\';\n\t\t\tposition: absolute;\n\t\t\tright: 0px;\n\t\t\tfont-size: 20px;\n\t\t\tcolor: RGB(122, 122, 122);\n\t\t}\n\t\t\n\t\t.content-item ul li:last-child:before {\n\t\t\tcontent: "|";\n\t\t\tposition: absolute;\n\t\t\tleft: 0px;\n\t\t\tfont-size: 20px;\n\t\t\tcolor: RGB(122, 122, 122);\n\t\t}\n\t\t/**/\n\t\t\n\t\t.content-title {\n\t\t\tbackground: RGB(198, 73, 71);\n\t\t\tcolor: white;\n\t\t\twidth: 100%;\n\t\t\toverflow: auto;\n\t\t\theight: 0.6rem;\n\t\t\tline-height: 0.6rem;\n\t\t\tposition: relative;\n\t\t}\n\t\t\n\t\t.content-title div {\n\t\t\ttext-align: center;\n\t\t}\n\t\t\n\t\t.content-icon-left,\n\t\t.content-icon-right {\n\t\t\twidth: 16%;\n\t\t\tfont-size: 0.6rem;\n\t\t\tfont-weight: 900;\n\t\t}\n\t\t\n\t\t.title-month {\n\t\t\twidth: 50%;\n\t\t\tmargin: 0 auto;\n\t\t\tposition: relative;\n\t\t}\n\t\t\n\t\t.title-month .title-today {\n\t\t\tposition: absolute;\n\t\t\tright: 0px;\n\t\t\ttop: 0px;\n\t\t\tborder: 1px solid gray;\n\t\t\tfont-size: 10px;\n\t\t\tbackground: white;\n\t\t\tcolor: black;\n\t\t\twidth: 40px;\n\t\t\tborder-radius: 4px;\n\t\t\tpadding: 5px;\n\t\t\tline-height: 100%;\n\t\t\tmargin-top: 3px;\n\t\t}\n\t\t.title-month .content-icon-left{\n\t\t\tfloat: left;\n\t\t}\n\t\t.title-month .content-icon-right{\n\t\t\tfloat: right;\n\t\t}\n\t\t#filter {\n\t\t\twidth: 100%;\n\t\t\toverflow: auto;\n\t\t\tpadding: 5px;\n\t\t\tborder: 1px solid RGB(82, 82, 82);\n\t\t\tfont-size: 12px;\n\t\t\tbackground: RGB(255, 255, 255);\n\t\t\tbox-sizing: border-box;\n\t\t}\n\t\t\n\t\t#filter #filter-word {\n\t\t\tfloat: left;\n\t\t\tfont-size: 16px;\n\t\t\tmargin-top: 1px;\n\t\t}\n\t\t\n\t\t#filter #month-or-week {\n\t\t\tfloat: left;\n\t\t\tmargin-left: 15px;\n\t\t\tborder-radius: 5px;\n\t\t\tpadding: 0 3px 0 3px;\n\t\t}\n\t\t\n\t\t#filter #filter-alltype {\n\t\t\tfloat: left;\n\t\t\tmargin-left: 15px;\n\t\t\tborder: 1px solid RGB(82, 82, 82);\n\t\t\tborder-radius: 5px;\n\t\t\tpadding: 0 3px 0 3px;\n\t\t}\n\t\t\n\t\t#filter #fliter-search {\n\t\t\tfloat: right;\n\t\t\tmargin-right: 5px;\n\t\t\tborder: 1px solid RGB(82, 82, 82);\n\t\t\tborder-radius: 5px;\n\t\t\tpadding: 0 3px 0 3px;\n\t\t\tcolor: RGB(82, 82, 82);\n\t\t}\n\t\t/**\n     * 导航\n     * */\n\t\t\n\t\t.horn {\n\t\t\tpadding-left: 20px;\n\t\t\tbackground: RGB(242, 242, 242);\n\t\t}\n\t\t\n\t\t.horn img {\n\t\t\tvertical-align: middle;\n\t\t}\n\t\t\n\t\t.activity_nav {\n\t\t\toverflow: auto;\n\t\t}\n\t\t\n\t\t.activity_nav .nav_list {\n\t\t\twidth: 25%;\n\t\t\tfloat: left;\n\t\t\ttext-align: center;\n\t\t\tpadding: 10px 0 10px 0;\n\t\t\tbox-sizing: border-box;\n\t\t\tbackground: white;\n\t\t}\n\t\t\n\t\t.activity_nav .nav_list img {\n\t\t\twidth: 20px;\n\t\t\theight: 20px;\n\t\t\tvertical-align: middle;\n\t\t}\n\t\t\n\t\t.goMain {\n\t\t\tdisplay: block;\n\t\t\twidth: 100%;\n\t\t}\n\t\t/*公司大事历*/\n\t\t\n\t\t.companyEvent,\n\t\t.companyActivity {\n\t\t\tpadding: 10px;\n\t\t\tdisplay: none;\n\t\t}\n\t\t\n\t\t.companyEvent p,\n\t\t.companyActivity p {\n\t\t\tline-height: 20px;\n\t\t}\n\t\t\n\t\t.companyEvent {\n\t\t\tbackground: RGB(228, 228, 228);\n\t\t}\n\t\t\n\t\t.companyActivity {\n\t\t\tbackground: RGB(255, 255, 204);\n\t\t}\n\t\t#section_wrap{\n\t\t\tpadding-bottom: 55px;\n\t\t}\n        #module-calendarBf-main .content{\n            bottom:50px;\n        }\n\t</style>\n\t<div id=\'module-calendarBf-main\'>\n\t\t<header class="ui3-header ui3-fontsize-2 ui3-theme-bg header-topBar" id="bar-header">\n\t\t\t<div class="ui3-row-12">\n\t\t\t\t<div class="ui3-col-3 ui3-icon-back back" data-click-title="日程表" data-click-label="返回">返回</div>\n\t\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title dataTitle" style="display:none;"></div>\n\t\t\t\t<!--原本放日期的位置，现在放活动二字-->\n\t\t\t\t<div class="ui3-col-6 ui3-fontsize-1 text-center header-title showTitle">活动</div>\n\t\t\t\t<div class="ui3-col-3 ui3-theme-color ui3-header-right">\n\t\t\t\t\t<!--<ul class="month-switch" id="monthChange"> <li class="active" data-click-title="日程表" data-click-label="月">月</li> <li data-click-title="日程表" data-click-label="周">周</li> </ul>--><span style="color: black;" class="goMain">首页</span> </div>\n\t\t\t</div>\n\t\t</header>\n\t\t<!--<header class="bar bar-nav blue-bar top-background-color" id="bar-header" style="position: absolute"> <button class="btn btn-link btn-nav pull-left back"> <span class="icon icon-left-nav  ui3-icon-back "><span>返回</span></span> </button> <div class="title dataTitle" style="display: none;">2015.9</div> <div class="title showTitle">2015.9</div> <ul class="month-switch" id="monthChange"> <li class="active">月</li> <li>周</li> </ul> </header>-->\n\t\t<div class="content" style="position: absolute;">\n\t\t\t<div id="main_jroll">\n\t\t\t\t<div class="horn" style="display: none;"> <img src="images/horn_icon.png"> <span>业务总监会议时间更改为09:00-12:00</span> </div>\n\t\t\t\t<div class="activity_nav" style="font-size: 12px;">\n\t\t\t\t\t<!--<div class="nav_list goHostActivity"> <img src="images/hostActivity_icon.png" /> <span>举办活动</span> </div>\n\t\t\t\t\t<div class="nav_list goSignUp"> <img src="images/activity_signUp.png" /> <span>活动报名</span> </div>\n\t\t\t\t\t<div class="nav_list goVisit"> <img src="images/visit_icon.png" /> <span>参观申请</span> </div>\n\t\t\t\t\t<div class="nav_list goCalendar" style="color: RGB(255,0,0);"> <img src="images/calendar_icon.png" /> <span>日历</span> </div>-->\n\t\t\t\t</div>\n\t\t\t\t<!--<div class="content-item">-->\n\t\t\t\t\t<!--<ul>-->\n\t\t\t\t\t\t<!--<li><img src="images/edit.png">我参与的活动</li>-->\n\t\t\t\t\t\t<!--<li><img src="images/edit.png">公司活动报名</li>-->\n\t\t\t\t\t\t<!--<li class="add-schedule"><img src="images/edit.png">新增日程</li>-->\n\t\t\t\t\t<!--</ul>-->\n\t\t\t\t<!--</div>-->\n\t\t\t\t<div class="content-title">\n\t\t\t\t\t<div class="title-month">\n\t\t\t\t\t\t<div class="content-icon-left"><</div>\n\t\t\t\t\t\t<span class="showTitle">2016年6月</span>\n\t\t\t\t\t\t<div class="content-icon-right">></div>\n\t\t\t\t\t\t<!--<div class=\'title-today\'>今天</div>-->\n\t\t\t\t\t</div>\n\t\t\t\t\t<ul class="month-switch" id="monthChange">\n\t\t\t\t\t\t<li class="active" data-click-title="日程表" data-click-label="月">月</li>\n\t\t\t\t\t\t<li data-click-title="日程表" data-click-label="周">周</li>\n\t\t\t\t\t</ul>\n\t\t\t\t</div>\n\t\t\t\t\t<table width="100%" style="background-color:#F2F2F2;" id="calendarHeader">\n\t\t\t\t\t\t<tr align="center">\n\t\t\t\t\t\t\t<td style="padding-top:10px;padding-bottom:10px;color: #221816">日</td>\n\t\t\t\t\t\t\t<td>一</td>\n\t\t\t\t\t\t\t<td>二</td>\n\t\t\t\t\t\t\t<td>三</td>\n\t\t\t\t\t\t\t<td>四</td>\n\t\t\t\t\t\t\t<td>五</td>\n\t\t\t\t\t\t\t<td style="color: #221816">六</td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t</table>\n\t\t\t\t\t<div id="calendar-month">\n\t\t\t\t\t\t<section id="calender_wrap">\n\t\t\t\t\t\t\t<div id="calenderList" class="calender-list">\n\t\t\t\t\t\t\t\t<div class="swiper-wrapper">\n\t\t\t\t\t\t\t\t\t<div class="swiper-slide"></div>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</section>\n\t\t\t\t\t\t<!--<section id="filter">-->\n\t\t\t\t\t\t\t<!--<div id="filter-word">筛选:</div>-->\n\t\t\t\t\t\t\t<!--<div id="month-or-week">-->\n\t\t\t\t\t\t\t\t<!--<ul class="month-switch" id="monthChange">-->\n\t\t\t\t\t\t\t\t\t<!--<li class="active" data-click-title="日程表" data-click-label="月">月</li>-->\n\t\t\t\t\t\t\t\t\t<!--<li data-click-title="日程表" data-click-label="周">周</li>-->\n\t\t\t\t\t\t\t\t<!--</ul>-->\n\t\t\t\t\t\t\t<!--</div>-->\n\t\t\t\t\t\t\t<!--<div id="filter-alltype">全部类型</div>-->\n\t\t\t\t\t\t\t<!--<div id="fliter-search">搜索</div>-->\n\t\t\t\t\t\t<!--</section>-->\n\t\t\t\t\t</div>\n\t\t\t\t\t<div id="calendar-week">\n\t\t\t\t\t\t<div class="swiper-wrapper">\n\t\t\t\t\t\t\t<div class="swiper-slide">\n\t\t\t\t\t\t\t\t<section id="">\n\t\t\t\t\t\t\t\t\t<div id="weekList" class="week-list"> </div>\n\t\t\t\t\t\t\t\t</section>\n\t\t\t\t\t\t\t\t<!--<section id="week-wrapper">-->\n\n\t\t\t\t\t\t\t\t\t<!--<div id="eventTabList">-->\n\t\t\t\t\t\t\t\t\t\t<!--<table id="weekEventList" class="weekEventList" style="display:none; width:100%;table-layout:fixed;height: 100%;"></table>-->\n\t\t\t\t\t\t\t\t\t<!--</div>-->\n\t\t\t\t\t\t\t\t<!--</section>-->\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t\t<section id="section_wrap">\n\t\t\t\t\t<div id="jroll_wrap">\n\t\t\t\t\t\t<div id="eventList">\n\t\t\t\t\t\t\t<!--新增公司大事历、公司活动-->\n\t\t\t\t\t\t\t<div class="companyEvent">\n\t\t\t\t\t\t\t\t<h4>公司大事历</h4>\n\t\t\t\t\t\t\t\t<div class="companyEventContent">\n\t\t\t\t\t\t\t\t\t<!--<p>2016年11月4日-11月7日，上海无限极活动举办领导人年会</p>\n                                    <p>2016年11月11日-11月13日，上海无限极活动举办新生代活动</p>-->\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class="companyActivity">\n\t\t\t\t\t\t\t\t<h4>公司活动</h4>\n\t\t\t\t\t\t\t\t<div class="companyActivityContent">\n\t\t\t\t\t\t\t\t\t<!--<p>9:00-12:00 业务总监会议 上海无限极服务中心</p>\n                                    <p>9:00-12:00 业务总监会议 上海无限极服务中心</p>\n                                    <p>9:00-12:00 业务总监会议 上海无限极服务中心</p>-->\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div id="eventList_box"></div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</section>\n\t\t\t\t\t<div id="calendar-week" style="display: none;">\n\t\t\t\t\t\t<div class="swiper-wrapper">\n\t\t\t\t\t\t\t<div class="swiper-slide">\n\t\t\t\t\t\t\t\t<section id="">\n\t\t\t\t\t\t\t\t\t<div id="weekList" class="week-list"> </div>\n\t\t\t\t\t\t\t\t</section>\n\t\t\t\t\t\t\t\t<section id="week-wrapper">\n\n\t\t\t\t\t\t\t\t\t<div id="eventTabList">\n\t\t\t\t\t\t\t\t\t\t<table id="weekEventList" class="weekEventList" style="display:none; width:100%;table-layout:fixed;height: 100%;"></table>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</section>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t\t<!--下栏三个图标不要-->\n\t\t\t\t<nav class="bar bar-tab bar-bottom giveLayout"> <a class="tab-item" id="todayBtn" href="javascript:;" data-click-title="日程表" data-click-label="今天"> <span data-click-title="日程表" data-click-label="今天">今</span> </a> <a class="tab-item" id="searchBtn" href="javascript:;" data-click-title="日程表" data-click-label="搜索"> <span class="icon icon-search" data-click-title="日程表" data-click-label="搜索"></span> </a> <a class="tab-item" id="addBtn" href="javascript:;" data-click-title="日程表" data-click-label="添加"> <span class="icon icon-plus" data-click-title="日程表" data-click-label="添加"></span> </a> </nav>\n\t\t\t\t<div id="toDetail" style="display:none"></div>\n\t\t\t\t<div class="newUserTips"><img src="" width="100%" height="100%"></div>\n\t\t\t\t<div class="ui-newerGuide" style="display:none">\n\t\t\t\t\t<!--指引元素--><img class="ui-newGuide-phone-1 month-switch " src="./images/newGuide_phone_1.png"> <img class="ui-newGuide-phone-2" src="./images/newGuide_phone_2.png"> <img class="ui-newGuide-phone-3" src="./images/newGuide_phone_3.png">\n\t\t\t\t\t<div class="ui-newGuide-phone-4"> <img src="./images/newGuide_phone_4.png"> </div>\n\t\t\t\t\t<div class="bar-tab ui-newGuide-phone-5">\n\t\t\t\t\t\t<div class="tab-item"></div>\n\t\t\t\t\t\t<div class="tab-item"></div>\n\t\t\t\t\t\t<a class="tab-item"> <img src="./images/newGuide_phone_5.png"> </a>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>';});


define('text!module_calendarBf/template/week-template.html',[],function () { return '<%function format(num){\n\tnum=""+num;\n\tif(parseInt(num)<10 && num.length<2){\n\t\treturn "0"+num;\n\t}else{\n\t\treturn num;\n\t}\n}%>\n<table class="table" width="100%" style="background-color:#F2F2F2;">\n\t<tr align="center">\n\t<% for(var i = 0; i < 7; i++){ %>\n\t\t<%var formatedDay=format(weekArray[i][2]);\n\t\t  var formatedMonth=format(weekArray[i][1]);\n\t\t%>\n\t\t<td  style="padding:5px;color: #221816; position:relative; width:14.28%" class="calendar-day" >\n\t\t\t<a href="javascript:;" class="now-day <%if(currentDate.nowDay==userClickDate[2] && currentDate.nowMonth==userClickDate[1]){\n\t\t\t    if(weekArray[i][2]==currentDate.nowDay){%>now-day-bg now-day-color<%}}\n\t\t\telse{if(weekArray[i][2]==userClickDate[2] && weekArray[i][0]==userClickDate[0] && weekArray[i][1]==userClickDate[1]){%>tap-day-bg<%}}%>" data-date="<%=weekArray[i][0]%>-<%=formatedMonth%>-<%=formatedDay%>"><%=weekArray[i][2]%></a>\n\t\t</td>\n\n\t<%}%>\n\t</tr>\n\t<tr height="1px">\n\t\t<td colspan=7 style="border-bottom:1px solid  #EEE;"></td>\n\t</tr>\n</table>\n';});


define('text!module_calendarBf/template/weekEventList-template.html',[],function () { return '<tr>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n</tr>\n<tr align="">\n\t<% for(var i=0; i<preTd; i++) { %>\n\t\t<td style="color: #221816; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<% } %>\n\t<!-- 日程 -->\n    <td style="text-align:left;color: #221816;background-color:#EEF7F6; border-radius:5px; border-right:1px solid #eee; box-sizing:border-box;" class="list"  data-mark="<%=sqlData.mark%>"  data-date="<%=sqlData.date%>" data-address="<%=sqlData.address%>" data-title="<%=sqlData.title%>" data-startTime="<%=sqlData.startTime%>" data-endTime="<%=sqlData.endTime%>" data-allDay="<%=sqlData.allDay%>" data-remind="<%=sqlData.remind%>" data-repeat="<%=sqlData.repeat%>" data-remarks="<%=sqlData.remarks%>" data-remindMark="<%=sqlData.remindMark%>" data-thingid="<%=sqlData.thingid%>"  data-itemId="<%=sqlData.id%>" data-thingEndTime="<%=sqlData.thingEndTime%>" colspan="<%=theTd%>" data-click-title="标题" data-click-label="事件详情" data-click-value="<%=sqlData.id%>">\n    <div style="background-color:#EEF7F6;" data-click-title="标题" data-click-label="事件详情" data-click-value="<%=sqlData.id%>"><span style="font-size:14px;font-family:\'微软雅黑\';overflow:hidden;white-space:nowrap;text-overflow:ellipsis;display: block;"  data-click-title="标题" data-click-label="事件详情" data-click-value="<%=sqlData.id%>"><%=sqlData.title%></span></div>\n    </td>\n\t<% for(var i=0; i<nextTd; i++) {%>\n\t\t<td style="color: #221816; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td>\n\t<% } %>\n</tr>';});


define('text!module_calendarBf/template/fourTypeEvents-template.html',[],function () { return '<div>\n\t<!--有约-->\n\t<div id="invTpl">\n\n\t</div>\n\t\n\t<!--参观申请-->\n\t<div id="visitTpl">\n\n\t</div>\n\t\n\t<!--公司活动-->\n\t<script type="text/template" id="activityTpl">\n\t\t<div data-id=\'<%=id%>\' data-group-type="<%=groupType%>" data-mark="<%=mark%>"  data-date="<%=date%>" data-address="<%=address%>" data-title="<%=title%>" data-startTime="<%=startTime%>" data-endTime="<%=endTime%>" data-allDay="<%=allDay%>" data-itemId="<%=id%>" data-remind="<%=remind%>" data-repeat="<%=repeat%>" data-remarks="<%=remarks%>" data-remindMark="<%=remindMark%>" data-thingid="<%=thingid%>" data-thingEndTime="<%=thingEndTime%>" data-from-search="<%=fromSearch%>" data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>">\n\t\t\t<span><%= startTime %>至<%= endTime %></span>\n\t\t\t<span><%= title %></span>\n\t\t\t<span><%= address %></span>\n\t\t</div>\n\t</script>\n\t\n\t<!--公司大事历-->\n\t<script type="text/template" id="eventsTpl">\n\t\t<div data-id=\'<%=id%>\' data-group-type="<%=groupType%>" data-mark="<%=mark%>"  data-date="<%=date%>" data-address="<%=address%>" data-title="<%=title%>" data-startTime="<%=startTime%>" data-endTime="<%=endTime%>" data-allDay="<%=allDay%>" data-itemId="<%=id%>" data-remind="<%=remind%>" data-repeat="<%=repeat%>" data-remarks="<%=remarks%>" data-remindMark="<%=remindMark%>" data-thingid="<%=thingid%>" data-thingEndTime="<%=thingEndTime%>" data-from-search="<%=fromSearch%>" data-click-title="标题" data-click-label="事件详情" data-click-value="<%=id%>">\n\t\t\t<span><%= startTime %>至<%= endTime %></span>\n\t\t\t<span><%= title %></span>\n\t\t\t<span><%= address %></span>\n\t\t</div>\n\t</script>\n</div>';});


define('text!module_calendarBf/template/activities_menu_tpl.html',[],function () { return '\t<%for(var i=0;i<result.length;i++){\n\t    if(result[i].attributes.iconUri == \'\'){result[i].attributes.iconUri = \'images/home_icon_01.png\'} %>\n\t\t<div class="nav_list " style="color: red;" uri="<%=result[i].uri%>" title="<%=result[i].name%>" jNavInfo=\'<%=result[i].attributes.helpUri%>\'>\n\t\t\t<img src="<%=result[i].attributes.iconUri%>"/>\n\t\t\t<span><%=result[i].name%></span>\n\t\t</div>\n\t<%}%>';});

/**
 * @license RequireJS domReady 2.0.1 Copyright (c) 2010-2012, The Dojo Foundation All Rights Reserved.
 * Available via the MIT or new BSD license.
 * see: http://github.com/requirejs/domReady for details
 */
/*jslint */
/*global require: false, define: false, requirejs: false,
  window: false, clearInterval: false, document: false,
  self: false, setInterval: false */


define('module_calendarBf/../../butterfly/vendor/lib/domReady',[],function () {
    'use strict';

    var isTop, testDiv, scrollIntervalId,
        isBrowser = typeof window !== "undefined" && window.document,
        isPageLoaded = !isBrowser,
        doc = isBrowser ? document : null,
        readyCalls = [];

    function runCallbacks(callbacks) {
        var i;
        for (i = 0; i < callbacks.length; i += 1) {
            callbacks[i](doc);
        }
    }

    function callReady() {
        var callbacks = readyCalls;

        if (isPageLoaded) {
            //Call the DOM ready callbacks
            if (callbacks.length) {
                readyCalls = [];
                runCallbacks(callbacks);
            }
        }
    }

    /**
     * Sets the page as loaded.
     */
    function pageLoaded() {
        if (!isPageLoaded) {
            isPageLoaded = true;
            if (scrollIntervalId) {
                clearInterval(scrollIntervalId);
            }

            callReady();
        }
    }

    if (isBrowser) {
        if (document.addEventListener) {
            //Standards. Hooray! Assumption here that if standards based,
            //it knows about DOMContentLoaded.
            document.addEventListener("DOMContentLoaded", pageLoaded, false);
            window.addEventListener("load", pageLoaded, false);
        } else if (window.attachEvent) {
            window.attachEvent("onload", pageLoaded);

            testDiv = document.createElement('div');
            try {
                isTop = window.frameElement === null;
            } catch (e) {}

            //DOMContentLoaded approximation that uses a doScroll, as found by
            //Diego Perini: http://javascript.nwbox.com/IEContentLoaded/,
            //but modified by other contributors, including jdalton
            if (testDiv.doScroll && isTop && window.external) {
                scrollIntervalId = setInterval(function () {
                    try {
                        testDiv.doScroll();
                        pageLoaded();
                    } catch (e) {}
                }, 30);
            }
        }

        //Check if document already complete, and if so, just trigger page load
        //listeners. Latest webkit browsers also use "interactive", and
        //will fire the onDOMContentLoaded before "interactive" but not after
        //entering "interactive" or "complete". More details:
        //http://dev.w3.org/html5/spec/the-end.html#the-end
        //http://stackoverflow.com/questions/3665561/document-readystate-of-interactive-vs-ondomcontentloaded
        //Hmm, this is more complicated on further use, see "firing too early"
        //bug: https://github.com/requirejs/domReady/issues/1
        //so removing the || document.readyState === "interactive" test.
        //There is still a window.onload binding that should get fired if
        //DOMContentLoaded is missed.
        if (document.readyState === "complete") {
            pageLoaded();
        }
    }

    /** START OF PUBLIC API **/

    /**
     * Registers a callback for DOM ready. If DOM is already ready, the
     * callback is called immediately.
     * @param {Function} callback
     */
    function domReady(callback) {
        if (isPageLoaded) {
            callback(doc);
        } else {
            readyCalls.push(callback);
        }
        return domReady;
    }

    domReady.version = '2.0.1';

    /**
     * Loader Plugin API method
     */
    domReady.load = function (name, req, onLoad, config) {
        if (config.isBuild) {
            onLoad(null);
        } else {
            domReady(onLoad);
        }
    };

    /** END OF PUBLIC API **/

    return domReady;
});

define('module_calendarBf/main',['jquery', 'View',
	'text!./template/calendar-template.html',
	'text!./template/week-template.html',
	'text!./template/eventList-template.html',
	'text!./template/weekEventList-template.html',
	'text!./template/fourTypeEvents-template.html',
	'text!./template/activities_menu_tpl.html',
	'../commonBf/js/EMCSUtil',
	'../../butterfly/components/store',
	'bsl', './js/swiper.min', './js/common', './js/moment.min',
	'jroll_infinite', 'init',
	'../../butterfly/vendor/lib/domReady',
	'../commonBf/js/isShowNewerGuide',"com",'./config', './js/calendarFunc'
], function($, View, calendarTpl, weekTpl, eventListTpl, WeekEventList,fourTypeEventsTpl ,activitiesMenuTpl, Util, Store, bsl, swiper3, CalendarCommon, moment, JRoll_Infinite, init, domReady, isShowNewerGuide,com,config,Func) {
	window.onerror = function(e) {
			console.log(e)
		}
		//文档加载结束，关闭原生loading--by dyz 2016-7-15
	domReady(function() {
		bsl.infinitus.tools.dismissLoading();
	});

	window.backAction = function() {
		var localsion = window.location.href;
		var localcalendarAdd = localsion.indexOf("calendarAdd"); //新建事件
		var localcalendarDetails = localsion.indexOf("calendarDetails"); //事件详情
		var localcalendarEdit = localsion.indexOf("calendarEdit"); //编辑事件
		var localcalendarSearch = localsion.indexOf("calendarSearch"); //搜索事件
		var localcalendarRemind = localsion.indexOf("calendarRemind"); //非全天提醒
		var localcalendarRemindAllday = localsion.indexOf("calendarRemind-Allday"); //全天提醒
		var localcalendarRepeat = localsion.indexOf("calendarRepeat"); //重复
		var localmain = localsion.indexOf("main");
		if(localmain > -1) {
			bsl.infinitus.transfer.returnBack(true);
		} else if(localcalendarAdd > -1) {
			if(Store.loadObject("calendarBf_remind") == "remind") {
				Butterfly.Store.deleteObject("calendarBf_remind");
				$("#calendarRemind").remove();
			} else if(Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
				Butterfly.Store.deleteObject("calendarBf_remindAllday");
				$("#calendarRemind-Allday").remove();
			} else if(Store.loadObject("calendarBf_repeat") == "repeat") {
				Butterfly.Store.deleteObject("calendarBf_repeat");
				$("#calendarRepeat").remove();
			} else {
				if(Store.loadObject("calendarBf_add") == "add") {
					$("#calendarAdd .back").trigger("click");
				}
			}
		} else if(localcalendarDetails > -1) {
			if($("#calendarDetails #DivYY").css("display") != "none") {
				$("#calendarDetails #DivYY").hide();
				$("#calendarDetails #deleteDiv").hide();
				$("#calendarDetails #deleteDivOnly").hide();
			} else {
				if(Store.loadObject("calendarBf_DetailsPrepage") == "Search") {
					window.butterfly.navigate('module_calendarBf/calendarSearch', {
						trigger: true
					});
				} else {
					window.butterfly.navigate('module_calendarBf/main', {
						trigger: true
					});
				}
			}
		} else if(localcalendarEdit > -1) {
			if($("#calendarEdit #DivYY").css("display") != "none") {
				$("#calendarEdit #DivYY").hide();
				$("#calendarEdit #saveDiv").hide();
			} else {
				if(Store.loadObject("calendarBf_remind") == "remind") {
					Butterfly.Store.deleteObject("calendarBf_remind");
					$("#calendarRemind").remove();
				} else if(Store.loadObject("calendarBf_remindAllday") == "remindAllday") {
					Butterfly.Store.deleteObject("calendarBf_remindAllday");
					$("#calendarRemind-Allday").remove();
				} else if(Store.loadObject("calendarBf_repeat") == "repeat") {
					Butterfly.Store.deleteObject("calendarBf_repeat");
					$("#calendarRepeat").remove();
				} else {
					if(Store.loadObject("calendarBf_edit") == "edit") {
						$("#calendarEdit .back").trigger("tap");
					}
				}
			}
		} else if(localcalendarSearch > -1) {
			window.butterfly.navigate('module_calendarBf/main', {
				trigger: true
			});
		}
	};
	var me = null;
    var dealerNo = null; //用户卡号
    var ActivityListStartTime;//公司大事件开始时间
    var ActivityListEndTime;//公司大事件结束时间
	var main_jroll = null;  //整个页面的jroll
	var displayYear = 0; // 当前日历显示的年
	var displayMonth = 0; // 当前日历显示的
	var displayWeek = null; // 当前周历显示的基准，没切换一次 移动7天时间
	var padDialog = null; // pad显示的 模态框对象
	var calenderList_JRoll = null; // 日程列表 “月历” iscroll对象
	var eventTabList_JRoll = null; //日程列表 “周历” iscroll对象
	var dateInfArray = []; // 存储查询到的日程数据
	var weekInfArray = []; // 存储查询到的一周日程数据
	var isPad = null; // 判断设备是不是平板
	var listLines = 0; //月历无事件列表数量
	var mySwiperMonth = null;      //日程列表“月历”swiper对象
	var model = View.extend({
		events: {
			"tap #module-calendarBf-main #todayBtn span": "diaplayNow",
			// "tap #module-calendarBf-main .title-today": "diaplayNow",
			"tap #module-calendarBf-main #monthChange": "monthChange",
			"click #module-calendarBf-main #addBtn span": "addEvent",
			// "click #module-calendarBf-main .add-schedule": "addEvent",
			"click #module-calendarBf-main #searchBtn span": "search",
			// "click #module-calendarBf-main #fliter-search": "search",
			"click #module-calendarBf-main .list": "details",
			"click #module-calendarBf-main .calendar-day a": "tapDay",
			"tap #module-calendarBf-main .back": "bslBack",
			"click .goSignUp":"goSignUp",
			"click .goHostActivity":"goActivityHost",
			"click .goMain":"goMain",
            "click .companyActivityContent>div":"details",
            "click .companyEventContent>div":"details"
		},
		userClickDate: null,
		initialize: function() {

			//运行公共方法初始化
			init.getStyle();

			//固定高度解决bug：https://jira.infinitus.com.cn/browse/GBSS-8905?filter=12372
			document.body.style.height = window.innerHeight + "px";
		},

		render: function() {

			me = this;
			//设置默认选中日期为今天
			d = me.getNowDate();
			// 存储公共信息，包括网络，手机版本等。
			if(isInApp) {
				bsl.infinitus.tools.getCommonParam(function(str) {
					var commonParamObj = JSON.parse(str);
					// 版本信息转换成小写
					var brand = commonParamObj[0].brand.toLowerCase();
					// 根据设备信息判断 ipad
					if(brand == "ipad") {
						Store.saveObject('calendarBf_isPad', true);
						isPad = true;

						// 设置pad 中dialog 的位置
						me.setDialogPosition();

					} else {
						Store.saveObject('calendarBf_isPad', false);
						isPad = false;
					}

					// 判断 是否 苹果设备
					if(brand == "ipad" || brand == "iphone") {
						Store.saveObject("calendarBf_isApple", true);
					}
					// 存储设备信息
					Store.saveObject("calendarBf_commonParam", commonParamObj);
				});
			}
			//　删除isFirstEnter　保证滑动事件绑定
			Butterfly.Store.deleteObject("calendarBf_isFirstEnter");
			Butterfly.Store.deleteObject("calendarBf_selectDate");
			Butterfly.Store.deleteObject("calendarBf_weekObj");
			var now = new Date();
			me.userClickDate = moment().format('YYYY-MM-DD');
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
			// 用于处理 今天显示背景
			Butterfly.Store.deleteObject("calendarBf_isFirstEnter_two");
			me.chageBarColor();
		},

		bslBack: function() {
			bsl.infinitus.transfer.goHome();
		},

		/*//点击举办活动
		goActivityHost:function(){
			bsl.infinitus.transfer.openWebPage({
				url:"/activity/pages/module_activityBf/index.html#/module_activityBf/main",
				sFlag:false
			});
		},

		//点击活动报名
		goSignUp:function(){
			bsl.infinitus.transfer.openWebPage({
				url:"/activity/pages/module_activityBf/index.html#/module_activityBf/activitySignUp",
				sFlag:false
			});
		},

		//点击进入公司活动详情
		goCompanyActivityDetail:function(){
			Util.navigate("companyActivityDetail");
		},*/

		//点击首页
		goMain:function(){
			com.goMain();
		},

		//显示当前的星期 或者 当日的 事件
		diaplayNow: function() {
			//按【今】按钮时userClickDate改为今日
			d = me.getNowDate();
			me.userClickDate = d.dateString;
			//$(target).addClass("now-day-bg");
			if($("#main #calenderList").css("display") == "none") {
				me.thisWeek();
			} else {
				Store.saveObject("calendarBf_isFirstEnter_two", false);
				var dayObject = me.getNowDate();
				var title = $('#main .dataTitle').html();
				if(title == dayObject.nowYear + '.' + dayObject.nowMonth) {
					me.show_today();
				} else {
					me.today();
				}
			}
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
		},
		addPage: null,

		addEvent: function() {
			if(!isPad) {
				window.butterfly.navigate('module_calendarBf/calendarAdd', {
					trigger: true
				});
				// 初始化 提醒 重复 “无”
				Store.saveObject("calendarBf_remind_type", 0);
				Store.saveObject("calendarBf_repeat_type", 0);
			} else {
				me.showPadDialog(me.addPage, 'calendarAdd');
				// 初始化 提醒 重复 “无”
				Store.saveObject("calendarBf_remind_type", 0);
				Store.saveObject("calendarBf_repeat_type", 0);
			}
		},

		detailPage: null,
        companyActivityDetail:null,
		// 设置高度
		setHeight: function() {
			var winHeight = $("#main").height() - $('#calendarHeader').height() - $("#calender_wrap").height() - $("#bar-header").height() - $(".bar-bottom").height();
			var newAddHeight = $('.horn').height() + $(".activity_nav").height() + $(".content-item").height() + $(".content-title").height();
			var sectionWrapHeight = $("#module-calendarBf-main .content").height() - $('#main_jroll').height();
            $('#section_wrap').height(sectionWrapHeight+'px');
			winHeight = winHeight - newAddHeight;
			//winHeight 再减去 $('.companyEvent').height() 再减去 $(".companyActivity").height();
			//周的显示就正常了
			console.log(winHeight);
			var weekHeight = $("#main").height() - $('#calendarHeader').height() - $("#weekList").height() - $("#bar-header").height() - $(".bar-bottom").height();
			// $("#main #section_wrap").css("height", winHeight + "px");
			console.log(weekHeight);
			//$("#main #section_wrap").css("height", winHeight + "px");
			$("#main #week-wrapper").css("height", weekHeight + "px");
			//$("#main #weekEventList").css("height", winHeight + "px");
			listLines = Math.floor(winHeight / 48);
		},

		details: function(e) {
			Store.saveObject("calendarBf_padSearchEnter", false);
			var theObj = {};
			var target = e.currentTarget;
			// while($(target).attr("class") != "list") target = target.parentNode;
			theObj = {
				date: $(target).attr("data-date"),
				title: $(target).attr("data-title"),
				address: $(target).attr("data-address"),
				startTime: $(target).attr("data-startTime"),
				endTime: $(target).attr("data-endTime"),
				allDay: $(target).attr("data-allDay"),
				remind: $(target).attr("data-remind"),
				repeat: $(target).attr("data-repeat"),
				remarks: $(target).attr("data-remarks"),
				mark: $(target).attr("data-mark"),
				remindMark: $(target).attr("data-remindMark"),
				id: parseInt($(target).attr("data-itemId")),
				thingid: parseInt($(target).attr("data-thingid")),
				thingEndTime: $(target).attr("data-thingEndTime"),
                groupType:$(target).attr("data-group-type")
			};
			console.log(theObj);
			Store.saveObject("calendarBf_show_detail_obj", theObj);
			Store.saveObject("calendarBf_remind_type", $(target).data("remind"));
			Store.saveObject("calendarBf_repeat_type", $(target).data("repeat"));
			Store.saveObject("calendarBf_allDay_type", $(target).attr("data-allDay"));
			Store.saveObject("calendarBf_DetailsPrepage", "main");
            var detailPage = me.detailPage,
                url = 'calendarDetails';
            if(theObj.groupType != '99'){//如果不是个人事件
                url = "companyActivityDetail";
                detailPage = me.companyActivityDetail;
            }
			if(!isPad) {
				window.butterfly.navigate('module_calendarBf/'+url, {
					trigger: true
				});
			} else {
				me.showPadDialog(detailPage, url);
			}
		},
		searchPage: null,
		search: function() {
			if(!isPad) {
				window.butterfly.navigate('module_calendarBf/calendarSearch', {
					trigger: true
				});
				bsl.infinitus.cat.analytics({
					"category": "日程搜索",
					"action": "浏览",
					"label": "",
					"value": ""
				});
			} else {
				me.showPadDialog(me.searchPage, 'calendarSearch_pad');
				bsl.infinitus.cat.analytics({
					"category": "日程搜索",
					"action": "浏览",
					"label": "",
					"value": ""
				});
			}
		},

		// 获取页面 地址 出去hash 的部分
		getUrl: function() {
			var href = window.location.href
			return href.split('#')[0];
		},

		// 一些自定义的绑定事件
		bindEvent: function() {
			//用swiper实现的左右滑动
			setTimeout(function() { //添加左右滑动效果需要有100毫秒的延时
				me.swiper();
			}, 200);

		},
		swiper: function() {
			var isMonthFirst = 0; //swiper首次执行时会触发onSlideNextEnd
			mySwiperMonth = new swiper3('#calenderList', {
				loop: true,
				threshold: 30,
				onSlidePrevEnd: function(swiper) {
					me.showPreMonth();
				},
				onSlideNextEnd: function(swiper) {
					if(isMonthFirst != 0) {
						me.showNextMonth();
					}
					isMonthFirst = 1;
				}
			});


			//左右箭头绑定滑动事件
			$('.content-icon-left').unbind('click').bind('click',function() {
				mySwiperMonth.slidePrev();
			})
			$('.content-icon-right').unbind('click').bind('click',function() {
				mySwiperMonth.slideNext();
			})

		},
		openDatabase: function(dbName) {
			var DEFAULT_SIZE = 5000000;
			// return bsl.sqlite.openDatabase(dbName, "1.0", "calendar", DEFAULT_SIZE);
			return bsl.sqlite.openDatabase({
				name: dbName,
				location: 'default'
			});
		},
		/**
		查询，并显示，某一天的事件
		*/
		showDateCalendar: function(date) {
			var tmpDate = moment(date, 'YYYY-MM-DD');
			CalendarCommon.getCalendarItemsFromDb(
				tmpDate.startOf("day").unix(),
				tmpDate.startOf("day").add(1, "days").unix(),
				function(data) {
					dateInfArray = data;
                    console.log('=====================',data);
					// me.loadCompanyEventsAndActivity(data);
					me.showDateCalendarItems();
				},
				function() {});
			//查询大事件
			if(dealerNo){
			    me.getActivityList(me.userClickDate)
			}
		},
		//月事件查询
		showDateCalendarOld: function(date) {
			Store.saveObject("calendarBf_userClickDate", date);

			var saveObj = {};

			saveObj.year = date.split("-")[0];
			saveObj.month = date.split("-")[1];
			saveObj.date = date.split("-")[2];
			Store.saveObject("calendarBf_selectDate", saveObj);

			var array = date.split('-');
			for(var i = 0; i < array.length; i++) {
				array[i] = array[i] < 10 ? "0" + array[i] : array[i];
			}
			date = array.join('-');
			dateInfArray = [];
			var db = me.openDatabase("mydatabase.sqlite");
			db.transaction(function(tx) {
				tx.executeSql('CREATE TABLE IF NOT EXISTS calendar_thing (id integer primary key, date TEXT, title TEXT, address TEXT, startTime TEXT, endTime TEXT, allDay BOOLEAN, remind INTEGER, repeat INTEGER, remarks TEXT, mark TEXT, weekinf TEXT, remindMark TEXT, orderAllday INTEGER, orderStart INTEGER, orderEnd INTEGER)');
			});
			var theObj = {}; // 临时存贮对象
			db.transaction(function(tx) {
				var sql = "select * from calendar_thing where date like '%" + date + "%' order by orderAllday desc, orderStart desc, orderEnd desc, id desc";
				tx.executeSql(sql, [], function(tx, res) {
					dateInfArray = [];
					for(var i = 0; i < res.rows.length; i++) {
						theObj = {
							date: res.rows.item(i).date,
							title: res.rows.item(i).title,
							allDay: res.rows.item(i).allDay,
							address: res.rows.item(i).address,
							startTime: res.rows.item(i).startTime,
							endTime: res.rows.item(i).endTime,
							remind: res.rows.item(i).remind,
							repeat: res.rows.item(i).repeat,
							remarks: res.rows.item(i).remarks,
							// mark 同一条记录的 mark 一致
							mark: res.rows.item(i).mark,
							weekinf: res.rows.item(i).weekinf,
							remindMark: res.rows.item(i).remindMark,
							// 排序的标志
							orderAllday: res.rows.item(i).orderAllday,
							orderStart: res.rows.item(i).orderStart,
							orderEnd: res.rows.item(i).orderEnd
						}
						dateInfArray.push(theObj);
					}
					// 显示到页面中
					me.showDateCalendarItems();
				});
			});
		},

		// 查询某一天 是否有事件
		isHasEvent: function(date) {
			var array = date.split('-');
			for(var i = 0; i < array.length; i++) {
				array[i] = array[i] < 10 ? "0" + array[i] : array[i];
			}
			date = array.join('-');
			var db = me.openDatabase("mydatabase.sqlite");
			db.transaction(function(tx) {
				var sql = "select * from calendar_thing where date like '%" + date + "%'";
				tx.executeSql(sql, [], function(tx, res) {
					if(res.rows.length) {
						return true
					} else {
						return false
					}
				});
			});
		},
		//周事件查询
		showCalendarWeek: function() {
			var ucDate = moment(me.userClickDate, 'YYYY-M-D');
			CalendarCommon.getCalendarItemsFromDb(
				ucDate.startOf("week").unix(),
				ucDate.startOf("week").add(1, "weeks").unix(),
				function(data) {
					weekInfArray = data;
					me.randerWeekThing();
				},
				function() {
					//console.log("showCalendar error");
				});
		},
		selectWeekDatebaseOld: function(week) {
			weekInfArray = [];
			var db = me.openDatabase("mydatabase.sqlite");
			var theObj = {}; // 临时存贮对象
			db.transaction(function(tx) {
				var sql = "select * from calendar_thing where weekinf like '%" + week + "%' order by orderAllday desc, orderStart desc, orderEnd desc, id desc";
				tx.executeSql(sql, [], function(tx, res) {
					for(var i = 0; i < res.rows.length; i++) {
						theObj = {
							date: res.rows.item(i).date,
							title: res.rows.item(i).title,
							allDay: res.rows.item(i).allDay,
							address: res.rows.item(i).address,
							startTime: res.rows.item(i).startTime,
							endTime: res.rows.item(i).endTime,
							remind: res.rows.item(i).remind,
							repeat: res.rows.item(i).repeat,
							remarks: res.rows.item(i).remarks,
							// mark 同一条记录的 mark 一致
							mark: res.rows.item(i).mark,
							weekinf: res.rows.item(i).weekinf,
							remindMark: res.rows.item(i).remindMark,
							// 排序的标志
							orderAllday: res.rows.item(i).orderAllday,
							orderStart: res.rows.item(i).orderStart,
							orderEnd: res.rows.item(i).orderEnd
						}

						var Date = res.rows.item(i).date;
						var Y = Date.split('-')[0];
						var M = Date.split('-')[1];
						M = M.replace(/^0/, "");
						if(Y == displayYear && M == displayMonth) {
							weekInfArray.push(theObj);
						};
					}

					// 显示到页面中
					me.randerWeekThing();
				});
			});
		},

		// 设置 pad 中dialog 的位置。
		setDialogPosition: function() {
			var winH = $(document).height();
			var winW = $(document).width();

			var dialogH = (winH - 575) / 2;
			var dialogW = (winW - 380) / 2;

			// 设置dialog 的宽高
			// pad 弹出的页面在其中
			$("#pad-dialog").css({
				top: dialogH + "px",
				left: dialogW + "px"
			})
		},

		onShow: function() {
			//生成菜单
				var menuCode = "BUPM-PHONE-HOME-ACTIVITY";
				Util.getMenu(menuCode,function(menus){
	            	var activities_menu_obj = _.template(activitiesMenuTpl);
	            	var activities_menu_html = activities_menu_obj({
		                result: menus
		            });
		            me.$el.find('.activity_nav').html(activities_menu_html);
					me.$el.find('.activity_nav>div').unbind('click').bind('click',function(e){
						var $currentTarget = $(e.currentTarget);
						var uri = $currentTarget.attr('uri');
						var jNavInfoStr = $currentTarget.attr('jNavInfo');
						var title = $currentTarget.attr('title');
						//var jNavInfoObj = JSON.parse(jNavInfoStr);
						bsl.infinitus.transfer.openWebPage({ "sTitle":title, "url": uri, "sFlag": true,"jNavInfo":jNavInfoStr});
					});		
				});

			isShowNewerGuide({ //设置新手指引-by dyz --2016-08-03
				modal: "calendarBf",
				parentSelector: "#main",
				padId: ".ui-newerGuide",
				phoneId: ".ui-newerGuide"
			});
			Store.saveObject("calendarBf_searchEnter", false);

			if(isInApp && !Store.loadObject("calendarBf_isApple")) {
				bsl.infinitus.tools.setBackAction(backAction);
			};
			// 禁止页面长按复制 安卓可以 ipad不行
			document.onselectstart = new Function("event.returnValue=false");
			/**
			每天运行一次
			*/
			CalendarCommon.init();
			//添加提醒
			CalendarCommon.initRemind();
			// 初始化为指定年月
			me.userClickDate = Store.loadObject("calendarBf_userClickDate");
			var theYear = me.userClickDate.split("-")[0];
			var theMonth = me.userClickDate.split("-")[1];

			//add by ygy
			displayYear = theYear;
			displayMonth = theMonth;

			// 显示某一天的日历事件列表
			//me.showDateCalendar(me.userClickDate);
			//me.showMonthTapDay();
			//为了判断management传过来的参数，把上面两句话写到getManagementArg函数里面
			me.getManagementEventList();



			//从服务器读取数据并放入本地数据库并再次显示数据
			// me.insertDataFromServer(function(){
			// 	// 显示某一天的日历事件列表
			// 	bsl.infinitus.tools.showToast('数据已更新', 2000);
			// 	me.getManagementEventList();
			// });



			if(Store.loadObject("calendarBf_weekObj")) {
				var theObj = Store.loadObject("calendarBf_weekObj");
				me.showCalendarWeek(theObj.theWeek); //刷新当前周的事件
			}
			// 绑定自定义事件 滑动切换日历等
			if(!Store.loadObject("calendarBf_isFirstEnter")) {
				// 保证 事件绑定只执行一次
				//me.showCalendar(theYear, theMonth);
				//要根据management传过来的参数显示日历哪个日期active
				me.getManagementCalendar(theYear,theMonth);

				me.bindEvent();
			} else {
				// 显示某一月的月历、初始化小圆点
				me.showCalendar(theYear, theMonth, "slide");
			};
			// 月历的 scroll事件
			setTimeout(function() {
				if($("#main #monthChange").find("li[class='active']").text() == '月') {
					$('#main #weekList').hide();
				}
//				if(!calenderList_JRoll) {
//					calenderList_JRoll = new JRoll("#main #section_wrap", {
//						bounce: true,
//						scrollX: false
//					});
//				} else {
//					calenderList_JRoll.refresh();
//				}
			}, 5);

			//提醒进入后的自动点击进入详情页
			setTimeout(function() {
				if(localStorage.getItem("calendarBf_noticeId")) {
					var item = {
						id: localStorage.getItem("calendarBf_noticeId")
					};
					CalendarCommon.pageCalendarSelectOneItem(item, function(data) {
						if(data) {
							$('#main #toDetail').on('click', function() {
								me.toDetails();
							});
							setTimeout(function() {
								$('#main #toDetail').click();
							}, 500);
						} else {
							localStorage.removeItem("calendarBf_noticeId");
							bsl.infinitus.tools.showToast("该事件已经删除", 1000);
						};
					});
				};
				me.showNewUserTips();
			}, 500);

			//埋点信息
			bsl.infinitus.cat.analytics({
				"category": "日程表",
				"action": "浏览",
				"label": "",
				"value": ""
			});

			//新建jroll
			main_jroll = new JRoll("#section_wrap",{
				bounce:true,
				scrollX:false
			});
			// me.getActivityList();
            me.getDataFromServer();//获取 用户ID
		},

		insertDataFromServer: function(datas){
		    var len = datas.length;
		    if(!len){
		        return false;
            }
            CalendarCommon.pageCalendarDeleteAllItemFromServer(function(){
				$.each(datas,function(key,data){
					var remindMark = Func.randomString(8); // 更新重复事件统一id
					var thing = {};
					thing.address = data.address;
					thing.title = data.title;
					if (data.groupType == 3) {//0：有约;1：参观申请;2：活动;3：大事件
						thing.allDay = true;
						thing.orderAllday = 0;
					} else {
						thing.allDay = false;
						thing.orderAllday = 1;
					}
					thing.remind = 0;
					thing.repeat = 0;
					thing.remarks = data.remark ? data.remark : '';
					thing.startTime = parseInt(data.startTime) / 1000;
					thing.endTime = parseInt(data.endTime) / 1000;
					//thing.startTime = 1481262116;//hardcode
					//thing.endTime = 1481214116;//hardcode
					thing.thingEndTime = 0;
					thing.remindMark = remindMark;
					thing.modifyids = '';
					thing.datafrom = 'server';
					thing.readonly = true;
					thing.dealerNo = dealerNo;
					thing.groupType = data.groupType;
					thing.state = data.state ? data.state : 0;
					thing.type = data.type;
					thing.showApply = (data.groupType == 1) || (data.groupType == 2) ? true : false;
					thing.isApply = data.isApply != null ? data.isApply : 0;
					console.log('thing',thing);
						CalendarCommon.pageCalendarAdd(thing, function() {
                            console.log('初始化数据成功',len);
                            len--;
                            if(len === 0){
                                bsl.infinitus.tools.showToast('初始化数据成功', 1000);
                                me.loadCompanyEventsAndActivity()
                            }
						},function(err) {
                            len--;
                            if(len === 0){
                                bsl.infinitus.tools.showToast('初始化数据失败', 1000);
                            }
						});
				});
            },function(err){

            });
		},

		getDataFromServer: function(){
			bsl.infinitus.tools.getUserInfo(function(data) {
				if (typeof(data) == "string") {
	                var data = JSON.parse(data);
	            }
	            dealerNo = data.authAttr.dealerNo;
	            var date = me.userClickDate;
				var param = dealerNo + '/' + date;
				console.log('getCalendarsList param:',param);
                me.getActivityList();//获取公司大事件
				// Util.Ajax({
				// 	url: config.Api.getCalendarsList + param,
                 //    data:{
                //
                 //    },
				// 	success: function(data, status, xhr) {
				// 		console.log('getCalendarsList data:',data);
				// 		callback(dealerNo,data);
				// 	}
				// });
			});
		},

		//判断management有没有传输传过来，有的话就加载传过来的日期的事件列表
		getManagementEventList:function(){
			var d = window.localStorage.getItem("viewdetails_data");
			//var d = "2015-12-01";
			if(d){
				me.showDateCalendar(d);
				me.showMonthTapDay(d);
			}else{
				me.showDateCalendar(me.userClickDate);
				me.showMonthTapDay();
			}
		},

		//判断management有没有传输传过来，有的话就日历就显示传过来的日期的那个月的1号
		getManagementCalendar:function(theYear,theMonth){
			var d = window.localStorage.getItem("viewdetails_data");
			//var d = "2015-12-01";
			if(d){
				var y = d.split('-')[0];
				var m = d.split('-')[1];
				//把日历强行定位到某一个月
				me.showCalendar(y, m);
				//把日历强行定位到传过来参数，即是一号
				me.setCurrentDayIcon(d);
				//缓存日期，切换周日期不变
				Store.saveObject("calendarBf_userClickDate", d);
			}else{
				me.showCalendar(theYear, theMonth);
			}
		},

		//加载公司大事历和公司活动
		loadCompanyEventsAndActivity:function(item){
			var invContent="",visitContent="",activityContent="",eventsContent="";
			var invTplFn = _.template($(fourTypeEventsTpl).find("#invTpl").html()),
			    visitTplFn = _.template($(fourTypeEventsTpl).find("#visitTpl").html()),
			    activityTplFn = _.template($(fourTypeEventsTpl).find("#activityTpl").html()),
			    eventsTplFn = _.template($(fourTypeEventsTpl).find("#eventsTpl").html());

			//循环分别装进不同的tpl
			//for(var i=0;i<data.length;i++){
				var item = $.extend(true,{},item);
                item.startTime = moment.unix(item.startTime).format('YYYY-MM-DD');
                item.endTime = moment.unix(item.endTime).format('YYYY-MM-DD');
				switch(item.groupType){
					case 1||2:     //活动
					    var tpl = activityTplFn(item);
					    activityContent+=tpl;
						break;
					case 3:     //大事件
						var tpl = eventsTplFn(item);
					    eventsContent+=tpl;
						break;
				}

			//}

			//将tpl塞进html
			if(activityContent)$('.companyEvent').show().find('.companyEventContent').append(activityContent);
            if(eventsContent)$('.companyActivity').show().find('.companyActivityContent').append(eventsContent);

		},
		showNewUserTips: function() {
			var tipsData = localStorage.getItem("calendarBf_mainTips"),
				tips = $("#main .newUserTips");
			if(tipsData !== "yes") {
				if(isPad) {
					tips.css("display", "block").find("img").attr("src", "images/ipadTips1.png");
				} else {
					tips.css("display", "block").find("img").attr("src", "images/phoneTips1.png");
				};
				tips.on("click", function() {
					tips.css("display", "none");
					localStorage.setItem("calendarBf_mainTips", "yes");
				});
			};
		},
		chageBarColor: function() {
			bsl.infinitus.tools.themeColor("status_bar_bg", function(val) {
				var val = 'ffffff';
				if(/ffffff/.test(val)) {
					//var cssTxt = "<style>header{background-color:" + val + "!important;}#main .month-switch li.active,#main .now-day-color{color:RGB(198,73,71)!important}#main .now-day-bg,#main .circle,#main .month-switch li.active{background-color:color:RGB(198,73,71)!important;color:#fff!important;}#main .month-switch li{color:RGB(198,73,71);}</style>";
					var cssTxt = "<style>header{background-color:" + val + "!important;}#main .month-switch li.active,#main .now-day-color{color:RGB(198,73,71)!important}#main .month-switch li.active,footer .save-btn{background-color:RGB(198,73,71)!important;color:#fff!important;}#main .month-switch li{color:RGB(198,73,71);}</style>";
				} else {
					//var cssTxt = "<style>header{background-color:" + val + "!important;}#main .month-switch li.active,#main .now-day-color{color:" + val + "!important}#main .now-day-bg,#main .circle{background-color:" + val + "!important;color:#fff!important;}</style>";
					var cssTxt = "<style>header{background-color:" + val + "!important;}#main .month-switch li.active,#main .now-day-color{color:" + val + "!important}#main .now-day-bg,footer .save-btn{background-color:" + val + "!important;color:#fff!important;}</style>";
				}

				$("body").append(cssTxt);
			});
		},

		//提醒进入详情页专用
		toDetails: function() {
			if(!isPad) {
				window.butterfly.navigate('module_calendarBf/calendarDetails', {
					trigger: true
				});
			} else {
				Store.saveObject("calendarBf_padSearchEnter", false);
				Store.saveObject("calendarBf_DetailsPrepage", "main");
				me.showPadDialog(me.detailPage, 'calendarDetails');
			}
		},

		//周历的 scroll事件
		eventTabListRoll_Func: function() {
			if(!eventTabList_JRoll) {
				eventTabList_JRoll = new JRoll("#main #eventTabList", {
					bounce: true,
					scrollX: false
				});
			} else {
				eventTabList_JRoll.refresh(); //刷新周历事件Scroll
			}
			eventTabList_JRoll.scrollTo(0, 0);
		},
		// 显示 周事件到页面中
		randerWeekThing: function() {
			// $("#main .weekEventList").html("");
			// var displayObj = [];
			// var theObj = {};
			// var preId = 0;
			// var nextId = 0;
			// var theTd = 7;
			// // 获取本周
			// var nowYear = parseInt(moment(displayWeek).format("YYYY"));
			// var nowWeek = parseInt(moment(displayWeek).format("w"));
			// for(var i = 0; i < weekInfArray.length; i++) {
			// 	var date = weekInfArray[i];
			// 	var theWeekInf = weekInfArray[i].weekinf.split("&");
			// 	var startYear = theWeekInf[0].split('-')[0];
			// 	var endYear = theWeekInf[theWeekInf.length - 1].split('-')[0];
			// 	// 日程开始的那天是第几周
			// 	var startWeekArr = theWeekInf[0].split('-')[1];
			// 	// 日程开始的那天是 周几
			// 	var startDayWeek = theWeekInf[0].split('-')[2];
			// 	// 日程结束的那天是第几周
			// 	var endWeekArr = theWeekInf[theWeekInf.length - 1].split('-')[1];
			// 	// 日程结束的那天是 周几
			// 	var endDayWeek = theWeekInf[theWeekInf.length - 1].split('-')[2];
			// 	// 处理0-6周的情况
			// 	var startWeek = startWeekArr > 99 ? (startWeekArr - 100) : startWeekArr;
			// 	var endWeek = endWeekArr > 99 ? (endWeekArr - 100) : endWeekArr;
            //
			// 	/*
			// 	    if 开始所在的周 等于 当前周  说明没有跨周  preId=startDayWeek
			// 	    if 开始所在的周 大于 当前周  说明跨年了 preId = 0
			// 	    if 开始所在的周 小于 当前周  说明跨周了 preId = 0
			// 	*/
			// 	if((startWeek == nowWeek && startYear == nowYear) || (startYear == endYear && startWeek == nowWeek)) {
			// 		preId = startDayWeek;
			// 	} else {
			// 		preId = 0;
			// 	}
            //
			// 	/*
			// 	    if 结束所在的周 等于 当前周  说明没有跨周  nextId=6-endDayWeek
			// 	    if 结束所在的周 大于 当前周  说明跨周了 nextId = 0
			// 	    if 结束所在的周 小于 当前周  说明跨年了 nextId = 0
			// 	*/
			// 	if(endWeek == nowWeek) {
			// 		nextId = 6 - endDayWeek;
			// 	} else {
			// 		nextId = 0;
			// 	}
            //
			// 	theTd = 7 - preId - nextId;
			// 	theObj = {
			// 		preTd: preId,
			// 		nextTd: nextId,
			// 		theTd: theTd,
			// 		sqlData: weekInfArray[i]
			// 	}
			// 	displayObj.push(theObj);
			// }
			// var count = 0;
			// if(displayObj.length != 0) {
            //
			// 	_.each(displayObj, function(elem, index) {
			// 		var weekEventListHtml = _.template(WeekEventList, elem);
			// 		$("#main .weekEventList").prepend(weekEventListHtml);
			// 		count++;
			// 		if(count == displayObj.length) {
			// 			$("#main .weekEventList").append('<tr><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td></tr>');
			// 			setTimeout(function() {
			// 				me.eventTabListRoll_Func();
			// 			}, 300);
			// 		};
			// 	});
            //
			// };
			// for(var i = 0; i < 10 - count; i++) {
			// 	$("#main .weekEventList").append('<tr><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td></tr>');
			// 	if(count == 0 && i == 4) {
			// 		$("#main .weekEventList").append('<tr><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;text-align:left;" colspan="1"><span style="display:block;font-size:14px;text-align:center;">无日程</span></td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td><td style="height:1px; padding:0; border-right:1px solid #eee; box-sizing:border-box;" colspan="1">&nbsp;&nbsp;</td></tr>');
			// 	};
            //
			// };

			var isWeekFirst = 0; //swiper首次执行时会触发onSlideNextEnd
			var mySwiperWeek = new swiper3('#calendar-week', {
				loop: true,
				threshold: 30,
				onSlidePrevEnd: function(swiper) {
					me.showPreWeek();
				},
				onSlideNextEnd: function(swiper) {
					if(isWeekFirst != 0) {
						me.showNextWeek();
					}
					isWeekFirst = 1;
				}
			});


			//左右箭头绑定滑动事件,用one代替不会卡顿
			$('.content-icon-left').unbind('click').bind('click', function() {
				mySwiperWeek.slidePrev();
			})
			$('.content-icon-right').unbind('click').bind('click', function() {
				mySwiperWeek.slideNext();
			})

			$('[data-click-title="标题"]').attr("data-click-title", "日程表");
		},

		/**
		查询显示 某一天的 日程
		显示事件列表
		*/
		showDateCalendarItems: function() {
			$("#eventList_box").html("");
            $('.companyEvent').hide().find('.companyEventContent').empty();
            $('.companyActivity').hide().find('.companyActivityContent').empty();
			if(dateInfArray.length != 0) {
				_.each(dateInfArray,
					function(elem, index) {
				    var dateArray = elem.date.split(','),
                        dateArrayLen = parseInt(dateArray.length),
                        today = elem.dateTime;
						elem.noDate = true;
						elem.fromSearch = 'false';
                        console.log('呵呵呵呵呵呵',elem);
                        if(dateArrayLen> 1 ){
                            if(dateArray[0] != today){
                                elem.startTimeHourMin = '00:00';
                            }
                            if(dateArray[dateArrayLen - 1] != today){
                                elem.endTimeHourMin = '24:00';
                            }
                        }
                        if(elem.groupType == 99 || elem.groupType == 0) {//个人日程或有约事件
                            var eventListHtml = _.template(eventListTpl, elem);
                            $("#eventList_box").prepend(eventListHtml);
                        }else{//公司大事件或公司活动
                            me.loadCompanyEventsAndActivity(elem);
                        }
					});
			} else {
				var listTxt = "";
				for(var i = 0; i < listLines; i++) {
					if(i == Math.floor(listLines / 2)) {
						listTxt += '<div class="lists">无日程</div>';
					} else {
						listTxt += '<div class="lists">&nbsp;</div>';
					};
				};
				$("#eventList_box").prepend(listTxt);
			}
			me.setHeight();
			//calenderList_JRoll.refresh(); // 刷新月历事件scroll
			//calenderList_JRoll.scrollTo(0, 0);
			$('[data-click-title="标题"]').attr("data-click-title", "日程表");
			setTimeout(function(){
                main_jroll.refresh();
                main_jroll.scrollTo(0,0);
            });
		},

		// 计算给定 日期的所在星期的 开始时间和结束时间
		getWeekArray: function(theYear, theMonth, theDay, theWeek) {
			theYear = parseInt(theYear);
			theMonth = parseInt(theMonth);
			theDay = parseInt(theDay);
			theWeek = parseInt(theWeek);
			// 新建 本周第一天的对象
			var weekFirst = null;
			var theDate = new Date(theYear, theMonth - 1, theDay);
			// 返回的数组
			var weekArray = [];
			// 最后返回的对象
			var returnObj = {};
			// 获取 本周第一天
			if(theWeek == 0) {
				weekFirst = theDate;
			} else if(theWeek == 6) {
				weekFirst = new Date(theDate.getTime() - 1000 * 60 * 60 * 24 * 6);
			} else {
				weekFirst = new Date(theDate.getTime() - 1000 * 60 * 60 * 24 * theWeek);
			}
			for(var i = 0; i < 7; i++) {
				var thisDay = new Date(weekFirst.getTime() + 1000 * 60 * 60 * 24 * i);
				var thisArray = [thisDay.getFullYear(), thisDay.getMonth() + 1, thisDay.getDate(), thisDay.getDay()];
				weekArray.push(thisArray);
			}

			if(!me.userClickDate) {
				me.userClickDate = moment().format('YYYY-MM-DD');
			}
			this.selectedDate = me.userClickDate.replace(/.*\-/g, "");
			var that = this;
			returnObj = {
				weekArray: weekArray,
				currentDate: me.getNowDate(),
				userClickDate: that.userClickDate.split("-")
			};

			return returnObj;
		},

		// 显示 周历
		showWeek: function(theYear, theMonth, theDay, theWeek) {
			var weekObj = {
				theYear: theYear,
				theMonth: theMonth,
				theDay: theDay,
				theWeek: theWeek
			}
			Store.saveObject("calendarBf_weekObj", weekObj);
			displayYear = theYear;
			displayMonth = theMonth;
			$("header .dataTitle").text(theYear + "." + parseInt(theMonth));
			$(".content-title .showTitle").text(theYear + "年" + parseInt(theMonth) + "月");
			var calendarHtml = _.template(weekTpl, me.getWeekArray(theYear, theMonth, theDay, theWeek));
			//alert(calendarHtml)
			$("#main .week-list").html(calendarHtml);
            me.insertCircle(theYear, theMonth);
			me.showWeekEvents(theYear, theMonth, theDay);
            me.showDateCalendar(me.userClickDate);
		},

		showPreWeek: function() {
			//displayWeek = new Date(moment(displayWeek.getTime()).add(-1, "weeks").valueOf());
			displayWeek = new Date(displayWeek.getTime() - 1000 * 60 * 60 * 24 * 7);
			me.userClickDate = (displayWeek.getFullYear()) + "-" + (displayWeek.getMonth() + 1) + "-" + displayWeek.getDate();
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
			me.showWeek(displayWeek.getFullYear(), displayWeek.getMonth() + 1, displayWeek.getDate(), displayWeek.getDay());
		},

		showNextWeek: function() {
			//displayWeek = new Date(moment(displayWeek.getTime()).add(1, "weeks").valueOf());
			displayWeek = new Date(displayWeek.getTime() + 1000 * 60 * 60 * 24 * 7);
			me.userClickDate = (displayWeek.getFullYear()) + "-" + (displayWeek.getMonth() + 1) + "-" + displayWeek.getDate();
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
			me.showWeek(displayWeek.getFullYear(), displayWeek.getMonth() + 1, displayWeek.getDate(), displayWeek.getDay());
		},

		//切换到本周视图的函数
		thisWeek: function() {
			// 获取现在的时间
			var nowDate = me.getNowDate();
			// 显示周历
			me.showWeek(nowDate.nowYear, nowDate.nowMonth, nowDate.nowDay, nowDate.nowWeek);
			// 更新周显示的 基准
			displayWeek = new Date();
		},

		// 显示周历事件
		showWeekEvents: function(d, m, t) {
			me.showCalendarWeek();
		},

		// 切换 月 周 显示
		monthChange: function() {
			me.userClickDate = Store.loadObject("calendarBf_userClickDate");
			var tempArr = me.userClickDate.split("-");
			displayWeek = new Date(parseInt(tempArr[0]), parseInt(tempArr[1]) - 1, parseInt(tempArr[2]));
			$("#main #calenderList").toggle();
			$("#main #weekList").toggle();
			// $("#main #section_wrap").toggle();
			// $("#main #weekEventList").toggle();
			$("#main #monthChange").find("li").toggleClass("active");

			//刷新周的数据
			if(!me.userClickDate) {
				// window.alert("這裡執行得到嗎")
				var obj = new Date();
				var y = displayYear;
				var m = displayMonth;
				var d = obj.getDate();
				me.userClickDate = "" + y + "-" + m + "-" + d;
				var dateString = me.userClickDate; //获取用户点击的日期
				var arrTemp = dateString.split("-");
				displayWeek = new Date(arrTemp[0], arrTemp[1], arrTemp[2]);
			}
			var dateString = me.userClickDate; //获取用户点击的日期
			var dateObject = me.getYearMonthDay(dateString);
			me.selectedDate = me.userClickDate.replace(/.*\-/g, "");
			if($("#main #monthChange").find("li.active").text() == "周") {//周历状态
				me.showWeek(dateObject.year, dateObject.month, dateObject.day, displayWeek.getDay());
				me.showDateCalendar(dateString);
				
				//html标签里面给#calendar-week标签里写了隐藏，所以这里要显示
				me.$el.find('#calendar-week').show();

			} else {//月历状态
            	me.$el.find('#calendar-week').hide();
				
				//左右箭头绑定滑动事件
				$('.content-icon-left').unbind('click').bind('click',function() {
					mySwiperMonth.slidePrev();
				})
				$('.content-icon-right').unbind('click').bind('click',function() {
					mySwiperMonth.slideNext();
				})

				// 刷新月历的数据
				me.showCalendar(dateObject.year, dateObject.month);
				var nowDate = moment().format('YYYY-MM-DD');
				// 判断是不是当前时间，分别加不同的class
				dateString = moment(dateString, "YYYY-M-D").format("YYYY-MM-DD");
				me.showDateCalendar(dateString);
				if(nowDate == $('#main #calenderList a[data-date="' + dateString + '"]').data("date")) {
					me.setCurrentDayIcon(dateString);
				} else {
					me.setTapDayBg(dateString);
				}

				me.setHeight(); // 调用周历事件表格动态高度
				me.eventTabListRoll_Func(); //调用周历JRoll方法
				// calenderList_JRoll.refresh(); //刷新月历JROLL
				main_jroll.refresh();
			}
		},
		getYearMonthDay: function(str) {
			var arr = str.split('-');
			dateObject = {
				year: arr[0],
				month: arr[1],
				day: arr[2]
			}
			return dateObject;
		},
		// 获取当前日期，时间
		getNowDate: function() {
			// 初始化需要返回的 时间对象
			var returnDate = {};

			// 获取当前时间
			var now = new Date();
			var nowWeek = now.getDay(); //今天本周的第几天
			var nowDay = now.getDate(); //当前日
			var nowMonth = now.getMonth() + 1; //当前月
			var nowYear = now.getFullYear(); //当前年
			var nowHour = now.getHours(); // 当前小时
			var nowMinutes = now.getMinutes(); // 当前分钟

			// 当前时间赋值给 时间对象
			returnDate = {
				nowYear: nowYear,
				nowMonth: nowMonth,
				nowDay: nowDay,
				nowWeek: nowWeek,
				nowHour: nowHour,
				nowMinutes: nowMinutes,
				dateString: nowYear + '-' + nowMonth + '-' + nowDay
			}

			// 返回时间对象
			return returnDate;
		},

		// 获取 某个月的第一天 是周几，最后一天是周几，最后一天的日期
		// 2015年12月返回值为：[2,4,31]
		getMonthWeek: function(theYear, theMonth) {
			// theYear 年份
			// theMonth 1-12的月份

			// 返回的数组 [第一天的星期, 最后一天的星期，最后一天的日期]
			theYear = parseInt(theYear);
			theMonth = parseInt(theMonth);
			var array = [];

			var theNextYear = theYear;
			var theNextMonth = theMonth + 1;

			// 计算下个月第一天的年月日
			if(theMonth == 12) {
				theNextYear += 1;
				theNextMonth = 1;
			}

			// 创建 theMonth的第一天的对象
			var theDate = new Date(theYear, theMonth - 1, 1);
			array.push(theDate.getDay());

			// 下个月的 第一天减去 一天 则是 要求的 月的最后一天
			// 设置theDate为 下个月第一天
			theDate.setYear(theNextYear);
			theDate.setMonth(theNextMonth - 1);

			// 新建下个月第一第一天的前一天对象
			theNextDate = new Date(theDate.getTime() - 1000 * 60 * 60 * 24);
			array.push(theNextDate.getDay());
			array.push(theNextDate.getDate());

			return array;
		},

		// 获取用于循环显示的 某月份的日期数组 主要是 在月的开始和结尾加入 填充数字
		// ["2015-12-01","2015-12-02"..."2015-12-31"]
		getMonthArray: function(theYear, theMonth) {
			if(Store.loadObject("calendarBf_selectDate")) {
				var selectDate = Store.loadObject("calendarBf_selectDate");
			} else {
				var selectDate = {
					date: -1,
					year: -1,
					month: -1
				}
			}
			// 获取 月的 第一天 和 最后一天的 星期。
			var weekInf = me.getMonthWeek(theYear, theMonth);

			// 初始化日期的数组
			var monthArray = [];

			// 初始化需要返回的对象
			var returnObj = {};

			var firstDayWeek = weekInf[0]; // 第一天的星期 0-6 0是周日
			var lastDayWeek = weekInf[1]; // 最后一天的星期
			var lastDay = weekInf[2]; // 最后一天的日期

			// 把当月第一天，之前的星期不全 补0
			for(var i = 0; i < firstDayWeek; i++) {
				monthArray.push(0);
			}

			// 把真实的日期放入数组
			for(var i = 1; i <= lastDay; i++) {
				monthArray.push(i);
			}

			// 把当月最后一天的星期补全 补0
			for(var i = 0; i < (6 - lastDayWeek); i++) {
				monthArray.push(0);
			}
			returnObj = {
					theYear: theYear,
					theMonth: theMonth,
					monthArray: monthArray,
					currentDate: me.getNowDate(),
					selectDate: selectDate
				}
				//console.log(returnObj);
			return returnObj;
		},

		// 处理 小于10 的情况
		calcTen: function(num) {
			if(num <= 0) {
				return num;
			} else {
				return num < 10 ? "0" + num : num;
			}
		},

		// 构造日历
		showCalendar: function(theYear, theMonth, slide) {
			$("#main .dataTitle").text(theYear + "." + parseInt(theMonth));
			$(".content-title .showTitle").text(theYear + "年" + parseInt(theMonth) + "月");
			if(!slide) {
				var calendarHtml = _.template(calendarTpl, me.getMonthArray(theYear, theMonth));
				$("#main #calenderList .swiper-slide").html(calendarHtml);
			}
			displayYear = theYear;
			displayMonth = theMonth;

			me.insertCircle(theYear, theMonth, slide);
		},
        insertCircle:function(theYear, theMonth, slide){
            // 先把旧的小圆点存下
            var circle = $(".circle");
            theMonth = "" + theMonth;
            if(parseInt(theMonth) < 10 && theMonth.length < 2) {
                theMonth = "0" + theMonth;
            };
            var tmpDate = moment(theYear + "-" + theMonth + "-01");
            CalendarCommon.getCalendarItemsFromDb(
                tmpDate.startOf("month").unix(),
                tmpDate.startOf("month").add(1, "months").unix(),
                function(data) {
                    console.log(data);
                    for(var i = 0; i < data.length; i++) {
                        var item = data[i];
                        var date = item.date;
                        var douhao = date.indexOf(",");
                        if(douhao != -1) {
                            var dateArr = date.split(",");
                            for(var d = 0; d < dateArr.length; d++) {
                                var dateM = dateArr[d];
                                dateM = moment(dateM).format("YYYY-MM-DD");
                                $("a.now-day[data-date='" + dateM + "']").append("<span class='circle'></span>")
                            };
                        } else {
                            date = moment(date).format("YYYY-MM-DD");
                            $("a.now-day[data-date='" + date + "']").append("<span class='circle'></span>");
                        }
                    };
                    //打上新圆点后，再把旧的圆点删除，优化圆点每次都闪一下的问题
                    circle.remove();
                    me.eventTabListRoll_Func();
                },
                function() {});
        },
		show_today: function() {
			// 获取现在的时间
			Butterfly.Store.deleteObject("calendarBf_isFirstEnter_two");
			var nowDate = me.getNowDate();

			// 显示当天的日程
			me.showDateCalendar(nowDate.dateString);
			var dayObject = me.getNowDate();
			var currentDay = dayObject.nowYear + '-' + dayObject.nowMonth + '-' + dayObject.nowDay;
			currentDay = moment(currentDay, "YYYY-MM-DD");
			me.setCurrentDayIcon(currentDay);
		},
		setCurrentDayIcon: function(currentDay) {
			var nowDate = me.getNowDate().dateString;
			$('#main #calenderList a').removeClass('now-day-bg');
			$('#main #calenderList a').removeClass('tap-day-bg');
			if(moment(currentDay).format("YYYY-MM-DD") == moment(nowDate, "YYYY-M-D").format("YYYY-MM-DD")) {
				$('#main #calenderList a[data-date="' + moment(currentDay).format("YYYY-MM-DD") + '"]').addClass('now-day-bg');
			} else {
				$('#main #calenderList a[data-date="' + moment(currentDay).format("YYYY-MM-DD") + '"]').addClass('tap-day-bg');
			}
		},
		setTapDayBg: function(tapDay) {
			$('#main #calenderList a').removeClass('now-day-bg');
			$('#main #calenderList a').removeClass('tap-day-bg');

			$('#main #calenderList a[data-date="' + tapDay + '"]').addClass('tap-day-bg');
		},
		// 今天
		today: function() {
			// 获取现在的时间
			Butterfly.Store.deleteObject("calendarBf_isFirstEnter_two");
			var nowDate = me.getNowDate();

			// 显示当天的日程
			me.showDateCalendar(nowDate.dateString);
			// 显示日历
			me.showCalendar(nowDate.nowYear, nowDate.nowMonth);
			var currentDay = moment(nowDate.dateString, 'YYYY-M-D').format("YYYY-MM-DD");
			me.setCurrentDayIcon(currentDay);
		},

		// 获取切换显示的 的 前一个月 或者后一个月的 日期 
		// @return '2015-11-08'
		getNewDay: function(year, month) {
			var now = new Date();
			// 得到今天的日期
			var todayDay = now.getDate();
			// 获取需要显示的 那一个月的 最后一天的日期
			var monthLastDate = me.getMonthWeek(year, month)[2];
			if(todayDay < monthLastDate) {
				todayDay = todayDay < 10 ? '0' + todayDay : todayDay;
				return year + '-' + month + '-' + todayDay;
			} else {
				monthLastDate = monthLastDate < 10 ? '0' + monthLastDate : monthLastDate;
				return year + '-' + month + '-' + monthLastDate;
			}
		},

		// 计算前一个月 并显示
		showPreMonth: function() {
			if(displayMonth == 1) {
				displayMonth = 12;
				--displayYear;
			} else {
				--displayMonth;
			}
			var tapDate = me.getMonthTapDay(me.userClickDate);
			var tapDateString = displayYear + "-" + displayMonth + "-" + tapDate;
			tapDateString = moment(tapDateString, "YYYY-M-D").format("YYYY-MM-DD");
			me.userClickDate = tapDateString;
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
			Store.saveObject("calendarBf_isFirstEnter_two", true);
			me.showDateCalendar(tapDateString);
			me.showCalendar(displayYear, displayMonth);
			me.setCurrentDayIcon(tapDateString);
		},

		// 计算后一个月 并显示
		showNextMonth: function() {
			if(displayMonth == 12) {
				displayMonth = 1;
				++displayYear;
			} else {
				++displayMonth;
			}
			var tapDate = me.getMonthTapDay(me.userClickDate);
			var tapDateString = displayYear + "-" + displayMonth + "-" + tapDate;
			tapDateString = moment(tapDateString, "YYYY-M-D").format("YYYY-MM-DD");
			me.userClickDate = tapDateString;
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
			Store.saveObject("calendarBf_isFirstEnter_two", true);
			me.showDateCalendar(tapDateString);
			me.showCalendar(displayYear, displayMonth);
			me.setCurrentDayIcon(tapDateString);
		},
		// 显示用户点击日期后每月当日的日程
		showMonthTapDay: function(u) {
			//如果有传具体的日期就用，没有就执行下面的
			if(u){
				var tapDateString = u;
			}else{
				var tapDate = me.getMonthTapDay(me.userClickDate)
				var tapDateString = displayYear + "-" + displayMonth + "-" + tapDate;
				tapDateString = moment(tapDateString, "YYYY-M-D").format("YYYY-MM-DD");
			}
			//alert(tapDateString);
			me.showDateCalendar(tapDateString);
			me.setCurrentDayIcon(tapDateString);
		},
		//获取用户点击后的日期，在每个月历中的日期
		getMonthTapDay: function(data) {
			var tapDate = {},
				tapDay;
			var monthLastDate = me.getMonthWeek(displayYear, displayMonth);
			monthLastDate = monthLastDate[2];
			if(!data) {
				var obj = new Date();
				var d = obj.getDate();
				tapDay = d;
			} else {
				tapDay = data.split("-")[2];
			};
			if(monthLastDate >= tapDay) {
				tapDate.date = tapDay;
			} else {
				tapDate.date = monthLastDate;
			};
			return tapDate.date;
		},
		// 日历点击函数
		tapDay: function(e) {
			// 获取当前时间字符串
			e.stopPropagation();
			//var nowDate = me.getNowDate().dateString;
			var target = e.target;
			//　如果点击的　td　修改target为ａ
			if($(target).get(0).tagName.toLowerCase() == 'td') {
				target = $(target).find('a');
			}
			if($(target).get(0).tagName.toLowerCase() == 'span') {
				target = $(target).parent();
			}

			//　判断如果点击的是　对象背景不是红的　执行ｉｆ
			if(!$(target).hasClass("now-day-bg")) {
				// 首先去掉 所有class
				$("#main .now-day").removeClass("now-day-bg").removeClass("tap-day-bg");
				// 判断是不是当前时间，分别加不同的class
				if(moment().format("YYYY-MM-DD") == moment($(target).data("date")).format("YYYY-MM-DD")) {
					$("#main .now-day[data-date='" + moment($(target).data("date")).format("YYYY-MM-DD") + "']").addClass("now-day-bg");
					$(target).addClass("now-day-bg");
				} else {
					$("#main .now-day[data-date='" + moment($(target).data("date")).format("YYYY-MM-DD") + "']").addClass("tap-day-bg");
					$(target).addClass("tap-day-bg");
				}
			}
			me.userClickDate = $(target).attr("data-date"); //记录用户点击的日期
			Store.saveObject("calendarBf_userClickDate", me.userClickDate);
			//me.showMonthTapDay();
			var arr = me.userClickDate.split("-");
			displayWeek = new Date(parseInt(arr[0]), parseInt(arr[1]) - 1, parseInt(arr[2]));
			me.showDateCalendar($(target).attr("data-date"));
			//calenderList_JRoll.scrollTo(0, 0); // 切换日期 使其日程回到顶部 
			main_jroll.refresh();
		},
        getActivityList:function(today){//获取公司活动、大事件
            if(!today && !ActivityListStartTime){//进入模块时第一次调用,以今天为基准查询前一个月和后三个月的大事件
                ActivityListStartTime = moment().subtract(1,'M');
                ActivityListEndTime = moment().add(3,'M');
            }else{//点击日历时调用,如果超出了当前的时间区间,更新区间
                var startTimeUnix = moment(ActivityListStartTime).unix(),
                    endTimeUnix = moment(ActivityListEndTime).unix(),
                    todayUnix = moment(today).unix();
                if(startTimeUnix >todayUnix || endTimeUnix< todayUnix){
                    ActivityListStartTime = moment(today).subtract(1,'M');
                    ActivityListEndTime = moment(today).add(3,'M');
                }else{//如果 没超出当前 时间区间,则不重复调用接口
                    return false;
                }
            }
            Util.Ajax({
                url:config.Api.getCalendarsList,
                data:{
                    //access_token:window.const_getAccessToken,
                    startTime:ActivityListStartTime.format('YYYY-MM-DD')||moment().format('YYY-MMM-DD'),
                    endTime:ActivityListEndTime.format('YYYY-MM-DD')||moment().format('YYY-MMM-DD')
                },
                type:'get',
                success:function(data){
                    console.log(data);
                    if(data){
                        me.insertDataFromServer(data);
                        // me.loadCompanyEventsAndActivity(data);
                    }
                },
                error:function(){
                    console.log(data);
                }
            });
        },
		// pad中 显示 dialog html为 页面名称，需要在本页面创建一个页面对象传进去。
		showPadDialog: function(pageName, html) {

			if(pageName) {
				pageName.show();
				pageName.$el.css({
					'display': 'block'
				});
				pageName.animateSlideInUp();
			} else {
				require(['view!module_calendarBf/' + html + '.html'], function(ViewClass) {
					pageName = new ViewClass();
					pageName.$el.css({
						'position': 'absolute',
						'top': '0px',
						'bottom': '0px',
						'width': '100%',
						'z-index': 1000
					});
					pageName.parentView = me;
					pageName.render();
					$("#pad-dialog").html(pageName.el);
					pageName.show();
					pageName.animateSlideInUp();
					$("#shadow-dialg").show();
					$("#shadow-dialg").css({
						"z-index": "20"
					});

				}, function(err) {
					Toast("操作失败，请重试");
				});
			};

		}

	});
	return model;
});

  define('module_calendarBf/module-registry',['require','./api','text!./calendarAdd.html','./calendarAdd','text!./calendarDetails.html','./calendarDetails','text!./calendarEdit.html','./calendarEdit','text!./calendarRemind-Allday.html','./calendarRemind-Allday','text!./calendarRemind.html','./calendarRemind','text!./calendarRepeat.html','./calendarRepeat','text!./calendarSearch.html','./calendarSearch','text!./calendarSearch_pad.html','./calendarSearch_pad','./common','text!./companyActivityDetail.html','./companyActivityDetail','./config','text!./index.html','./index','./js/calendarFunc','./js/common','./js/moment.min','./js/swiper.min','./js/validator','text!./main.html','./main','text!./template/activities_menu_tpl.html','text!./template/calendar-template.html','text!./template/companyActivityDetail-template.html','text!./template/eventList-template.html','text!./template/fourTypeEvents-template.html','text!./template/week-template.html','text!./template/weekEventList-template.html'],function(require){
    require("./api");
require("text!./calendarAdd.html");
require("./calendarAdd");
require("text!./calendarDetails.html");
require("./calendarDetails");
require("text!./calendarEdit.html");
require("./calendarEdit");
require("text!./calendarRemind-Allday.html");
require("./calendarRemind-Allday");
require("text!./calendarRemind.html");
require("./calendarRemind");
require("text!./calendarRepeat.html");
require("./calendarRepeat");
require("text!./calendarSearch.html");
require("./calendarSearch");
require("text!./calendarSearch_pad.html");
require("./calendarSearch_pad");
require("./common");
require("text!./companyActivityDetail.html");
require("./companyActivityDetail");
require("./config");
require("text!./index.html");
require("./index");
require("./js/calendarFunc");
require("./js/common");
require("./js/moment.min");
require("./js/swiper.min");
require("./js/validator");
require("text!./main.html");
require("./main");
require("text!./template/activities_menu_tpl.html");
require("text!./template/calendar-template.html");
require("text!./template/companyActivityDetail-template.html");
require("text!./template/eventList-template.html");
require("text!./template/fourTypeEvents-template.html");
require("text!./template/week-template.html");
require("text!./template/weekEventList-template.html");
  });
  
