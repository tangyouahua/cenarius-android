define(['bsl', 'util', 'zepto'], function(bsl, Util, $) {

    return function(host) {

        host = typeof host === "string" ? JSON.parse(host) : host;

        var hostRoot = host.root;
        var hostEmcs = host.emcs;
        var hostGbss = host.gbss;

        //把对象转换为数组
        window.toArray = function(obj) {
            if ($.isArray(obj)) {
                return obj;
            } else {
                return [obj];
            }
        };

        /**
         * 如果是生产环境，重写所有console的方法，禁止在生产环境输出
         * 提供__console方法在生产环境输出日志
         */
        window.__console = window.console;
        if (hostRoot.indexOf('gbss.infinitus.com.cn') > -1) {
            var n = function() {};
            window.console = {
                assert: n,
                clear: n,
                count: n,
                debug: n,
                dir: n,
                dirxml: n,
                error: n,
                group: n,
                groupCollapsed: n,
                groupEnd: n,
                info: n,
                log: n,
                markTimeline: n,
                profile: n,
                profileEnd: n,
                table: n,
                time: n,
                timeEnd: n,
                timeStamp: n,
                timeline: n,
                timelineEnd: n,
                trace: n,
                warn: n
            };
        }


        //动态绑定容器

        /**
         *
         * @param container 父元素
         * @param obj 数据
         * @param append
         * @param images 图片字段属性名数组
         * @returns {*}
         */
        window.bindTemplate = function(container, obj, append, images) {
            //历史遗留问题，这个方法不能用jQuery，只能用Zepto
            var $ = Zepto;

            if (typeof(container) == "string") {
                container = $("#" + container);
            }
            if (append != true) {
                container.children().remove();
            }
            var templateStr = $("#" + container.data("template")).html();
            var data = toArray(obj);
            if (!!images) {
                template.formatImage(data, images); //把data里面的图片添加前缀，并且为data新增一个key字段
            }


            var parent = $("#" + container.data("template") + "Parent"); //for ipad flexbox的应用,获取到html_pad的flex父元素，为了多栏布局
            var templateParentStr;
            var parentColumn;
            var parentClass;
            var parentMod;
			var lastRowLen;
            if (parent.length > 0) { //确定是否分栏布局
                templateParentStr = parent.html();
                parentColumn = parent.data("column");
                parentClass = parent.data("class");
				//by dyz,2016-9-22 当最后一行已经满格,不需要添加空位
				lastRowLen=data.length % parentColumn;//最后一行列数
				parentMod=lastRowLen&&(parentColumn-lastRowLen);//最后一行需要补充的空位数
               // parentMod = parentColumn - (data.length % parentColumn); //获取最后一行需要补多少个空位
            }
            var templateParent;
            for (var i = 0; i < data.length; i++) {
                var item;
                var itemStr = _.template(templateStr, data[i]); // 获取已经赋值后的html
                if (itemStr.trim().indexOf("<tr") == 0) {
                    item = $("<table>" + itemStr + "</table>"); //获取tr的时候内容里面必须有table包住，否则可能是空对象
                    item = item.find("tr");
                } else {
                    item = $(itemStr);
                }
                var hadChildren = []; //创建子模板的数组
                var allItem = item.concat(item.find("*")); //把所有自己的子元素和自己都放在 allItem里面
                allItem.forEach(function(e) {
                    //寻找allItem 里面是否有子模板，有就push 入hadChildren
                    var child = $(e);
                    var template = child.data("template");
                    var children = child.data("children");
                    if (!!template && !!children) {
                        hadChildren.push(e);
                    }
                });
                hadChildren.forEach(function(e) {
                    bindTemplate($(e), data[i][e.dataset["children"]]); //编译子模板
                });

                if (parent.length > 0) { //是否分栏布局
                    if (i % parentColumn === 0) { // 判断是否每一行的第一列位置，就添加一个flexbox的父元素
                        templateParent = $(templateParentStr);
                        container.append(templateParent);
                    }
                    for (var j = 0; j < item.length; j++) {
                        templateParent.append(item[j]);
                    }
                    if (i == data.length - 1 && parentMod!==0){// (data.length % 2 !== 0)) {
                        //假如循环到最后一个元素的时候，就添加空位。
                        for (var j = 0; j < parentMod; j++) {
                            templateParent.append($("<div style='background:none;border:none;' class='noBackground " + parentClass + "'></div>"));
                        }
                    }
                } else {
                    for (var j = 0; j < item.length; j++) {
                        container.append(item[j]);
                    }
                }
            }
            if (!!images) {
                template.loadImage(data, images);
            }
            container.removeClass("hidden");
            return container;
        };

        window.template = {
            emcs: host.cdn,
            //图片补全地址
            formatImage: function(obj, property) {
                var data = toArray(obj);
                var properties = toArray(property);
                for (var i = 0; i < data.length; i++) {
                    for (var j = 0; j < properties.length; j++) {
                        if (properties[j].indexOf("|") == -1) {
                            var url = data[i][properties[j]];
                            if (url !== null) {
                                //如果url不包含EMCS地址和http:协议，自动添加
                                if (url.indexOf(this.emcs) == -1 && url.indexOf('http:') === -1) {
                                    data[i][properties[j]] = this.emcs + url;
                                }

                                //url包括指定property值时，以property作为key值，否则以文件名作为key
                                if (url.indexOf("=") > -1) {
                                    //url /front/emcs-server-newMobile/guest/photo/getLibPhoto?photoCode=P1449736025060
                                    data[i][properties[j] + "Key"] = url.split("=")[1];
                                } else {
                                    //url http://hd.infinitus.com.cn/data/upload/20160725/5795e26e496e2.jpg
                                    data[i][properties[j] + "Key"] = 'P' + url.substring(url.lastIndexOf("/") + 1, url.lastIndexOf("."));
                                }
                            } else {
                                data[i][properties[j] + "Key"] = null;
                            }
                        } else { //支持子对象是数组
                            var children = properties[j].split("|");
                            var ary = toArray(data[i][children[0]]);
                            for (var k = 0; k < ary.length; k++) {
                                var url = ary[k][children[1]];
                                if (url !== null) {
                                    if (url.indexOf(this.emcs) == -1 && url.indexOf('http:') === -1) {
                                        ary[k][children[1]] = this.emcs + url;
                                    }

                                    if (url.indexOf("=") > -1) {
                                        ary[k][children[1] + "Key"] = url.split("=")[1];
                                    } else {
                                        ary[k][children[1] + "Key"] = 'P' + url.substring(url.lastIndexOf("/") + 1, url.lastIndexOf("."));
                                    }
                                } else {
                                    ary[k][children[1] + "Key"] = null;
                                }
                            }
                        }
                    }
                }
            },
            //把图片缓存到客户端
            loadImage: function(obj, property) {
                var data = toArray(obj);
                var properties = toArray(property)
                for (var i = 0; i < data.length; i++) {
                    for (var j = 0; j < properties.length; j++) {
                        if (properties[j].indexOf("|") == -1) {
                            var key = data[i][properties[j] + "Key"];
                            if (key !== null && key != "") {
                                var url = data[i][properties[j]];
                                console.log('url1', url)
                                bsl.infinitus.cache.cacheImageWithUrl(url, key, template.formatImageCallback);
                            }
                        } else { //支持子对象是数组
                            var children = properties[j].split("|");
                            var ary = toArray(data[i][children[0]]);
                            for (var k = 0; k < ary.length; k++) {
                                var key = ary[k][children[1] + "Key"];
                                if (key !== null && key != "") {
                                    var url = ary[k][children[1]];
                                    bsl.infinitus.cache.cacheImageWithUrl(url, key, template.formatImageCallback);
                                }
                            }
                        }
                    }
                }
            },
            //缓存到客户端后的回调方法
            /* params[0] url 远程图片地址
             * params[1] filePath 本地图片地址
             * params[2] sUserInfo 图片信息
             */
            formatImageCallback: function(params) {
                params = typeof params === "string" ? JSON.parse(params) : params;
                var filePath = params[1] || params[0];
                var sUserInfo = params[2];
                //当模板循环绑定数据的时候，图片属性名+'key'＝图片路径后面的参数值
                //图片路径: /front/emcs-server-newMobile/mongoPhoto/getProductPhoto?photoCode=S1418893496410
                //<img class="<%=iconImgKey%>" src="../com.infinitus.common/images/default.png" />
                var img = new Image();
                img.src = filePath;
                img.onload = function() {
                    $("." + sUserInfo).attr("src", filePath);
                };

            }
        };

        //日期格式化
        Date.prototype.format = function(format) {
            var o = {
                "M+": this.getMonth() + 1, //month
                "d+": this.getDate(), //day
                "h+": this.getHours(), //hour
                "m+": this.getMinutes(), //minute
                "s+": this.getSeconds(), //second
                "q+": Math.floor((this.getMonth() + 3) / 3), //quarter
                "S": this.getMilliseconds() //millisecond
            };
            if (/(y+)/.test(format)) {
                format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(format)) {
                    format = format.replace(RegExp.$1,
                        RegExp.$1.length == 1 ? o[k] :
                        ("00" + o[k]).substr(("" + o[k]).length));
                }
            }
            return format;
        };

        window.formatDate = function(obj, property, format) {
            var data = toArray(obj);
            var properties = toArray(property)
            for (var i = 0; i < data.length; i++) {
                for (var j = 0; j < properties.length; j++) {
                    data[i][properties[j]] = toDate(data[i][properties[j]]).format(format);
                }
            }
        };

        window.saveGlobalCache = function(key, val) {
            // if (bsl.infinitus.tools.debug) {
            window.localStorage.setItem(key, JSON.stringify(val));
            // } else {
            //     bsl.infinitus.cache.setH5Cache(key, JSON.stringify(val));
            // }
        };

        window.getGlobalCache = function(key, keep) {
            var objStr;
            // if (bsl.infinitus.tools.debug) {
            objStr = window.localStorage.getItem(key);
            // } else {
            //     objStr = bsl.infinitus.cache.getH5Cache(key);
            // }
            var obj = (objStr === null || objStr === "") ? null : JSON.parse(objStr);
            return obj;
        };

        window.clearGlobalCache = function() {
            // if (bsl.infinitus.tools.debug) {
            window.localStorage.clear();
            // } else {
            //     bsl.infinitus.cache.clearH5Cache();
            // }
        };

        //本地数据保存
        window.saveObject = function(key, value) {
	        var val;
	        if(typeof value === "object"){
		        val = JSON.stringify(value);
	        }else{
		        val = value;
	        }
	        window.localStorage.setItem(key,val);
        };

        //本地数据读取
        window.loadObject = function(key, keep) {
	        var ret = window.localStorage.getItem(key);

	        var result;
	        if(ret == null || ret == "null" || ret == ""){
		        result = null;
	        }else{
			        try{
				        result = JSON.parse(ret);
			        }catch(e){
				        //无法转为对象
				        result = ret;
			        }
	        }

	        return result;
        };

        //清除本地数据
        window.clearObject = function() {
            // if (bsl.infinitus.tools.debug) {
            window.localStorage.clear();
            // } else {
            //     bsl.infinitus.tools.cleanTempCache();
            // }
        };

        //清除本地数据
        window.removeObject = function(key) {
            window.localStorage.removeItem(key);
        };

        // 读取数据，软件关掉，数据清除
        window.readGlobalValue = function(key) {
            var objStr;
            // if (tools.debug) {
            objStr = window.sessionStorage.getItem(key);
            // } else {
            //     objStr = bsl.infinitus.cache.getH5Cache(key);
            // }
            var obj;
            if (typeof objStr == "undefined" || objStr === null || objStr === "") {
                obj = null;
            } else {
                if (typeof objStr !== "object") {
                    obj = JSON.parse(objStr);
                } else {
                    obj = objStr;
                }
            }
            return obj;
        };

        // 保存数据，软件关掉，数据清除
        window.saveGlobalValue = function(key, val) {
            var objStr;
            // if (tools.debug) {
            objStr = window.sessionStorage.setItem(key, JSON.stringify(val));
            // } else {
            //  objStr = bsl.infinitus.cache.setH5Cache(key, JSON.stringify(val));
            // }
        };
        //加法运算，避免数据相加小数点后产生多位数和计算精度损失。
        window.numAdd = function(num1, num2) {
            var baseNum, baseNum1, baseNum2;
            try {
                baseNum1 = num1.toString().split(".")[1].length;
            } catch (e) {
                baseNum1 = 0;
            }
            try {
                baseNum2 = num2.toString().split(".")[1].length;
            } catch (e) {
                baseNum2 = 0;
            }

            baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
            return (numMulti(baseNum, num1) + numMulti(baseNum, num2)) / baseNum;
        };

        //加法运算，避免数据相减小数点后产生多位数和计算精度损失。
        window.numSub = function(num1, num2) {
            var baseNum, baseNum1, baseNum2;
            var precision; // 精度
            try {
                baseNum1 = num1.toString().split(".")[1].length;
            } catch (e) {
                baseNum1 = 0;
            }
            try {
                baseNum2 = num2.toString().split(".")[1].length;
            } catch (e) {
                baseNum2 = 0;
            }
            baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
            precision = (baseNum1 >= baseNum2) ? baseNum1 : baseNum2;
            return Number(((num1 * baseNum - num2 * baseNum) / baseNum).toFixed(precision));
        };

        //乘法运算，避免数据相乘小数点后产生多位数和计算精度损失。
        //这个方法还是有问题
        window.numMulti = function(num1, num2) {
            var baseNum = 0;
            try {
                baseNum += num1.toString().split(".")[1].length;
            } catch (e) {}
            try {
                baseNum += num2.toString().split(".")[1].length;
            } catch (e) {}
            return Number(num1.toString().replace(".", "")) * Number(num2.toString().replace(".", "")) / Math.pow(10, baseNum);
        };


        //除法运算，避免数据相除小数点后产生多位数和计算精度损失。
        //这个方法还是有问题
        window.numDiv = function(num1, num2) {
            var baseNum1 = 0,
                baseNum2 = 0;
            var baseNum3, baseNum4;
            try {
                baseNum1 = num1.toString().split(".")[1].length;
            } catch (e) {
                baseNum1 = 0;
            }
            try {
                baseNum2 = num2.toString().split(".")[1].length;
            } catch (e) {
                baseNum2 = 0;
            }
            with(Math) {
                baseNum3 = Number(num1.toString().replace(".", ""));
                baseNum4 = Number(num2.toString().replace(".", ""));
                return (baseNum3 / baseNum4) * pow(10, baseNum2 - baseNum1);
            }
        };

        window.pageObject = {
            init: function(page) {
                //防止重复执行
                if (page.init_is_ok) {
                    return;
                } else {
                    page.init_is_ok = true;
                }
                //弹出框
                $(".showOverlay").unbind("click").bind("click", function() {
                    $(".overlay").removeClass("hidden");
                });

                $(".overlay").unbind("click").bind("click", function(sender) { //点击灰色层隐藏
                    if (sender.currentTarget == sender.target) {
                        $(".selected_up").removeClass('selected_up');
                        $(sender.currentTarget).addClass("hidden");
                        if (typeof page.hideOverlayCallBack === 'function') {
                            page.hideOverlayCallBack();
                        }
                    }
                });

                //tab
                var firstTab = $(".tab > div > div:nth-child(1)");
                firstTab.addClass("tab-active").siblings().removeClass("tab-active");
                var firstContext = $("#" + firstTab.data("context"));
                firstContext.removeClass("hidden").siblings().addClass("hidden");
                $(".tab>div>div").unbind("click").bind("click", function(e) {
                    var target = $(e.currentTarget);
                    var context = target.data("context");
                    var localNameNow = $(".ui3-header").children().children().eq(1).text().trim();
                    if (localNameNow == "有奖活动") {
                        closeBaiduSecord();
                        setTimeout(function() {
                            openBaiduSecord();
                        }, 500);
                    }

                    target.addClass("tab-active").siblings().removeClass("tab-active");
                    if (!!e.changeTab) {
                        e.changeTab(context);
                    }
                    //加上动画
                    var showContext = $("#" + context);
                    var currentContext = showContext.siblings().not(".hidden");
                    currentContext.addClass("autoHide");
                    setTimeout(function() {
                        showContext.addClass("autoShow");
                        showContext.removeClass("hidden").siblings().addClass("hidden");
                        showContext.removeClass("autoShow");
                        currentContext.removeClass("autoHide");
                    }, 500);
                });

                //tab 滑动，代码应该放在上面的位置
                $("html").bind("swipeLeft", function(e) {
                    if (!!e.swipe) {
                        e.swipe("left");
                    }
                    $(".tab-active").next().trigger("click");
                });
                $("html").bind("swipeRight", function(e) {
                    if (!!e.swipe) {
                        e.swipe("right");
                    }
                    $(".tab-active").prev().trigger("click");
                });

                //下拉分页代码
                if (page.nextPage !== null) {
                    $(window).bind("scroll", function(e) {
                        var nextPage = page.$el.find(".nextPage:not(.hidden)");
                        if (page.hasNextpage === true) { //还有下一页
                            var offset = nextPage.offset();
                            var nextPagePosition = offset.top + numDiv(offset.height, 2); //offsetTop + 2分之一“加载更多”高度
                            var currentWindow = $(window);
                            var currentPosition = currentWindow.height() + currentWindow.scrollTop();
                            if (nextPagePosition <= currentPosition) { //已经到底部，请求下一页数据
                                page.nextPage();
                            }
                        }
                    });
                }

                //省市区选择
                $(".areaSelect:not(:disabled),#addressList:not(:disabled)").bind("click", business.selectArea);

                //弹出层出现后，背后层不能拖动
                $(".overlay").bind("touchmove", function(e) {
                    var div = $(e.currentTarget).find("div > div:nth-of-type(2)")[0];
                    if (div && div.scrollHeight <= $(div).css("height").replace(/[a-z]/g, '')) {
                        e.preventDefault();
                        return;
                    }
                    var continueMove = false;
                    $(".overlay > div > div:nth-of-type(2) > div").each(function() {
                        if (e.target == this) {
                            continueMove = true;
                            return false;
                        }
                    });
                    if (!continueMove) e.preventDefault();
                });
            },
            nextPageSuccess: function(page, data) {
                if (data.lastPage) { //已是最后一页，隐藏下一页标签
                    page.$el.find(".nextPage").addClass("hidden");
                    page.hasNextpage = false;
                } else { //不是最后一页，显示下一页标签
                    page.$el.find(".nextPage").removeClass("hidden");
                    page.hasNextpage = true;
                }
            },
            nextPageFailed: function(page) {
                $(".nextPage").addClass("hidden");
            }
        };

        window.doNothing = function() {}

        //之前不知道currentTarget，所以要用target找到currentTarget的 data属性
        window.findData = function(e, key) {
            var target = $(e);
            var value = target.data(key);
            if (value === null || value === ""||value===undefined) {
                var parent = target.parent();
                if (parent.length > 0) {
                    return findData(parent, key);
                }
            } else {
                return value;
            }
        };

        String.prototype.trim = function() {
            return this.replace(/(^\s*)|(\s*$)/g, "");
        };

        String.prototype.trimStr = function(value) {
            var str = this;
            if (str.indexOf(value) === 0) {
                str = str.substring(value.length);
            }
            if (str.indexOf(value) == str.length - value.length) {
                str = str.substring(0, str.length - value.length);
            }
            return str;
        };

        window.business = {
            selectArea: function(e, touch) {
				var $ = Zepto;//只能用zepto
                $('<input type="radio" value="bugfix" name="bugfix">').insertAfter($(e.currentTarget)).click().focus().remove(); //bugfix hack 解决 iPad 光标闪烁和键盘不收起的问题 appendTo("body")会导致overlay显示时body忽然滚动到最低端
                var target = $(e.target);
                var type = target.data("type"); // 省、市、区
                var business = target.data("business"); //区分接口数据,根据接口文档
                var parent = e.target.dataset["parent"]; //已选择的上一级目录对象
                page.addressSelectCode = e.target.dataset["code"];
                var saleBranchNo = e.target.dataset["salebranchno"]; //在线推荐的分公司code
                var zipCode = e.target.dataset["zipcode"];
                var data = {};
                var url;
                var parentType;
                var childType;
                var clear = [];
                var title;
                switch (type) {
                    case "province":
                        if (business == "so") {
                            url = "/front/gbss-mobile-newBusiness/common/query/listSoProvinces";
                        } else {
                            url = "/front/gbss-mobile-newBusiness/jpAddrManager/query/listJpPoProvinces";
                        }
                        childType = "city";
                        title = "选择省份";
                        break;
                    case "city":
                        if (business == "so") {
                            url = "/front/gbss-mobile-newBusiness/common/query/listSoCitys";
                        } else {
                            url = "/front/gbss-mobile-newBusiness/jpAddrManager/query/listJpPoCitys";
                        }
                        parentType = "province";
                        childType = "county";
                        clear = ["city", "county", "districts"];
                        if (!parent) { // 上一级没有选择
                            return;
                        }
                        data = {
                            provinceCode: parent
                        };
                        title = "选择城市";
                        break;
                    case "county":
                        if (business == "so") {
                            url = "/front/gbss-mobile-newBusiness/common/query/listSoCountys";
                        } else {
                            url = "/front/gbss-mobile-newBusiness/jpAddrManager/query/listJpCountys";
                        }
                        parentType = "city";
                        childType = "districts";
                        clear = ["county", "districts"];
                        if (!parent) {
                            return;
                        }
                        data = {
                            cityCode: parent
                        };
                        title = "选择区/县";
                        break;
                    case "districts":
                        url = "/front/gbss-mobile-newBusiness/jpAddrManager/query/listJpDistricts";
                        parentType = "county";
                        clear = ["districts"];
                        if (!parent) {
                            return;
                        }
                        data = {
                            areaCode: parent
                        };
                        title = "选择镇/区";
                        break;
                    default:
                        parentType = "districts";
                        break;
                }
                var text = target.text();
                console.log(target);
                if (text !== "") {
                    //清空所有下级的数据
                    clear.forEach(function(item) {
                        $(".areaSelect[data-type='" + item + "']").val("").attr("placeholder", "请选择");
                        $(".areaSelect[data-type='" + item + "']").data("parent", "");
                        $(".areaSelect[data-type='" + item + "']").data("code", "");
                    });
                    var parentSel = $(".areaSelect[data-type='" + parentType + "']");
                    parentSel.val(text);
                    parentSel.data("code", parent);
                    if (page.selectArea != null) {
                        page.selectArea(parentType, parent, saleBranchNo, zipCode);
                    }
                    if (parentType == "districts") {
                        parentSel.data("ismaxactive", e.target.dataset["ismaxactive"]);
                        var effectivedate = e.target.dataset["effectivedate"];
                        if (effectivedate != "") {
                            effectivedate = effectivedate.split(" ")[0];
                            parentSel.data("effectivedate", effectivedate);
                        }
                    }
                    $(".areaSelect[data-type='" + type + "']").data("parent", parent);
                }
                if (!!url && $(".areaSelect[data-type='" + type + "']").length > 0) {
                setTimeout(function(){
                    Util.Ajax({
                        url: url,
                        data: data,
                        success: function(data, status, xhr) {
                            data.forEach(function(item) {
                                item.type = childType;
                                item.isMaxActive = item.isMaxActive == null ? "" : item.isMaxActive;
                                item.effectiveDate = item.effectiveDate == null ? "" : item.effectiveDate;
                                item.zipCode == item.zipCode == null ? "" : item.zipCode;
                            });
                            bindTemplate("addressList", data);
                            $($("#addressList").parent().children()[0]).text(title);
                            $("#addressList").children().data("business", business);
                            var children = $("#addressList").children();
                            for (var i = 0; i < data.length; i++) {
                                children[i].dataset["salebranchno"] = data[i].saleBranchNo;
                                children[i].dataset["zipcode"] = data[i].zipCode;
                            }       
                            $(".selectArea").parent().removeClass("hidden");
                            $("#addressList>div[data-parent='" + page.addressSelectCode + "']").addClass("active");
                            //判断城市级别，设置相应产品配送权限
                            if ($("#lblProducts").length) {
                                if (data[0].areaAttr != undefined) {
                                    switch (data[0].areaAttr) {
                                        case "A":
                                            console.log(data[0].areaAttr);
                                            $("#lblProducts").text("全部产品");
                                            break;
                                        case "B":
                                            console.log(data[0].areaAttr);
                                            $("#lblProducts").text("全部产品");
                                            break;
                                        case "C": //三四线城市家居配送，获取其可配送产品
                                        case "D":
                                            console.log(data[0].areaAttr);
                                            Util.Ajax({
                                                url: "/front/gbss-mobile-newBusiness/jpAddrManager/query/getJpSpecialProducts",
                                                data: {},
                                                success: function(data, status, xhr) {
                                                    var JpSpecialProducts = data.productCodes;
                                                    JpSpecialProducts = JpSpecialProducts.split(",")
                                                    var JPspecialProductsList = [];
                                                    var JpSpecialProductsNameList = "";
                                                    for (var i = 0, l = JpSpecialProducts.length; i < l; i++) {
                                                        JPspecialProductsList.push(JpSpecialProducts[i].split("||")[1].trim());
                                                    }
                                                    JpSpecialProductsNameList = JPspecialProductsList.join(",");
                                                    console.log(JpSpecialProductsNameList);
                                                    $("#lblProducts").text(JpSpecialProductsNameList);
                                                }
                                            });
                                            break;
                                    }
                                } else {
                                    $("#lblProducts").text("");
                                }
                            }
                        }
                    });
                },300);
                } else {
                    $(".selectArea").parent().addClass("hidden");
                }
            }
        }

        //当没数据的时候要显示一个DIV样式来显示
        window.empty = function(msg, page) {
            var noData = "<div class='empty middle'>" + msg + "</div>";
            page.$el.append(noData);
            // page.el.appendChild(noData[0]);
        }

        window.removeEmpty = function() {
            $(".empty").remove();
        }

        window.removeScroll = function() {
            var window_height = $(window).height();
            $(".page").height(window_height).css("overflow", "hidden");
        }

        window.enableScroll = function() {
            $(".page").height("auto").css("overflow", "auto");
        }


        //解决事件穿透
        window.stopTap = function(touch, e) {
            var target = $(touch.el);
            if (target.hasClass("overlay") || (target.parents().hasClass("overlay") && !(target.is("input[type='text']") || target.is("input[type='checkbox']"))) || target.hasClass("goBack") || ($(touch.el).data("stop") || $(touch.el).parents("[data-stop='true']").length > 0)) {
                var forTap = $('#forTap');
                if (!forTap[0]) {
                    forTap = $('<div id="forTap" style="display: none; border-radius: 60px; position: absolute; z-index: 99999; width: 60px; height: 60px"></div>');
                    $('body').append(forTap);
                }
                forTap.css({
                    top: (e.changedTouches[0].pageY - 30) + 'px',
                    left: (e.changedTouches[0].pageX - 30) + 'px'
                });
                forTap.show();
                setTimeout(function() {
                    forTap.hide();
                }, 350);
            }
        }

        window.keyboardWillShow = function() {
            $(".shoppingBar").addClass("commonHidden");
            $(".topBar>div,.fixed").addClass("topBarHidden");
            page.currentScroll = document.body.scrollTop;
        }

        window.keyboardWillHide = function() {
            $(".shoppingBar").removeClass("commonHidden");
            $(".topBar>div,.fixed").removeClass("topBarHidden");
            document.body.scrollTop = page.currentScroll;
        };

        window.toDate = function(str) {
            try {
                if (str === null) {
                    return new Date();
                }
                var date = new Date(str);
                if (!isNaN(date)) {
                    return date;
                } else {
                    // return eval("new Date(" + str.split(/\D/).join(",").replace(/(^\,*)|(\,*$)/g, "") + ")");
                    var parms = str.split(/\D/).join(",").replace(/(^\,*)|(\,*$)/g, "").split(",")
                    parms[1] = parseInt(parms[1]) - 1;
                    return eval("new Date(" + parms.join(",") + ")");
                }
            } catch (ex) {
                return new Date(undefined);
            }
        };

        window.selecttwo = function() {
            var firstTab = $(".tab > div > div:nth-child(2)");
            firstTab.addClass("tab-active").siblings().removeClass("tab-active");
            var firstContext = $("#" + firstTab.data("context"));
            firstContext.removeClass("hidden").siblings().addClass("hidden");
        }

        //页面跳转统计开始
        window.openBaiduSecord = function() {
            var topBar = $(".topBar");
            var localNameNow = topBar.children().children().eq(1).text().trim();
            var tabNameNow;
            if (localStorage.topBarName == null) {
                if (localNameNow == "有奖活动") {
                    tabNameNow = $(".tab").find(".tab-active").text().trim();
                    localStorage.topBarName = tabNameNow;
                    bsl.infinitus.baiduTools.recordPageStart(tabNameNow);
                    //alert("统计开始："+tabNameNow);
                } else if (localNameNow == "帮助") {
                    var helpNameNow = "使用帮助";
                    localStorage.topBarName = helpNameNow;
                    bsl.infinitus.baiduTools.recordPageStart(helpNameNow);
                    //alert("统计开始："+helpNameNow);
                } else {
                    localStorage.topBarName = localNameNow;
                    bsl.infinitus.baiduTools.recordPageStart(localNameNow);
                    //alert("统计开始："+localNameNow);
                }
            }
        };

        //页面跳转统计结束
        window.closeBaiduSecord = function() {
            var localName = localStorage.topBarName;
            var localNameNow = $(".topBar").children().children().eq(1).text().trim();
            if (localName !== null) {
                if (localNameNow != "有奖活动") {
                    bsl.infinitus.baiduTools.recordPageEnd(localName);
                    //alert("统计结束：" + localName);
                } else {
                    bsl.infinitus.baiduTools.recordPageEnd(localStorage.topBarName);
                    //alert("统计结束：" + localStorage.topBarName);
                }
                localStorage.removeItem("topBarName");
            }

        };

        //html5tools add by chenjianlong 2015-7-15
        window.html5tools = {
            /* showDialog 打开对话框
             * sTitle 标题
             * sMsg     提示内容，支持html标签、样式
             * aBtnTitles   按钮数组，例：["确定", "取消"]
             * sCallback  回调函数，可以是函数，也可以是函数名字符串，例：function(index){} //index对应按钮的位置，由0开始
             */
            curCallback: null,
            showDialog: function(sTitle, sMsg, aBtnTitles, sCallback) {
                var html, body, wrap, box, title, bodyer, footer, i, l, h, s = "",
                    t = "",
                    isClick;
                if(bsl.infinitus.tools.debug){
                    var alert_bg = "#ebfffd";
                    var alert_btn = "#000000";
                    var alert_btn_select = "#ffffff";
                    var alert_btn_bg_select = "#64bdaf";
                    var alert_split = "#d7d2cc";
                    var alert_title = "#000000";
                    var alert_content = "#000000";
                }else{
                    bsl.infinitus.tools.themeColor("alert_bg",function(clor){
                        var alert_bg = clor;
                    });
                    bsl.infinitus.tools.themeColor("alert_btn",function(clor){
                        var alert_btn = clor;
                    });
                    bsl.infinitus.tools.themeColor("alert_btn_select",function(clor){
                        var alert_btn_select = clor;
                    });
                    bsl.infinitus.tools.themeColor("alert_btn_bg_select",function(clor){
                        var alert_btn_bg_select = clor;
                    });
                    bsl.infinitus.tools.themeColor("alert_split",function(clor){
                        var alert_split = clor;
                    });
                    bsl.infinitus.tools.themeColor("alert_title",function(clor){
                        var alert_title = clor;
                    });
                    bsl.infinitus.tools.themeColor("alert_content",function(clor){
                        var alert_content = clor;
                    });
                }
                // var alert_bg = bsl.infinitus.tools.debug ? "#ebfffd" : tools.themeColor("alert_bg"); //弹窗背景色
                // var alert_btn = bsl.infinitus.tools.debug ? "#000000" : tools.themeColor("alert_btn"); //弹窗按钮文本色
                // var alert_btn_select = bsl.infinitus.tools.debug ? "#ffffff" : tools.themeColor("alert_btn_select"); //弹窗按钮被选中时文本色
                // var alert_btn_bg_select = bsl.infinitus.tools.debug ? "#64bdaf" : tools.themeColor("alert_btn_bg_select"); //弹窗按钮被选中时背景色
                // var alert_split = bsl.infinitus.tools.debug ? "#d7d2cc" : tools.themeColor("alert_split"); //弹窗分隔线颜色
                // var alert_title = bsl.infinitus.tools.debug ? "#000000" : tools.themeColor("alert_title"); //弹窗标题颜色
                // var alert_content = bsl.infinitus.tools.debug ? "#000000" : tools.themeColor("alert_content"); //弹窗内容颜色

                this.curCallback = sCallback;

                body = document.body;
                h = window.innerHeight;
                wrap = document.getElementById("html5_dialog_wrap");
                box = document.getElementById("html5_dialog_box");
                title = document.getElementById("html5_dialog_title");
                bodyer = document.getElementById("html5_dialog_body");
                footer = document.getElementById("html5_dialog_footer");

                if (!wrap) {
                    createDialogDiv();
                }

                if (sTitle) {
                    title.innerHTML = sTitle;
                }

                if (sMsg) {
                    bodyer.innerHTML = sMsg;
                }

                if (aBtnTitles instanceof Array) {
                    for (i = 0, l = aBtnTitles.length; i < l; i++) {
                        if (i !== l - 1) {
                            t = "style='display:table-cell;border-right:1px solid " + alert_split;
                            if (i === 0) {
                                t += ";border-bottom-left-radius:8px;'";
                            } else {
                                t += ";'";
                            }
                        } else {
                            t = "style='display:table-cell;border-bottom-right-radius:8px;'";
                        }
                        s += "<div class='html5-dialog-button' data-index=" + i + " " + t + ">" + aBtnTitles[i] + "</div>";
                    }
                    footer.innerHTML = s;
                }

                wrap.style.display = "block";

                //让弹窗垂直居中
                wrap.style.top = scrollY + "px";
                bodyer.style.maxHeight = (h * 0.88 - title.offsetHeight * 2) + "px";
                box.style.top = (h - box.offsetHeight) / 2 + "px";

                //创建元素 元素标签,id,class
                function createEl(tag, id, css) {
                    var el = document.createElement(tag);
                    if (id) el.id = id;
                    if (css) el.style.cssText = css;
                    return el;
                }

                //创建对话框
                function createDialogDiv() {
                    wrap = createEl("div", "html5_dialog_wrap",
                        "width:100%;height:100%;position:absolute;top:0;left:0;background:rgba(0,0,0,.5);z-index:999;display:none;");
                    box = createEl("div", "html5_dialog_box",
                        "width:88%;height:auto;margin:0 auto;background:" + alert_bg + ";position:absolute;left:6%;border-radius:8px;");
                    title = createEl("div", "html5_dialog_title",
                        "border-bottom:1px solid #d8d0c9;font-size:.46rem;height:.88rem;line-height:.88rem;text-align:center;color:" + alert_title + ";");
                    bodyer = createEl("div", "html5_dialog_body",
                        "font-size:.36rem;padding:.2rem;overflow-y:auto;color:" + alert_content + ";");
                    footer = createEl("div", "html5_dialog_footer",
                        "border-top:1px solid #d8d0c9;height:.88rem;color:" + alert_btn + ";line-height:.88rem;font-size:.3rem;width:100%;text-align:center;display:table;-webkit-tap-highlight-color:transparent;");
                    box.appendChild(title);
                    box.appendChild(bodyer);
                    box.appendChild(footer);
                    wrap.appendChild(box);

                    //ipad尺寸
                    if (window.innerWidth > 768) {
                        box.style.width = "46%";
                        box.style.left = "27%";
                    }

                    //给footer添加事件监听
                    footer.addEventListener("touchstart", function(e) {
                        var el = e.target;
                        if (el.className === "html5-dialog-button") {
                            //设置按钮被选中颜色
                            el.style.background = alert_btn_bg_select;
                            el.style.color = alert_btn_select;

                            isClick = true;
                        }
                    }, false);

                    footer.addEventListener("touchend", function(e) {
                        var el = e.target;
                        if (!isClick) return;
                        if (el.className === "html5-dialog-button") {
                            //按钮置回默认颜色
                            el.style.background = alert_bg;
                            el.style.color = alert_btn;

                            if (typeof html5tools.curCallback === "function") {
                                html5tools.curCallback(parseInt(el.dataset["index"]));
                            } else if (typeof html5tools.curCallback === "string") {
                                eval(html5tools.curCallback + "(" + el.dataset["index"] + ")");
                            }
                        }
                    }, false);

                    wrap.addEventListener("touchmove", function(e) {
                        e.preventDefault();

                        //将所有按钮的颜色置回默认值
                        var btns = footer.querySelectorAll(".html5-dialog-button");
                        for (var i = 0; i < btns.length; i++) {
                            btns[i].style.background = alert_bg;
                            btns[i].style.color = alert_btn;
                        }

                        isClick = false;
                    }, false);

                    body.appendChild(wrap);
                }
            },

            /* closeDialog 关闭对话框 */
            closeDialog: function() {
                var dlg = document.getElementById("html5_dialog_wrap");
                if (dlg) dlg.style.display = "none";
            }
        };

        //生成唯一ID，create by chenjianlong 2016-06-07
        //格式[8位16进数]-[4位16进数]-[4位16进数]-[4位16进数]-[12位16进数]
        //例：2A774185-0BE9-F924-FF12-AE3C89611144
        window.createUniqueId = function() {
            var a = (Date.now()).toString(16).substr(3, 8).toUpperCase();
            var b = get4random();
            var c = get4random();
            var d = get4random();
            var e = get4random() + get4random() + get4random();

            function get4random() {
                var f = parseInt(Math.random() * 100000).toString(16).toUpperCase().substr(0, 4);
                if (f.length !== 4) {
                    for (var i = 0, l = 4 - f.length; i < l; i++) {
                        f = "0" + f;
                    }
                }
                return f;
            }
            return a + "-" + b + "-" + c + "-" + d + "-" + e;
        };

        //页面跳转
        window.jumpToPage = function(url, isDel) {
            //跳转前检查网络状态
            bsl.infinitus.network.checkNetState(function(netStatus) {
                if (parseInt(netStatus) === 0) {
                    if (window.UI3) {
                        window.UI3.showNetworkFail();
                    } else {
                        bsl.infinitus.tools.showToast("网络连接异常，稍后重试!");
                    }
                } else {
                    if (window.UI3) {
                        window.UI3.hideNetworkFail();
                    }
                    location.href = url;
                }
            });
        };

        //返回元素在数组中的index
        if (!Array.prototype.indexOf) {
            Array.prototype.indexOf = function(elt) {
                var len = this.length >>> 0;
                var from = Number(arguments[1]) || 0;
                from = (from < 0) ? Math.ceil(from) : Math.floor(from);
                if (from < 0) from += len;
                for (; from < len; from++) {
                    if (from in this && this[from] === elt) return from;
                }
                return -1;
            };
        }
        //根据index删除数组元素
        if (!Array.prototype.del) {
            Array.prototype.del = function(n) {
                if (n < 0) {
                    return this;
                } else {
                    return this.slice(0, n).concat(this.slice(n + 1, this.length));
                }
            };
        }

        window.selectTab = function(mcode, fun, sParam) {
            bsl.infinitus.tools.getCommonParam(function(param) {
                param = typeof param === "string" ? JSON.parse(param) : param;
                var model = param[0].model;
                //索引 模块code
                var index, code;
                switch (mcode) {
                    case 'EFAN':
                        index = 1;
                        if (model == 1 || model == '1') { //ipad
                            code = 'BUPM-PAD-EFAN';
                        } else {
                            code = 'BUPM-PHONE-EFAN';
                        }
                        break;
                    case 'MY':
                        index = 3;
                        if (model == 1 || model == '1') { //ipad
                            code = 'BUPM-PAD-MY';
                        } else {
                            code = 'BUPM-PHONE-MY';
                        }
                        break;
                }
                //跳到原生tab
                bsl.infinitus.transfer.selectedTabItem({
                    "selectedItem": [index, code],
                    "sFunction": fun || '',
                    "sParam": sParam || ''
                });
            });
        };

    };
});