function getHost(param){
	var host;
	switch(param){
		case 'bupm':
			host = 'http://10.86.21.66:6089';
		break;
		default:
			host = 'http://cmsapi-test.infinitus.com.cn';
		break;
	}
	return host;
}