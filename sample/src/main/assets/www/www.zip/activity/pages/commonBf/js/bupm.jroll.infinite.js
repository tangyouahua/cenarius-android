/**
 * jroll.infinite
 * 由JRoll2的jroll-infinite和jroll-pulldown组合兼容JRoll1的jroll.infinite
 */
define([
    'jroll', 'jroll-infinite', 'jroll-pulldown'
], function (JRoll, Infinite, Pulldown) {
    'use strict';

    var JRoll_Infinite = function (selector, options, jrollOption) {
        
        var jroll = new JRoll(selector, jrollOption || {});

        //下拉刷新
        jroll.pulldown({
            refresh: function(complete) {
                jroll.options.page = 1;
                jroll.scrollTo(0, 44, 0, true);  //滚回顶部
                options.getData(1, function (data) {
                    complete();
                    jroll.scroller.innerHTML = "";    //清空内容
                    jroll.infinite_callback(data);
                })
            }
        });

        //无限加载
        jroll.infinite(options);

        this.jroll = jroll;
        this.options = jroll.options;
        this.getData = function () {
            options.getData(1, function (data) {
                jroll.scroller.innerHTML = "";    //清空内容
                jroll.infinite_callback(data);
            })
        }
    }

    return JRoll_Infinite
});