define({
	"language": "zh-cn",
	"pullup_load_more": "上拉加载更多数据...",
	"release_to_load": "释放以加载...",
	"release_to_update": "释放以刷新...",
	"pulldown_to_refresh": "下拉刷新...",
	"data_updating": "数据刷新中...",
	"data_loading": "数据加载中...",
	"not_offline": "当前不在离线模式中",
	"no_data": "无相关记录",
	"no_more_data": "",
	"search": "搜索",
	"searching": "查询中..."
});