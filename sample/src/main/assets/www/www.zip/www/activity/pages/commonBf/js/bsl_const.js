define(['bsl'], function(bsl) {
	window.bsl_const = {};
	var native = {
		/*公共参数*/
		getCommonParam : function(callback){
			bsl.infinitus.tools.getCommonParam(function(commonParam){
				if (commonParam) {
					commonParam = JSON.parse(commonParam);
					callback(commonParam);
				}
			});
		},
		/*客户端请求host*/
		getHost : function(callback){
			bsl.infinitus.tools.getHost(function(host) {
				if (host) {
					host = JSON.parse(host);
					callback(host);
				}
			})
		},
		getConst : function(){
			var me = this;
			me.getCommonParam(function(commonParam){
				window.bsl_const.getCommonParam = commonParam;

				me.getHost(function(host){
					window.bsl_const.getHost = host;
				})
			})
		}
	};

	native.getConst();

	//登陆成功广播和APP激活广播
	bsl.infinitus.tools.addObserverForUserInfo(function(result){
		//登录后重新获取公共参数
		native.getCommonParam(function(commonParam){
			window.bsl_const.getCommonParam = commonParam;
		})
	})
});
